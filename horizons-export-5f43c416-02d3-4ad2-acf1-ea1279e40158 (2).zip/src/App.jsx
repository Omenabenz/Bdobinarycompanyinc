import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';

import HomePage from '@/pages/HomePage';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import ResetPasswordPage from '@/pages/ResetPasswordPage';
import AdminLoginPage from '@/pages/admin/AdminLoginPage';

import DashboardLayout from '@/components/dashboard/DashboardLayout';
import DashboardHomePage from '@/pages/dashboard/DashboardHomePage';
import WalletPage from '@/pages/dashboard/WalletPage';
import TransactionsPage from '@/pages/dashboard/TransactionsPage';
import TransactionReceiptPage from '@/pages/dashboard/TransactionReceiptPage';
import UserProfilePage from '@/pages/dashboard/UserProfilePage';
import BankDetailsPage from '@/pages/dashboard/BankDetailsPage';
import HistoryPage from '@/pages/dashboard/HistoryPage';
import WithdrawPage from '@/pages/dashboard/WithdrawPage';
import DepositPage from '@/pages/dashboard/DepositPage';
import ChatPage from '@/pages/dashboard/ChatPage';
import ChatListPage from '@/pages/dashboard/ChatListPage';
import NotificationsPage from '@/pages/dashboard/NotificationsPage';
import TaskPage from '@/pages/dashboard/TaskPage';
import SettingsPage from '@/pages/dashboard/SettingsPage';

import AdminLayout from '@/components/admin/AdminLayout';
import AdminDashboardOverviewPage from '@/pages/admin/AdminDashboardOverviewPage';
import AdminUsersManagementPage from '@/pages/admin/AdminUsersManagementPage';
import AdminTransactionsPage from '@/pages/admin/AdminTransactionsPage';
import AdminWithdrawalsPage from '@/pages/admin/AdminWithdrawalsPage';
import AdminInvestmentsPage from '@/pages/admin/AdminInvestmentsPage';
import AdminDepositChatPage from '@/pages/admin/AdminDepositChatPage';
import AdminMarketDataPage from '@/pages/admin/AdminMarketDataPage';
import AdminSettingsPage from '@/pages/admin/AdminSettingsPage';
import AdminChatPage from '@/pages/admin/AdminChatPage';
import AdminAnnouncementsPage from '@/pages/admin/AdminAnnouncementsPage';


console.log("Hostinger Horizons: App.jsx is executing - top level");

const AppContent = () => {
  console.log("Hostinger Horizons: AppContent component is rendering");
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, isAdmin, loading: authLoading } = useAuth();

  useEffect(() => {
    console.log("Hostinger Horizons: AppContent useEffect for Supabase check, authLoading:", authLoading);
    const checkSupabaseConnection = async () => {
      if (authLoading) return; 

      try {
        // Using a more specific query to check if the 'profiles' table exists and is queryable
        // This specific query might require RLS to allow reads for authenticated users,
        // or it might fail if RLS is too strict and no user is logged in.
        // A simple `select 1` is often used for basic connection checks, but this tests table access.
        const { error } = await supabase.from('profiles').select('id', { count: 'exact', head: true }).limit(1);

        if (error) {
          if (error.message.includes("relation") && error.message.includes("does not exist")) {
            console.warn('Supabase connection test: "profiles" table does not exist or is not accessible.', error.message);
             toast({
              title: "Database Setup Incomplete",
              description: `The 'profiles' table seems to be missing. Please ensure migrations ran.`,
              variant: "destructive",
              duration: 10000,
            });
          } else if (error.code === '42501' || error.message.includes("permission denied")) {
             console.warn('Supabase connection test: RLS permission denied for "profiles" table.', error.message);
             toast({
              title: "Database Access Issue",
              description: `Permission denied for 'profiles' table. Check RLS policies.`,
              variant: "destructive",
              duration: 10000,
            });
          } else {
            console.error('Supabase connection error:', error);
            toast({
              title: "Supabase Connection Error",
              description: `Failed to query Supabase: ${error.message}`,
              variant: "destructive",
              duration: 7000,
            });
          }
        } else {
          console.log('Supabase connected successfully and test query on profiles successful.');
          if ((user || isAdmin) && (sessionStorage.getItem('supabaseConnectionToastShown') !== 'true')) { 
            toast({
              title: "Supabase Connected!",
              description: "Successfully connected to your Trading/Investment project database.",
              duration: 5000,
            });
            sessionStorage.setItem('supabaseConnectionToastShown', 'true');
          }
        }
      } catch (e) {
        console.error('Supabase client initialization or network error:', e);
        toast({
          title: "Supabase Initialization Failed",
          description: "Could not initialize connection to the database. Check network or Supabase status.",
          variant: "destructive",
          duration: 7000,
        });
      }
    };
    
    // Run check once after auth is resolved and user/admin status is known
    if (!authLoading && (user || isAdmin)) { 
        checkSupabaseConnection();
    }
    
  }, [authLoading, user, isAdmin]);

  if (authLoading) {
    console.log("Hostinger Horizons: AppContent rendering 'Initializing App...' because authLoading is true");
    return <div className="flex justify-center items-center min-h-screen bg-background"><p className="text-foreground">Initializing App...</p></div>;
  }
  console.log("Hostinger Horizons: AppContent rendering Routes, user:", user, "isAdmin:", isAdmin);

  const ProtectedRoute = ({ children }) => {
    if (authLoading) {
      return <div className="flex justify-center items-center min-h-screen bg-background"><p className="text-foreground">Loading...</p></div>;
    }
    if (!user) return <Navigate to="/login" />;
    if (isAdmin) return <Navigate to="/admin/dashboard" />; // If admin tries to access user dashboard, redirect to admin
    return children;
  };
  
  const AdminProtectedRoute = ({ children }) => {
    if (authLoading) {
      return <div className="flex justify-center items-center min-h-screen bg-background"><p className="text-foreground">Loading...</p></div>;
    }
    // For "Company Access" code login, user object might be null. Check isAdmin flag.
    return isAdmin ? children : <Navigate to="/admin/login" />;
  };

  const PublicRoute = ({ children }) => {
    if (authLoading) {
      return <div className="flex justify-center items-center min-h-screen bg-background"><p className="text-foreground">Loading...</p></div>;
    }
    if (isAdmin) return <Navigate to="/admin/dashboard" />;
    return !user ? children : <Navigate to="/dashboard" />;
  };

  return (
    <>
      <Toaster />
      <Routes>
        <Route path="/" element={<PublicRoute><HomePage isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} /></PublicRoute>} />
        <Route path="/login" element={<PublicRoute><LoginPage /></PublicRoute>} />
        <Route path="/register" element={<PublicRoute><RegisterPage /></PublicRoute>} />
        <Route path="/forgot-password" element={<PublicRoute><ForgotPasswordPage /></PublicRoute>} />
        <Route path="/reset-password" element={<PublicRoute><ResetPasswordPage /></PublicRoute>} />
        <Route path="/admin/login" element={isAdmin ? <Navigate to="/admin/dashboard" /> : <AdminLoginPage />} />
        
        <Route path="/dashboard" element={<ProtectedRoute><DashboardLayout /></ProtectedRoute>}>
          <Route index element={<DashboardHomePage />} />
          <Route path="wallet" element={<WalletPage />} />
          <Route path="transactions" element={<TransactionsPage />} />
          <Route path="transactions/receipt/:transactionId" element={<TransactionReceiptPage />} />
          <Route path="profile" element={<UserProfilePage />} />
          <Route path="bank-details" element={<BankDetailsPage />} />
          <Route path="history" element={<HistoryPage />} />
          <Route path="withdraw" element={<WithdrawPage />} />
          <Route path="deposit" element={<DepositPage />} />
          <Route path="chat" element={<ChatListPage />} />
          <Route path="chat/:sessionId" element={<ChatPage />} />
          <Route path="chat/new-support" element={<ChatPage />} /> 
          <Route path="notifications" element={<NotificationsPage />} />
          <Route path="tasks" element={<TaskPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>

        <Route path="/admin" element={<AdminProtectedRoute><AdminLayout /></AdminProtectedRoute>}>
          <Route path="dashboard" element={<AdminDashboardOverviewPage />} />
          <Route path="users" element={<AdminUsersManagementPage />} />
          <Route path="transactions" element={<AdminTransactionsPage />} />
          <Route path="withdrawals" element={<AdminWithdrawalsPage />} />
          <Route path="investments" element={<AdminInvestmentsPage />} />
          <Route path="deposit-chat" element={<AdminDepositChatPage />} />
          <Route path="deposit-chat/:sessionId" element={<AdminChatPage />} />
          <Route path="announcements" element={<AdminAnnouncementsPage />} />
          <Route path="market-data" element={<AdminMarketDataPage />} />
          <Route path="settings" element={<AdminSettingsPage />} />
        </Route>

        <Route path="*" element={<Navigate to={isAdmin ? "/admin/dashboard" : (user ? "/dashboard" : "/")} />} />
      </Routes>
    </>
  );
};

const App = () => {
  console.log("Hostinger Horizons: App component is rendering");
  useEffect(() => {
    // Clear the flag on initial app load so toast can show again after a full refresh
    sessionStorage.removeItem('supabaseConnectionToastShown');
  }, []);
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
};

export default App;