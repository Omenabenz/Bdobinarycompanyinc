import React, { createContext, useState, useEffect, useContext } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';

const AuthContext = createContext(null);
console.log("Hostinger Horizons: AuthContext.jsx is executing - top level");

const ADMIN_ACCESS_CODE = "BDOADMIN"; // Hardcoded admin access code

export const AuthProvider = ({ children }) => {
  console.log("Hostinger Horizons: AuthProvider component is rendering");
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const logUserActivity = async (userId, actionType, description) => {
    const currentUserId = isAdmin && !userId ? 'ADMIN_ACTION' : userId;
    if (!currentUserId) return; 
    try {
      await supabase.from('user_activity_log').insert({
        user_id: currentUserId,
        action_type: actionType,
        description: description,
      });
    } catch (error) {
      console.warn("Failed to log user activity:", error.message);
    }
  };

  useEffect(() => {
    console.log("Hostinger Horizons: AuthProvider useEffect for auth state is running");
    setLoading(true);

    const getSessionAndProfile = async () => {
      console.log("Hostinger Horizons: AuthProvider getSessionAndProfile called");
      try {
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        if (sessionError) {
          console.error("Error getting session:", sessionError.message);
          toast({ title: "Auth Error", description: "Failed to retrieve session.", variant: "destructive" });
          setUser(null); setProfile(null); setIsAdmin(false);
          localStorage.removeItem('isAdminAccessGranted');
          return;
        }
        
        console.log("Hostinger Horizons: AuthProvider getSessionAndProfile success, session user:", session?.user);
        setUser(session?.user ?? null);

        if (session?.user) {
          await fetchProfileLogic(session.user.id); // fetchProfileLogic will handle isAdmin based on role
        } else {
          setProfile(null);
          // Check for persisted admin access code login
          const persistedAdminAccess = localStorage.getItem('isAdminAccessGranted');
          if (persistedAdminAccess === 'true') {
            setIsAdmin(true);
            console.log("Persisted admin access restored (no Supabase session).");
          } else {
            setIsAdmin(false);
          }
        }
      } catch (e) {
        console.error("Exception in getSessionAndProfile:", e.message);
        toast({ title: "Auth Init Error", description: "An issue occurred during session retrieval.", variant: "destructive" });
        setUser(null); setProfile(null); setIsAdmin(false);
        localStorage.removeItem('isAdminAccessGranted');
      } finally {
        console.log("Hostinger Horizons: AuthProvider getSessionAndProfile finally block, setting loading to false");
        setLoading(false);
      }
    };

    getSessionAndProfile();

    const { data: authListener } = supabase.auth.onAuthStateChange(async (_event, session) => {
      console.log("Hostinger Horizons: AuthProvider onAuthStateChange triggered, event:", _event, "session user:", session?.user);
      setLoading(true);
      try {
        const currentUser = session?.user ?? null;
        setUser(currentUser);

        if (currentUser) {
          await fetchProfileLogic(currentUser.id); // This will set profile and isAdmin based on role
          if (_event === 'SIGNED_IN') {
            logUserActivity(currentUser.id, 'LOGIN', 'User signed in successfully.');
          }
        } else { // No Supabase user
          setProfile(null);
          // If SIGNED_OUT, explicitly remove admin access unless it was from access code and not cleared by adminLogout
          if (_event === 'SIGNED_OUT') {
            const persistedAdminAccess = localStorage.getItem('isAdminAccessGranted');
            // If admin was logged in via Supabase and signed out, clear isAdmin
            // If admin was via access code, it should remain unless adminLogout was called
            if (!persistedAdminAccess) { // If not from access code, or if adminLogout cleared it
                setIsAdmin(false);
            }
          } else { // Event is not SIGNED_OUT, but no user (e.g. initial load, token cleared by other means)
            const persistedAdminAccess = localStorage.getItem('isAdminAccessGranted');
            setIsAdmin(persistedAdminAccess === 'true');
          }
        }
      } catch (e) {
        console.error("Exception in onAuthStateChange:", e.message);
        toast({ title: "Auth State Error", description: "An issue occurred updating auth state.", variant: "destructive" });
        setUser(null); setProfile(null); setIsAdmin(false); localStorage.removeItem('isAdminAccessGranted');
      } finally {
        console.log("Hostinger Horizons: AuthProvider onAuthStateChange finally block, setting loading to false");
        setLoading(false);
      }
    });

    return () => {
      console.log("Hostinger Horizons: AuthProvider useEffect cleanup - unsubscribing authListener");
      authListener?.unsubscribe();
    };
  }, []);

  const fetchProfileLogic = async (userId) => {
    console.log("Hostinger Horizons: AuthProvider fetchProfileLogic called for userId:", userId);
    if (!userId) {
      setProfile(null);
      // Do not automatically set isAdmin to false here, as admin might be via access code
      // It should be handled by the calling context (getSession or onAuthStateChange)
      return;
    }
    try {
      const { data, error, status } = await supabase
        .from('profiles')
        .select(`full_name, phone_number, avatar_url, bank_name, bank_account_name, bank_account_number, role, status`)
        .eq('id', userId)
        .single();

      if (error && status !== 406) { 
        console.error('Error fetching profile data:', error.message);
        setProfile(null); // Clear profile on error
        setIsAdmin(false); // If profile fetch fails, assume not admin for this Supabase user
        localStorage.removeItem('isAdminAccessGranted'); // Clear persisted admin if tied to this user
        throw error;
      }
      console.log("Hostinger Horizons: AuthProvider fetchProfileLogic success, profile data:", data);
      setProfile(data || null);
      if (data?.role === 'admin') {
        setIsAdmin(true);
        localStorage.setItem('isAdminAccessGranted', 'true'); // Persist admin state if profile confirms it
        console.log("Admin role confirmed via profile fetch for user:", userId);
      } else {
        // If profile exists but not admin, and no access code grant, then not admin.
        const persistedAdminAccessViaCode = localStorage.getItem('isAdminAccessGrantedByCode');
        if (!persistedAdminAccessViaCode) { // Check if admin access was granted by code separately
            setIsAdmin(false);
            localStorage.removeItem('isAdminAccessGranted'); // Clear general admin grant if profile is not admin
        }
      }

    } catch (error) {
      console.error('Error fetching profile:', error.message);
      toast({ title: "Profile Error", description: "Could not fetch user profile.", variant: "destructive" });
      setProfile(null);
      setIsAdmin(false); // Reset admin state on error if not access code admin
      localStorage.removeItem('isAdminAccessGranted');
    }
  };

  const adminLoginWithAccessCode = (accessCode) => {
    if (accessCode === ADMIN_ACCESS_CODE) {
      setIsAdmin(true);
      setUser(null); 
      setProfile(null); 
      localStorage.setItem('isAdminAccessGranted', 'true'); 
      localStorage.setItem('isAdminAccessGrantedByCode', 'true'); // Specific flag for access code
      logUserActivity('ADMIN_ACCESS_CODE_LOGIN', 'ADMIN_LOGIN', 'Admin logged in via access code.');
      toast({ title: "Admin Access Granted", description: "Welcome, Company Administrator!" });
      setLoading(false); // Ensure loading is false after admin login
      return true;
    }
    toast({ title: "Access Denied", description: "Invalid Company Access Code.", variant: "destructive" });
    setLoading(false);
    return false;
  };

  const adminLogout = () => {
    setIsAdmin(false);
    localStorage.removeItem('isAdminAccessGranted');
    localStorage.removeItem('isAdminAccessGrantedByCode');
    if (user) { // If admin was also a Supabase user, sign them out
      supabase.auth.signOut(); 
    } else { // If only access code admin, ensure state is reset
        setUser(null);
        setProfile(null);
        setLoading(false); // Ensure loading is false after admin logout
    }
    logUserActivity('ADMIN_ACCESS_CODE_LOGOUT', 'ADMIN_LOGOUT', 'Admin logged out.');
    toast({ title: "Admin Logged Out", description: "You have logged out from Company Access." });
  };
  
  const sendOtpEmail = async (email, otp) => {
    try {
      const { error } = await supabase.functions.invoke('send-email', {
        body: JSON.stringify({
          to_email: email,
          subject: 'Verify Your Bdounibank Account',
          html_content: `<p>Use this code to verify your login: <strong>${otp}</strong></p><p>Thank you,<br/>Bdounibank</p>`,
        }),
      });
      if (error) throw error;
      toast({ title: 'OTP Sent', description: 'An OTP has been sent to your email.' });
    } catch (error) {
      console.error('Error sending OTP email:', error);
      toast({ title: 'OTP Error', description: 'Could not send OTP email.', variant: 'destructive' });
    }
  };

  const value = {
    user,
    profile,
    isAdmin,
    loading,
    fetchProfile: fetchProfileLogic, // Expose the core logic for external use if needed
    logUserActivity,
    signInWithEmail: async (email, password) => {
        setLoading(true);
        const result = await supabase.auth.signInWithPassword({ email, password });
        // onAuthStateChange will handle setting user, profile, isAdmin, and loading
        return result;
    },
    signUpWithEmail: async (email, password, metadata) => {
      setLoading(true);
      const result = await supabase.auth.signUp({ email, password, options: { data: metadata } });
      // onAuthStateChange will handle setting user, profile, isAdmin, and loading
      return result;
    },
    signInWithGoogle: () => supabase.auth.signInWithOAuth({ provider: 'google' }),
    signInWithFacebook: () => supabase.auth.signInWithOAuth({ provider: 'facebook' }),
    signOut: async () => {
      setLoading(true);
      console.log("Hostinger Horizons: AuthProvider signOut called");
      if(user) await logUserActivity(user.id, 'LOGOUT', 'User signed out.');
      const { error } = await supabase.auth.signOut(); 
      if (error) {
        toast({ title: "Logout Error", description: error.message, variant: "destructive" });
      }
      // State updates (setUser, setProfile, isAdmin to false if not code admin) handled by onAuthStateChange
      // Explicitly set loading false if onAuthStateChange doesn't fire quickly or fails
      // setLoading(false); // onAuthStateChange's finally should handle this.
      return { error };
    },
    adminLoginWithAccessCode,
    adminLogout,
    sendOtpEmail,
  };
  
  console.log("Hostinger Horizons: AuthProvider will render children. Current state: loading:", loading, "isAdmin:", isAdmin, "user:", user?.id);
  
  // Modified loading condition: Show loading only if auth is truly still initializing
  // and not if admin is already determined by localStorage (for access code scenarios).
  if (loading) {
    const persistedAdminAccess = localStorage.getItem('isAdminAccessGranted');
    if (!persistedAdminAccess) { // If not admin via access code, show loading
        return <div className="flex justify-center items-center min-h-screen"><p>Loading Application (AuthProvider)...</p></div>;
    } else if (persistedAdminAccess && !isAdmin) { // Persisted admin, but isAdmin state not yet true
        // This case might be brief as isAdmin should sync quickly.
        // Still, could show loading to prevent flicker.
         return <div className="flex justify-center items-center min-h-screen"><p>Initializing Admin Session...</p></div>;
    }
    // If persistedAdminAccess is true AND isAdmin is true, proceed to render children.
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};