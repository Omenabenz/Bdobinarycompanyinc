import React from 'react';
import { BarChart3, Globe, TrendingUp } from 'lucide-react';

const MarketActivity = () => {
  return (
    <section className="py-16 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Live Market Activity
          </h2>
          <p className="text-lg text-gray-600">Real-time trading data and market trends</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <BarChart3 className="w-6 h-6 mr-3 text-blue-600" />
              Philippine Stock Exchange
            </h3>
            <div className="space-y-4">
              {[
                { symbol: 'PSEi', price: '₱6,847.23', change: '+2.3%', positive: true },
                { symbol: 'BDO', price: '₱142.50', change: '+1.8%', positive: true },
                { symbol: 'BPI', price: '₱98.75', change: '+2.1%', positive: true },
                { symbol: 'SM', price: '₱875.50', change: '+1.5%', positive: true }
              ].map((stock, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-bold text-gray-900">{stock.symbol}</p>
                    <p className="text-2xl font-bold text-blue-600">{stock.price}</p>
                  </div>
                  <div className={`text-right ${stock.positive ? 'text-green-600' : 'text-red-600'}`}>
                    <p className="font-bold">{stock.change}</p>
                    <TrendingUp className="w-5 h-5 ml-auto" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <Globe className="w-6 h-6 mr-3 text-blue-600" />
              Cryptocurrency Market
            </h3>
            <div className="space-y-4">
              {[
                { symbol: 'Bitcoin', price: '$43,250', change: '+5.2%', positive: true },
                { symbol: 'Ethereum', price: '$2,650', change: '+3.8%', positive: true },
                { symbol: 'BNB', price: '$315', change: '+2.1%', positive: true },
                { symbol: 'Cardano', price: '$0.52', change: '+4.5%', positive: true }
              ].map((crypto, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-bold text-gray-900">{crypto.symbol}</p>
                    <p className="text-2xl font-bold text-blue-600">{crypto.price}</p>
                  </div>
                  <div className={`text-right ${crypto.positive ? 'text-green-600' : 'text-red-600'}`}>
                    <p className="font-bold">{crypto.change}</p>
                    <TrendingUp className="w-5 h-5 ml-auto" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MarketActivity;