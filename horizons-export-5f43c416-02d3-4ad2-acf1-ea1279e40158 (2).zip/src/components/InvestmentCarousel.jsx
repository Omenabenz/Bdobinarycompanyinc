import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, DollarSign, Clock, TrendingUp, Zap } from 'lucide-react';

const InvestmentCarousel = ({ handleRegister }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const investmentPlans = [
    { 
      deposit: '₱2,000', 
      payout: '₱15,000', 
      roi: '650%',
      popular: false,
      description: 'Perfect starter plan for new investors'
    },
    { 
      deposit: '₱3,000', 
      payout: '₱25,000', 
      roi: '733%',
      popular: false,
      description: 'Great value for growing your investment'
    },
    { 
      deposit: '₱5,000', 
      payout: '₱55,000', 
      roi: '1000%',
      popular: true,
      description: 'Most popular choice among investors'
    },
    { 
      deposit: '₱10,000', 
      payout: '₱120,000', 
      roi: '1100%',
      popular: false,
      description: 'High returns for serious investors'
    },
    { 
      deposit: '₱20,000', 
      payout: '₱250,000', 
      roi: '1150%',
      popular: false,
      description: 'Premium investment opportunity'
    },
    { 
      deposit: '₱50,000', 
      payout: '₱880,000', 
      roi: '1660%',
      popular: false,
      description: 'Maximum returns for elite investors'
    }
  ];

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === investmentPlans.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? investmentPlans.length - 1 : prevIndex - 1
    );
  };

  const goToSlide = (index) => {
    setCurrentIndex(index);
  };

  return (
    <section id="plans" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Investment Plans to Start Up
          </h2>
          <p className="text-xl text-gray-600 mb-4">
            6–24 hours — guaranteed, no regrets, no excuses, no disappointments and no tricks
          </p>
          <div className="inline-flex items-center bg-gradient-to-r from-green-500 to-green-600 text-white rounded-full px-6 py-3">
            <Zap className="w-5 h-5 mr-2" />
            <span className="font-bold">Every plan is safe. Every payout is real.</span>
          </div>
        </motion.div>

        <div className="relative max-w-6xl mx-auto">
          <div className="overflow-hidden rounded-3xl">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 300 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -300 }}
                transition={{ duration: 0.5, ease: "easeInOut" }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
              >
                {[0, 1, 2].map((offset) => {
                  const planIndex = (currentIndex + offset) % investmentPlans.length;
                  const plan = investmentPlans[planIndex];
                  
                  return (
                    <motion.div
                      key={planIndex}
                      initial={{ opacity: 0, y: 50 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: offset * 0.1 }}
                      className={`relative bg-white rounded-2xl p-8 shadow-2xl border-2 hover:shadow-3xl transition-all duration-300 ${
                        plan.popular 
                          ? 'border-yellow-400 bg-gradient-to-br from-yellow-50 to-orange-50' 
                          : 'border-blue-200 hover:border-blue-300'
                      }`}
                    >
                      {plan.popular && (
                        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                          <div className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-6 py-2 rounded-full text-sm font-bold shadow-lg">
                            🔥 MOST POPULAR
                          </div>
                        </div>
                      )}

                      <div className="text-center">
                        <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 ${
                          plan.popular 
                            ? 'bg-gradient-to-br from-yellow-500 to-orange-600' 
                            : 'bg-gradient-to-br from-blue-600 to-blue-800'
                        }`}>
                          <DollarSign className="w-10 h-10 text-white" />
                        </div>
                        
                        <h3 className="text-2xl font-bold text-gray-900 mb-2">
                          Deposit: {plan.deposit}
                        </h3>
                        
                        <p className="text-sm text-gray-600 mb-6">{plan.description}</p>
                        
                        <div className="mb-6">
                          <p className="text-5xl font-bold text-green-600 mb-2">
                            {plan.payout}
                          </p>
                          <p className="text-sm text-gray-600">Guaranteed Payout</p>
                        </div>
                        
                        <div className={`rounded-xl p-4 mb-6 ${
                          plan.popular 
                            ? 'bg-gradient-to-r from-yellow-500 to-orange-500' 
                            : 'bg-gradient-to-r from-green-500 to-green-600'
                        } text-white`}>
                          <div className="flex items-center justify-center space-x-2">
                            <TrendingUp className="w-5 h-5" />
                            <p className="font-bold text-lg">ROI: {plan.roi}</p>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-center space-x-2 text-sm text-gray-600 mb-6">
                          <Clock className="w-4 h-4" />
                          <span>6-24 Hours Guaranteed</span>
                        </div>
                        
                        <Button 
                          onClick={handleRegister}
                          className={`w-full py-3 text-lg font-bold ${
                            plan.popular 
                              ? 'bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-black' 
                              : 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white'
                          }`}
                        >
                          {plan.popular ? '🚀 Invest Now' : 'Invest Now'}
                        </Button>
                      </div>
                    </motion.div>
                  );
                })}
              </motion.div>
            </AnimatePresence>
          </div>

          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/90 backdrop-blur-sm rounded-full p-3 shadow-lg hover:bg-white transition-all duration-200 z-10"
          >
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>

          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/90 backdrop-blur-sm rounded-full p-3 shadow-lg hover:bg-white transition-all duration-200 z-10"
          >
            <ChevronRight className="w-6 h-6 text-gray-700" />
          </button>

          <div className="flex justify-center mt-8 space-x-2">
            {investmentPlans.map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-3 h-3 rounded-full transition-all duration-200 ${
                  index === currentIndex 
                    ? 'bg-blue-600 w-8' 
                    : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-12"
        >
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-2xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold mb-4">Why Choose Our Investment Plans?</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Clock className="w-6 h-6" />
                </div>
                <p className="font-semibold">Fast Payouts</p>
                <p className="text-sm opacity-90">6-24 hours guaranteed</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <TrendingUp className="w-6 h-6" />
                </div>
                <p className="font-semibold">High Returns</p>
                <p className="text-sm opacity-90">Up to 1660% ROI</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6" />
                </div>
                <p className="font-semibold">Secure Platform</p>
                <p className="text-sm opacity-90">SEC registered & BSP authorized</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default InvestmentCarousel;