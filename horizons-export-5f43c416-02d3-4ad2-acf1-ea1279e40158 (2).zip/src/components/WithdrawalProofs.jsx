import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Users, TrendingUp } from 'lucide-react';

const WithdrawalProofs = ({ currentDate }) => {
  const proofItems = [
    {
      id: 1,
      imageUrl: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/0129f49d10953ac76bbbb444062e4537.jpg',
      altText: 'Filipino investor showing successful withdrawal from BDO Binary Company',
      description: 'Happy Filipino investors showcasing their successful payouts received via mobile banking apps and checks, thanks to BDO Binary Company Inc.',
      caption: 'Success Stories'
    },
    {
      id: 2,
      imageUrl: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/33c74e554a07b63b74660971f55151e0.jpg',
      altText: 'Young Filipino man displaying large payout on Maya app',
      description: 'A young Filipino entrepreneur proudly displays a significant payout of ₱250,000.00 on his Maya app, crediting BDO Binary Company for his financial success.',
      caption: 'Large Payouts'
    },
    {
      id: 3,
      imageUrl: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/e915905b9bff15fae2b950897a3c64cb.jpg',
      altText: 'Group of Filipinos showing their investment earnings on various mobile payment apps',
      description: 'A group of satisfied Filipino clients display their earnings on various mobile payment apps like GCash, Coins.ph, and Maya, all facilitated by BDO Binary Company Inc.',
      caption: 'Consistent Earnings'
    },
    {
      id: 4,
      imageUrl: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/4037446f46a808adad22b44d9631233d.jpg',
      altText: 'Filipina professional attesting to quick profit withdrawal',
      description: 'A Filipina professional shares her positive experience: "BDO Binary Company Inc. helped me withdraw my profits very quickly." Highlighting the platform\'s efficiency.',
      caption: 'Fast Withdrawals'
    }
  ];

  return (
    <section id="proofs" className="py-16 bg-gradient-to-br from-teal-50 via-green-50 to-emerald-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Proof of Successful Payouts
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            See real Filipinos who have successfully withdrawn their earnings from BDO Binary Company. 
            Our commitment is to ensure every client receives their profits, 100% guaranteed. (Information current as of {currentDate})
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {proofItems.map((item, index) => (
            <motion.div
              key={item.id}
              className="bg-white rounded-xl shadow-2xl overflow-hidden group transform transition-all duration-300 hover:shadow-green-200 hover:-translate-y-2"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.15 }}
            >
              <div className="relative">
                <img
                  src={item.imageUrl}
                  alt={item.altText}
                  className="w-full h-80 md:h-96 object-cover transition-transform duration-300 group-hover:scale-105"
                />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                 <div className="absolute bottom-0 left-0 p-6">
                    <h3 className="text-xl font-semibold text-white leading-tight bg-black/50 px-3 py-1 rounded-md">{item.caption}</h3>
                 </div>
              </div>
              <div className="p-6">
                <p className="text-gray-700 text-md mb-4">{item.description}</p>
                <div className="flex items-center text-green-700">
                  <TrendingUp size={20} className="mr-2" />
                  <span className="font-medium">Verified Successful Withdrawal</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <Users className="w-12 h-12 text-green-600 mx-auto mb-3" />
          <p className="text-gray-800 text-lg font-semibold">
            Join thousands of satisfied Filipinos who are building their wealth with BDO Binary Company Inc.
          </p>
          <p className="text-gray-600 mt-1">Your financial success story starts here! (Data as of {currentDate})</p>
        </motion.div>
      </div>
    </section>
  );
};

export default WithdrawalProofs;