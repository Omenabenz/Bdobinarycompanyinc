import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Shield, TrendingUp, Award, Zap, Star, CheckCircle } from 'lucide-react';

const HeroSection = ({ handleRegister }) => {
  return (
    <section id="home" className="relative min-h-screen overflow-hidden">
      <div className="absolute inset-0">
        <img  
          alt="Professional Filipino business team in modern office"
          className="w-full h-full object-cover"
         src="https://images.unsplash.com/photo-1701206069848-312831d2c276" />
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/90 via-blue-800/85 to-blue-700/80"></div>
        <div className="absolute inset-0 bg-black/20"></div>
      </div>

      <div className="relative min-h-screen flex items-center">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-white"
            >
              <div className="mb-6">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="inline-flex items-center bg-white/10 backdrop-blur-sm rounded-full px-6 py-3 mb-6"
                >
                  <Award className="w-5 h-5 mr-2 text-yellow-400" />
                  <span className="text-sm font-medium">SEC Registered & BSP Authorized</span>
                </motion.div>
              </div>

              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight"
              >
                Philippines' Most
                <span className="block bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-500 bg-clip-text text-transparent">
                  Trusted Investment
                </span>
                <span className="block text-white">Platform</span>
              </motion.h1>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="mb-8"
              >
                <p className="text-xl md:text-2xl mb-4 text-blue-100 font-medium">
                  Earn Securely in 6-24 Hours
                </p>
                <p className="text-lg text-blue-200 mb-6">
                  Withdraw and payout directly to your Philippine bank accounts
                </p>
                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center bg-green-500/20 rounded-full px-4 py-2">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-400" />
                    <span>Instant Profits</span>
                  </div>
                  <div className="flex items-center bg-green-500/20 rounded-full px-4 py-2">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-400" />
                    <span>6-24 Hour Payouts</span>
                  </div>
                  <div className="flex items-center bg-green-500/20 rounded-full px-4 py-2">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-400" />
                    <span>50,000+ Verified Clients</span>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="flex flex-col sm:flex-row gap-4"
              >
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    size="lg" 
                    onClick={handleRegister}
                    className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black font-bold px-8 py-4 text-lg shadow-2xl"
                  >
                    <Zap className="mr-2 w-5 h-5" />
                    Start Investing Now
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </motion.div>
                
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    size="lg" 
                    variant="outline"
                    className="border-2 border-white/30 bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 px-8 py-4 text-lg"
                  >
                    View Live Payouts
                  </Button>
                </motion.div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="mt-8 flex items-center space-x-6"
              >
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-xs font-bold">
                      {i}
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center mb-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-sm text-blue-200">Trusted by 50,000+ Filipino investors</p>
                </div>
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="relative"
            >
              <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 shadow-2xl">
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-white mb-2">Live Investment Stats</h3>
                  <p className="text-blue-200">Real-time platform performance</p>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.8, type: "spring" }}
                    className="text-center"
                  >
                    <div className="text-3xl font-bold text-yellow-400 mb-1">₱2.5B+</div>
                    <div className="text-sm text-blue-200">Total Payouts</div>
                  </motion.div>
                  
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.9, type: "spring" }}
                    className="text-center"
                  >
                    <div className="text-3xl font-bold text-green-400 mb-1">99.9%</div>
                    <div className="text-sm text-blue-200">Success Rate</div>
                  </motion.div>
                  
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 1.0, type: "spring" }}
                    className="text-center"
                  >
                    <div className="text-3xl font-bold text-blue-400 mb-1">6-24h</div>
                    <div className="text-sm text-blue-200">Payout Time</div>
                  </motion.div>
                  
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 1.1, type: "spring" }}
                    className="text-center"
                  >
                    <div className="text-3xl font-bold text-purple-400 mb-1">50K+</div>
                    <div className="text-sm text-blue-200">Active Users</div>
                  </motion.div>
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.2 }}
                  className="mt-6 p-4 bg-green-500/20 rounded-xl border border-green-400/30"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-green-400 font-bold">Latest Payout</p>
                      <p className="text-white text-sm">₱280,000 to Maria S.</p>
                    </div>
                    <div className="text-green-400">
                      <CheckCircle className="w-6 h-6" />
                    </div>
                  </div>
                </motion.div>
              </div>

              <div className="absolute -top-4 -right-4 w-20 h-20 bg-yellow-400 rounded-full flex items-center justify-center animate-pulse">
                <TrendingUp className="w-10 h-10 text-black" />
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-20 left-10 floating">
        <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
          <Shield className="w-8 h-8 text-white" />
        </div>
      </div>
      
      <div className="absolute top-20 right-10 floating" style={{ animationDelay: '1s' }}>
        <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
          <Award className="w-8 h-8 text-white" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;