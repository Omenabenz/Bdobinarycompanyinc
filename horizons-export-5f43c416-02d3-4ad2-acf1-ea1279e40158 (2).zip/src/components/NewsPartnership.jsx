import React from 'react';
import { motion } from 'framer-motion';
import { Newspaper } from 'lucide-react';

const NewsPartnership = () => {
  const newsItems = [
    {
      id: 1,
      imageUrl: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/fe711c5ef8d15b23a0a651faee899503.jpg',
      altText: 'BDO and Binary Investment Cooperation Contract Newspaper Clipping',
      title: 'Binary Investment Cooperation Contract with BDO',
      source: 'Philippine Daily Inquirer',
      date: 'Published: May 28, 2025'
    },
    {
      id: 2,
      imageUrl: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/17c57d3d7a66989477432a0650232c9b.jpg',
      altText: 'BDO Binary Company Inc. Financial Opportunity Newspaper Clipping',
      title: 'BDO Binary Company Inc. - A New Financial Opportunity',
      source: 'The Philippine Star',
      date: 'Published: June 02, 2025'
    },
    {
      id: 3,
      imageUrl: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/3734fa3b2819d34c86a6001f8d246c60.jpg',
      altText: 'Nestor Tan BDO CEO Endorsing BDO Binary Company Inc.',
      title: 'BDO CEO Nestor Tan on BDO Binary Company Legitimacy',
      source: 'Manila Bulletin',
      date: 'Published: June 05, 2025'
    },
    {
      id: 4,
      imageUrl: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/a070b29e64ede365706ef01731414a4e.jpg',
      altText: 'BDO Unibank and Binary Investment Partnership Announcement Newspaper Clipping',
      title: 'BDO Unibank & Binary Investment Announce Partnership',
      source: 'BusinessWorld',
      date: 'Published: June 06, 2025'
    }
  ];

  return (
    <section id="news" className="py-16 bg-gradient-to-br from-gray-100 to-gray-200">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <Newspaper className="w-16 h-16 text-blue-700 mx-auto mb-4" />
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            In The News: BDO & Binary Investment Partnership
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Highlighting our strategic alliance with BDO Unibank, as featured in leading Philippine publications. 
            This collaboration underscores our commitment to providing secure and legitimate investment opportunities.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {newsItems.map((item, index) => (
            <motion.div
              key={item.id}
              className="bg-white rounded-xl shadow-2xl overflow-hidden group transform transition-all duration-300 hover:scale-105 hover:shadow-blue-200"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="relative">
                <img
                  src={item.imageUrl}
                  alt={item.altText}
                  className="w-full h-96 object-cover object-top transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
                <div className="absolute bottom-0 left-0 p-6">
                  <h3 className="text-xl font-bold text-white mb-2 leading-tight">{item.title}</h3>
                </div>
              </div>
              <div className="p-6 bg-gray-50">
                <p className="text-sm font-semibold text-blue-700 mb-1">{item.source}</p>
                <p className="text-xs text-gray-500">{item.date}</p>
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          className="text-center mt-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <p className="text-gray-700 text-md">
            These publications affirm the strong and legitimate partnership between BDO Unibank and BDO Binary Company Inc., 
            dedicated to fostering financial growth for Filipinos.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default NewsPartnership;