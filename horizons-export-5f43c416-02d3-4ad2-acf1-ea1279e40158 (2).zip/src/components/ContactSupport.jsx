import React from 'react';
import { Button } from '@/components/ui/button';
import { Mail, Phone, MessageCircle, MapPin, Zap } from 'lucide-react';

const ContactSupport = ({ handleRegister }) => {
  const faqs = [
    {
      question: 'How long does it take to receive my payout?',
      answer: 'All payouts are processed within 6-24 hours guaranteed. Most clients receive their funds within 6-12 hours.'
    },
    {
      question: 'Is BDO Binary Company legitimate?',
      answer: 'Yes, we are fully registered with SEC, DTI, and authorized by BSP. We have official partnership with BDO Unibank.'
    },
    {
      question: 'What banks do you support for payouts?',
      answer: 'We support all major Philippine banks including BDO, BPI, Metrobank, UnionBank, and e-wallets like GCash and Maya.'
    },
    {
      question: 'What is the minimum investment amount?',
      answer: 'The minimum investment is ₱2,000 with a guaranteed payout of ₱15,000 within 6-24 hours.'
    },
    {
      question: 'How do I track my investment?',
      answer: 'Once registered, you will receive real-time updates via SMS and email. You can also contact our 24/7 support team.'
    }
  ];

  return (
    <section id="contact" className="py-16 bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Contact & Support
          </h2>
          <p className="text-lg text-gray-600">We're here to help you 24/7</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <div className="space-y-8">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Get in Touch</h3>
              
              <div className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <Mail className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Email Support</p>
                    <p className="text-blue-600">info@bdobinaryinc.net</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <Phone className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Phone Support</p>
                    <p className="text-green-600">+63 917 123 4567</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <MessageCircle className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Live Chat</p>
                    <p className="text-purple-600">Available 24/7</p>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Office Address</p>
                    <p className="text-orange-600">Makati City, Metro Manila, Philippines</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl shadow-xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-4">Business Hours</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Monday - Friday:</span>
                  <span>8:00 AM - 8:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday:</span>
                  <span>9:00 AM - 5:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday:</span>
                  <span>10:00 AM - 4:00 PM</span>
                </div>
              </div>
              <div className="mt-6 p-4 bg-white bg-opacity-20 rounded-lg">
                <p className="text-sm">
                  <strong>Emergency Support:</strong> Available 24/7 for urgent payout inquiries
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-8 lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h3>
              
              <div className="space-y-6">
                {faqs.map((faq, index) => (
                  <div key={index} className="border-b border-gray-200 pb-4">
                    <h4 className="font-bold text-gray-900 mb-2">{faq.question}</h4>
                    <p className="text-gray-600 text-sm">{faq.answer}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-2xl shadow-xl p-8 text-white text-center">
              <Zap className="w-16 h-16 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-4">Ready to Start Earning?</h3>
              <p className="mb-6">Join thousands of successful Filipino investors today!</p>
              <Button 
                onClick={handleRegister}
                className="bg-white text-green-600 hover:bg-gray-100 font-bold px-8 py-3"
              >
                Register Now
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSupport;