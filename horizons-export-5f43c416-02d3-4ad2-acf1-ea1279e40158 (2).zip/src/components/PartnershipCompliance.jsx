import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Building, Award, Shield, CreditCard, Globe } from 'lucide-react';

const PartnershipCompliance = ({ currentDate }) => {
  const legalDocs = [
    {
      icon: <FileText className="w-8 h-8 text-blue-600" />,
      title: 'SEC Registration Certificate',
      description: `Securities and Exchange Commission approved (Issued: ${currentDate})`,
      status: 'Verified',
      certificateImage: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/a8ec952d855ebd0a35f7e43777aab968.jpg' 
    },
    {
      icon: <Building className="w-8 h-8 text-green-600" />,
      title: 'DTI Business Registration',
      description: `Department of Trade and Industry certified (Issued: ${currentDate})`,
      status: 'Active',
      certificateImage: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/8498064bf5d28db4b4fc6a0b34070e3c.jpg'
    },
    {
      icon: <Award className="w-8 h-8 text-purple-600" />,
      title: "Mayor's Business Permit",
      description: `Local government unit authorized (Issued: ${currentDate})`,
      status: 'Current',
      certificateImage: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/a91518d7a2fe9096376990c2339a2fe0.jpg'
    },
    {
      icon: <Shield className="w-8 h-8 text-orange-600" />,
      title: 'Barangay Clearance',
      description: `Community level business clearance (Issued: ${currentDate})`,
      status: 'Valid',
      certificateImage: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/205872b6877f1c14b3d14db402026969.jpg' 
    },
    {
      icon: <CreditCard className="w-8 h-8 text-red-600" />,
      title: 'BSP License',
      description: `Bangko Sentral ng Pilipinas compliance (Issued: ${currentDate})`,
      status: 'Approved',
      certificateImage: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/ea6771b03df9672fcbe6637dcf72a785.jpg'
    },
    {
      icon: <Globe className="w-8 h-8 text-indigo-600" />,
      title: 'BIR Tax Clearance',
      description: `Bureau of Internal Revenue registered (Issued: ${currentDate})`,
      status: 'Compliant',
      certificateImage: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/205872b6877f1c14b3d14db402026969.jpg'
    }
  ];

  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Partnership & Legal Compliance
          </h2>
          <p className="text-lg text-gray-600">Government approved and legally authorized to operate in the Philippines. All documents issued {currentDate}.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <div className="space-y-8">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Official Partnership</h3>
            </div>
            
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-8 shadow-xl">
              <div className="flex items-center justify-center mb-6">
                <img 
                  alt="BDO Partnership ceremony with executives"
                  className="w-full max-w-md rounded-lg shadow-lg"
                  src="https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/16ac87efdbd2fa5e32732ddbbf08363a.jpg" />
              </div>
              <div className="text-center">
                <h4 className="text-xl font-bold text-blue-900 mb-4">
                  Official BDO Unibank Partnership
                </h4>
                <p className="text-gray-700">
                  Authorized investment partner with BDO Unibank, Philippines' largest bank. 
                  This partnership ensures secure transactions and guaranteed payouts for all our clients. (Established: {currentDate})
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-8 shadow-xl">
              <div className="flex items-center justify-center mb-6">
                <img 
                  alt="Filipino executive leadership team of BDO Binary Company Inc."
                  className="w-full max-w-md rounded-lg shadow-lg"
                  src="https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/40956768fcd37049e0da15b857c51e45.jpg" />
              </div>
              <div className="text-center">
                <h4 className="text-xl font-bold text-green-900 mb-4">
                  Executive Leadership Team
                </h4>
                <p className="text-gray-700">
                  Led by experienced financial professionals with over 20 years of combined experience 
                  in investment management and Philippine banking sector.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Legal Documentation (Public View)</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {legalDocs.map((doc, index) => (
                <motion.div
                  key={index}
                  className="bg-white rounded-xl p-4 shadow-lg border-2 border-gray-100 hover-scale group"
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="relative mb-4 aspect-[3/4]">
                    <img 
                      src={doc.certificateImage} 
                      alt={`${doc.title} (Blurred for public view)`} 
                      className="w-full h-full object-contain rounded-md transition-transform duration-300 group-hover:scale-105"
                    />
                     <div className="absolute inset-0 bg-black/10 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <span className="text-white text-sm bg-black/50 px-2 py-1 rounded">Public Preview</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 mt-1">
                      {doc.icon}
                    </div>
                    <div className="flex-grow">
                      <h4 className="text-md font-bold text-gray-900">{doc.title}</h4>
                      <p className="text-gray-500 text-xs">{doc.description}</p>
                    </div>
                  </div>
                  <div className="mt-3 text-right">
                      <span className="bg-green-100 text-green-800 px-2 py-0.5 rounded-full text-xs font-medium">
                        {doc.status}
                      </span>
                    </div>
                </motion.div>
              ))}
            </div>
             <p className="text-xs text-gray-500 text-center mt-4">
              Note: For security and confidentiality, full legal documents are presented in a blurred format for public viewing. Verified copies are available upon request for registered clients and official inquiries.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PartnershipCompliance;