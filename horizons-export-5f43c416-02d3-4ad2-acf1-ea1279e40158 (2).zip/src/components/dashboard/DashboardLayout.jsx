import React, { useState, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { Home, Wallet, Repeat, UserCircle2, Menu as MenuIcon, LogOut, Settings, CheckSquare, Landmark, History as HistoryIcon, Bell, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { formatDistanceToNowStrict } from 'date-fns';

const DashboardLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, profile, signOut } = useAuth();
  const [isSheetOpen, setIsSheetOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);

  useEffect(() => {
    if (!user) return;

    const fetchNotifications = async () => {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(5); // Fetch latest 5 for popover

      if (error) {
        console.error("Error fetching notifications:", error);
      } else {
        setNotifications(data || []);
      }

      const { count, error: countError } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('is_read', false);
      
      if (countError) {
        console.error("Error fetching unread count:", countError);
      } else {
        setUnreadCount(count || 0);
      }
    };

    fetchNotifications();

    const notificationChannel = supabase
      .channel(`notifications:${user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` },
        (payload) => {
          console.log('Notification change received!', payload);
          fetchNotifications(); // Refetch all on change
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(notificationChannel);
    };
  }, [user]);

  const navItems = [
    { path: '/dashboard', icon: Home, label: 'Home' },
    { path: '/dashboard/wallet', icon: Wallet, label: 'Wallet' },
    { path: '/dashboard/transactions', icon: Repeat, label: 'Transact.' },
    { path: '/dashboard/profile', icon: UserCircle2, label: 'Profile' },
  ];

  const menuItems = [
    { path: '/dashboard/profile', icon: UserCircle2, label: 'Profile' },
    { path: '/dashboard/bank-details', icon: Landmark, label: 'Bank Details' },
    { path: '/dashboard/notifications', icon: Bell, label: 'Notifications' },
    { path: '/dashboard/chat', icon: MessageSquare, label: 'Support Chat' },
    { path: '/dashboard/history', icon: HistoryIcon, label: 'Activity History' },
    { path: '/dashboard/tasks', icon: CheckSquare, label: 'Tasks' },
    { path: '/dashboard/settings', icon: Settings, label: 'Settings' },
  ];

  const handleLogout = async () => {
    setIsSheetOpen(false);
    try {
      await signOut();
      toast({ title: "Logged Out", description: "You have been successfully logged out." });
      navigate('/login'); 
    } catch (error) {
      toast({ title: "Logout Failed", description: error.message, variant: "destructive" });
    }
  };
  
  const getInitials = (name) => {
    if (!name) return user?.email?.[0]?.toUpperCase() || 'U';
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  const handleNotificationClick = async (notification) => {
    setIsPopoverOpen(false); // Close popover
    if (!notification.is_read) {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notification.id);
      if (error) console.error("Error marking notification as read:", error);
      else setUnreadCount(prev => Math.max(0, prev -1));
    }
    if (notification.link_to) {
      navigate(notification.link_to);
    } else {
      navigate('/dashboard/notifications');
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      {/* Header for Mobile & Tablet */}
      <header className="bg-white shadow-sm p-3 sm:p-4 flex justify-between items-center sticky top-0 z-40">
        <div className="flex items-center space-x-3">
          <Avatar className="h-9 w-9 sm:h-10 sm:w-10">
            <AvatarImage src={profile?.avatar_url || undefined} alt={profile?.full_name || user?.email} />
            <AvatarFallback>{getInitials(profile?.full_name || user?.email)}</AvatarFallback>
          </Avatar>
          <div className="md:hidden"> {/* Greetings only on mobile/tablet header if needed */}
            <h1 className="text-sm sm:text-md font-semibold text-gray-800">Hi, {profile?.full_name ? profile.full_name.split(' ')[0] : 'User'}</h1>
            {/* <p className="text-xs text-gray-500">Welcome Back!</p> */}
          </div>
        </div>
        <div className="flex items-center space-x-2 sm:space-x-3">
          <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" className="relative text-gray-700">
                <Bell className="h-5 w-5 sm:h-6 sm:w-6" />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 block h-2.5 w-2.5 transform -translate-y-1/2 translate-x-1/2 rounded-full bg-red-500 ring-2 ring-white" />
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0">
              <div className="p-4 border-b">
                <h4 className="font-medium text-gray-800">Notifications</h4>
                {unreadCount > 0 && <p className="text-xs text-blue-600">{unreadCount} new</p>}
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.length === 0 ? (
                  <p className="text-sm text-gray-500 p-4 text-center">No new notifications.</p>
                ) : (
                  notifications.map(notif => (
                    <div
                      key={notif.id}
                      onClick={() => handleNotificationClick(notif)}
                      className={`p-3 border-b last:border-b-0 hover:bg-gray-50 cursor-pointer ${!notif.is_read ? 'bg-blue-50' : ''}`}
                    >
                      <p className={`text-sm font-medium ${!notif.is_read ? 'text-gray-800' : 'text-gray-700'}`}>{notif.message}</p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {formatDistanceToNowStrict(new Date(notif.created_at), { addSuffix: true })}
                      </p>
                    </div>
                  ))
                )}
              </div>
              <div className="p-2 border-t">
                <Button variant="link" size="sm" className="w-full text-blue-600" asChild>
                  <Link to="/dashboard/notifications" onClick={() => setIsPopoverOpen(false)}>View All Notifications</Link>
                </Button>
              </div>
            </PopoverContent>
          </Popover>

          <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-gray-700">
                <MenuIcon className="h-6 w-6 sm:h-7 sm:w-7" /> 
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] bg-slate-800 text-white p-0 flex flex-col">
              <SheetHeader className="p-6 border-b border-slate-700 flex flex-row items-center space-x-3">
                 <Avatar className="h-10 w-10">
                  <AvatarImage src={profile?.avatar_url || undefined} alt={profile?.full_name || user?.email} />
                  <AvatarFallback className="bg-blue-500 text-white">{getInitials(profile?.full_name || user?.email)}</AvatarFallback>
                </Avatar>
                <div>
                  <SheetTitle className="text-lg text-white text-left">{profile?.full_name || "Menu"}</SheetTitle>
                  <p className="text-xs text-slate-300 text-left">{user?.email}</p>
                </div>
              </SheetHeader>
              <nav className="flex-grow p-4 space-y-1 overflow-y-auto">
                {menuItems.map((item) => (
                  <SheetClose asChild key={item.path}>
                    <Link
                      to={item.path}
                      className={`flex items-center space-x-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors
                                  ${location.pathname === item.path || (item.path.includes('notifications') && location.pathname.includes('notifications')) || (item.path.includes('chat') && location.pathname.includes('chat')) ? 'bg-blue-600 text-white' : 'text-slate-200 hover:bg-slate-700 hover:text-white'}`}
                    >
                      <item.icon className="h-5 w-5" />
                      <span>{item.label}</span>
                    </Link>
                  </SheetClose>
                ))}
              </nav>
              <div className="p-4 border-t border-slate-700">
                <Button
                  onClick={handleLogout}
                  variant="ghost"
                  className="w-full flex items-center space-x-3 justify-start text-slate-200 hover:bg-red-600 hover:text-white"
                >
                  <LogOut className="h-5 w-5" />
                  <span>Logout</span>
                </Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      <main className="flex-grow overflow-y-auto pb-20 md:pb-0">
        {/* Desktop Header content (greetings) now inside DashboardHomePage */}
        <Outlet />
      </main>

      {/* Bottom Navigation for Mobile */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-top-md md:hidden z-40">
        <div className="flex justify-around items-center h-16">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center justify-center space-y-1 p-2 rounded-lg transition-colors w-1/4
                          ${location.pathname === item.path ? 'text-blue-600' : 'text-gray-500 hover:text-blue-500'}`}
            >
              <item.icon className="h-6 w-6" />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
};

export default DashboardLayout;