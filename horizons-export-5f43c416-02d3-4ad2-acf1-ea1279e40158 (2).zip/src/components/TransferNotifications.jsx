import React from 'react';
import { motion } from 'framer-motion';
import { Mail, MessageCircle } from 'lucide-react';

const TransferNotifications = () => {
  const notifications = [
    {
      type: 'SMS',
      bank: 'GCash',
      message: 'You have received P85,000.00 from BDO BINARY COMPANY INC. Your new balance is P125,450.00. Ref: GC240112345',
      time: '2 minutes ago'
    },
    {
      type: 'Email',
      bank: 'BDO Online',
      message: 'Dear Valued Client, Your account has been credited with PHP 150,000.00 from BDO Binary Company Inc. Transaction successful.',
      time: '5 minutes ago'
    },
    {
      type: 'SMS',
      bank: 'Maya',
      message: 'Hi! You received P95,000.00 from BDO BINARY COMPANY. Available balance: P145,230.00. Thank you for using Maya!',
      time: '8 minutes ago'
    },
    {
      type: 'Email',
      bank: 'BPI Online',
      message: 'Transaction Alert: Credit of PHP 120,000.00 to your account from BDO Binary Company Inc has been processed successfully.',
      time: '12 minutes ago'
    },
    {
      type: 'SMS',
      bank: 'UnionBank',
      message: 'UB Alert: Your account was credited P200,000.00 from BDO BINARY COMPANY INC. New balance: P285,750.00',
      time: '15 minutes ago'
    },
    {
      type: 'Email',
      bank: 'Metrobank',
      message: 'Dear Client, Your Metrobank account has received a credit of PHP 75,000.00 from BDO Binary Company Inc. Transaction completed.',
      time: '18 minutes ago'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Live Transfer Notifications
          </h2>
          <p className="text-lg text-gray-600">Real-time bank and wallet credit alerts from our clients</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {notifications.map((notification, index) => (
            <motion.div
              key={index}
              className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-6 shadow-lg hover-scale"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  {notification.type === 'SMS' ? (
                    <MessageCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <Mail className="w-5 h-5 text-blue-600" />
                  )}
                  <span className="font-bold text-gray-900">{notification.type}</span>
                </div>
                <span className="text-sm text-gray-500">{notification.time}</span>
              </div>
              
              <div className="mb-3">
                <p className="font-bold text-blue-600">{notification.bank}</p>
              </div>
              
              <div className="bg-white rounded-lg p-4 border-l-4 border-green-500">
                <p className="text-sm text-gray-700">{notification.message}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TransferNotifications;