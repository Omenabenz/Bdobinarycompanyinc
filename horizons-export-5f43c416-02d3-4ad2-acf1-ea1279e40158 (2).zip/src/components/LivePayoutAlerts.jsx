import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle } from 'lucide-react';

const LivePayoutAlerts = () => {
  const payoutData = [
    { bank: 'GCash', amount: '₱25,000', name: 'Maria A.', time: '2 minutes ago', logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/60d6bc3cebd4e6cca26c15d859fe07be.png' },
    { bank: 'BDO Bank', amount: '₱280,000', name: 'Ramos L.', time: 'just now', logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/5968c3a84ee2324918fc85408b7968b2.png' },
    { bank: 'Maya', amount: '₱120,000', name: 'Emily G.', time: '1 minute ago', logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/d7d3f02134ec15a75bf02a33dc6912e7.png' },
    { bank: 'BPI', amount: '₱95,000', name: 'Carlos M.', time: '3 minutes ago', logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/8931832db4847ef5cf4954be38b2934f.png' },
    { bank: 'UnionBank', amount: '₱180,000', name: 'Ana S.', time: '2 minutes ago', logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/d4ecdcc0502eb0cba9117b9f42a54309.png' },
    { bank: 'Metrobank', amount: '₱65,000', name: 'Jose R.', time: '4 minutes ago', logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/2684066ab58a299e2c1c30f316a1e622.png' }
  ];

  return (
    <section id="payouts" className="py-16 bg-gradient-to-r from-green-50 to-emerald-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            🔴 LIVE PAYOUT ALERTS
          </h2>
          <p className="text-lg text-gray-600">Real-time payouts happening right now!</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-2xl p-8 overflow-hidden">
            <div className="h-96 overflow-hidden relative">
              <div className="payout-scroll space-y-4">
                {[...payoutData, ...payoutData, ...payoutData].map((payout, index) => (
                  <motion.div
                    key={index}
                    className="flex items-center justify-between p-4 bg-gradient-to-r from-green-100 to-emerald-100 rounded-lg border-l-4 border-green-500"
                    initial={{ opacity: 0, x: -50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <div className="flex items-center space-x-4">
                      <img src={payout.logo} alt={`${payout.bank} logo`} className="w-10 h-10 object-contain" />
                      <div>
                        <p className="font-bold text-green-800">
                          {payout.amount} sent to {payout.name}
                        </p>
                        <p className="text-sm text-gray-600">
                          via {payout.bank} • {payout.time}
                        </p>
                      </div>
                    </div>
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LivePayoutAlerts;