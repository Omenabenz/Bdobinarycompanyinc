import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Users, ListChecks, TrendingDown, BarChart3, MessageSquare as MessageSquareText, Cog, LogOut, ShieldAlert, Menu, X, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';

const AdminLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { adminLogout, user, profile } = useAuth(); // user and profile might be null if admin logged in via access code
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); // For mobile

  const adminNavItems = [
    { path: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard Overview' },
    { path: '/admin/users', icon: Users, label: 'Users Management' },
    { path: '/admin/transactions', icon: ListChecks, label: 'Transactions' },
    { path: '/admin/withdrawals', icon: TrendingDown, label: 'Withdrawals' },
    { path: '/admin/investments', icon: BarChart3, label: 'Investments' },
    { path: '/admin/deposit-chat', icon: MessageSquareText, label: 'Deposit Chat' },
    { path: '/admin/market-data', icon: ShieldAlert, label: 'Market Data' }, // Using ShieldAlert as placeholder
    { path: '/admin/settings', icon: Cog, label: 'Settings' },
  ];

  const handleAdminLogout = async () => {
    try {
      await adminLogout();
      navigate('/admin/login');
    } catch (error) {
      toast({ title: "Logout Failed", description: error.message, variant: "destructive" });
    }
  };

  const getPageTitle = () => {
    const currentNavItem = adminNavItems.find(item => location.pathname.startsWith(item.path));
    return currentNavItem ? currentNavItem.label : 'Admin Panel';
  };
  
  const getAdminInitials = () => {
    if (user && profile?.full_name) return profile.full_name.split(' ').map(n=>n[0]).join('').toUpperCase();
    if (user && user.email) return user.email[0].toUpperCase();
    return 'A'; // Default for access code login
  }

  return (
    <div className="flex h-screen bg-slate-100">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-slate-200 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out md:relative md:translate-x-0 md:flex md:flex-col`}>
        <div className="flex items-center justify-between h-16 px-6 border-b border-slate-700">
          <Link to="/admin/dashboard" className="text-2xl font-bold text-white">ADMIN</Link>
          <Button variant="ghost" size="icon" className="md:hidden text-slate-300 hover:text-white" onClick={() => setIsSidebarOpen(false)}>
            <X className="h-6 w-6" />
          </Button>
        </div>
        <nav className="flex-grow p-4 space-y-1 overflow-y-auto">
          {adminNavItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setIsSidebarOpen(false)}
              className={`flex items-center space-x-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors
                          ${location.pathname.startsWith(item.path) ? 'bg-blue-600 text-white shadow-md' : 'hover:bg-slate-700 hover:text-white'}`}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-700">
          <Button
            onClick={handleAdminLogout}
            variant="ghost"
            className="w-full flex items-center space-x-3 justify-start text-slate-300 hover:bg-red-600 hover:text-white"
          >
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm h-16 flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" className="md:hidden mr-3 text-slate-600" onClick={() => setIsSidebarOpen(true)}>
              <Menu className="h-6 w-6" />
            </Button>
            <h1 className="text-xl font-semibold text-slate-800">{getPageTitle()}</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input type="search" placeholder="Search..." className="pl-10 pr-4 py-2 h-9 text-sm rounded-md border-slate-300 focus:border-blue-500 focus:ring-blue-500" />
            </div>
            <Avatar className="h-9 w-9 cursor-pointer">
              <AvatarImage src={user && profile?.avatar_url ? profile.avatar_url : undefined} alt="Admin" />
              <AvatarFallback className="bg-blue-500 text-white font-semibold">{getAdminInitials()}</AvatarFallback>
            </Avatar>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-100 p-6">
          <Outlet />
        </main>
      </div>
      {isSidebarOpen && <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={() => setIsSidebarOpen(false)}></div>}
    </div>
  );
};

export default AdminLayout;