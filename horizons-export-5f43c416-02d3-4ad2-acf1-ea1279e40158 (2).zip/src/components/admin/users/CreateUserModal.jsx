import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

const userRoles = ['user', 'admin'];

const CreateUserModal = ({ isOpen, onClose, onUserCreated }) => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState('user');

  const handleCreateUser = async () => {
    if (!email.trim() || !password.trim() || !fullName.trim()) {
      toast({ title: "Missing Fields", description: "Please fill all required fields.", variant: "destructive"});
      return;
    }
    if (password.length < 6) {
      toast({ title: "Weak Password", description: "Password must be at least 6 characters.", variant: "destructive"});
      return;
    }
    setLoading(true);
    try {
      // Step 1: Sign up the user using client-side Supabase.
      // This does NOT automatically confirm the email or set the role from metadata for auth.users.
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: email,
        password: password,
        options: {
          // user_metadata is for the auth.users table, but role/status are better managed in profiles.
          // We'll pass full_name here, which might be picked up by a trigger if one exists for profiles.
          data: { 
            full_name: fullName 
            // Note: Supabase client-side signUp options.data does not directly set `role` in `auth.users`.
            // `role` is typically a custom claim or a field in your public `profiles` table.
          }
        }
      });

      if (signUpError) {
        // Check if error is due to user already registered but unconfirmed
        if (signUpError.message.includes("User already registered")) {
           toast({ title: "User Exists", description: "This email is already registered. If unconfirmed, an admin might need to resend confirmation or manually verify.", variant: "default" });
        } else {
          throw signUpError;
        }
      }
      
      const newUserId = signUpData?.user?.id;

      if (!newUserId) {
        // If user already exists and is confirmed, signUpData.user might be null but signUpData.session might exist.
        // Or if user exists but unconfirmed, signUpData.user will have the user object.
        // This part can be tricky depending on Supabase's exact response for existing users.
        // For now, if no new user ID, assume an issue or existing user.
        if (!signUpError) { // If no signUpError but no newUserId, it's an edge case.
            toast({ title: "User Creation Issue", description: "User might already exist or an unknown issue occurred.", variant: "destructive" });
            setLoading(false);
            return;
        }
      }
      
      // Step 2: Call the Edge Function to confirm the user and set up their profile.
      // This is crucial for making the user active without email verification.
      if (newUserId) {
        const { data: confirmationData, error: confirmationError } = await supabase.functions.invoke('confirm-user-by-admin', {
          body: JSON.stringify({ 
            user_id: newUserId,
            email: email,
            full_name: fullName,
            role: role
          }),
        });

        if (confirmationError) {
          console.error("Edge function error details:", confirmationError);
          // Attempt to delete the partially created user if confirmation fails
          // This requires admin privileges on the client, which is not typical or secure.
          // Better to handle this cleanup manually in Supabase if needed.
          // await supabase.auth.admin.deleteUser(newUserId); // This won't work client-side without service_role
          throw new Error(`Failed to confirm user via Edge Function: ${confirmationError.message}. User auth record might be created but unconfirmed/profile incomplete.`);
        }
        console.log("Edge function success:", confirmationData);
        toast({ title: "User Created & Verified", description: `Account for ${email} created and automatically verified.` });
      } else if (!signUpError) {
        // This case means user likely already existed and was confirmed.
        // We might want to just update their profile role if needed.
        // For simplicity, we'll assume admin wants to create a NEW user.
        // If an existing user was returned by signUp, their profile might need manual admin adjustment.
         toast({ title: "User Exists", description: "This email is already registered and confirmed.", variant: "default" });
      }


      onUserCreated(); // Refresh the user list
      onClose(); // Close modal
      // Reset form
      setEmail(''); setPassword(''); setFullName(''); setRole('user');
    } catch (error) {
      console.error("Full error in handleCreateUser:", error);
      toast({ title: "User Creation Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New User</DialogTitle>
          <DialogDescription>
            Enter details for the new user account. The account will be automatically verified.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="create-fullName">Full Name</Label>
            <Input id="create-fullName" placeholder="John Doe" value={fullName} onChange={e => setFullName(e.target.value)} disabled={loading} />
          </div>
          <div>
            <Label htmlFor="create-email">Email Address</Label>
            <Input id="create-email" type="email" placeholder="user@example.com" value={email} onChange={e => setEmail(e.target.value)} disabled={loading} />
          </div>
          <div>
            <Label htmlFor="create-password">Password</Label>
            <Input id="create-password" type="password" placeholder="Minimum 6 characters" value={password} onChange={e => setPassword(e.target.value)} disabled={loading} />
          </div>
          <div>
            <Label htmlFor="create-role">Role</Label>
            <Select value={role} onValueChange={setRole} disabled={loading}>
              <SelectTrigger id="create-role"><SelectValue placeholder="Select role" /></SelectTrigger>
              <SelectContent>
                {userRoles.map(r => <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline" disabled={loading}>Cancel</Button></DialogClose>
          <Button onClick={handleCreateUser} disabled={loading || !email || !password || !fullName}>
            {loading ? 'Creating...' : 'Create User'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CreateUserModal;