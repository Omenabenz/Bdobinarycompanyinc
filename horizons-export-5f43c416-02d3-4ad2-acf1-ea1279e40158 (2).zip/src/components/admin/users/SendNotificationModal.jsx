import React, { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input'; // Added for optional link
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select'; // Added for notification type

const notificationTypes = [
  { value: 'general_info', label: 'General Info' },
  { value: 'account_update', label: 'Account Update' },
  { value: 'important_notice', label: 'Important Notice' },
  { value: 'promotion', label: 'Promotion' },
];

const SendNotificationModal = ({ isOpen, onClose, user }) => {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [linkTo, setLinkTo] = useState('');
  const [type, setType] = useState('general_info');


  const handleSendNotification = async () => {
    if (!user || !message.trim()) {
      toast({ title: "Missing Information", description: "Please provide a message for the notification.", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase
        .from('notifications')
        .insert({
          user_id: user.id,
          type: type, // Admin can choose type
          message: message,
          link_to: linkTo || null, // Optional link
          is_read: false
        });
      
      if (error) throw error;
      toast({ title: "Notification Sent", description: `Notification sent to ${user.full_name || user.email}.` });
      onClose(); // Close modal
      setMessage('');
      setLinkTo('');
      setType('general_info');
    } catch (error) {
      toast({ title: "Failed to Send Notification", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };
  
  if (!user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Send Notification to: {user.full_name || user.email}</DialogTitle>
          <DialogDescription>Compose a direct message that will appear in the user's notification panel.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="notification-type">Notification Type</Label>
             <Select id="notification-type" value={type} onValueChange={setType} disabled={loading}>
              <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
              <SelectContent>
                {notificationTypes.map(nt => (
                  <SelectItem key={nt.value} value={nt.value}>{nt.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="notification-message">Message</Label>
            <Textarea 
              id="notification-message"
              placeholder="Enter your notification message here..." 
              value={message} 
              onChange={e => setMessage(e.target.value)} 
              rows={4}
              disabled={loading} 
            />
          </div>
           <div>
            <Label htmlFor="notification-link">Optional Link (e.g., /dashboard/settings)</Label>
            <Input 
              id="notification-link"
              placeholder="/dashboard/some-page" 
              value={linkTo} 
              onChange={e => setLinkTo(e.target.value)} 
              disabled={loading} 
            />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline" disabled={loading}>Cancel</Button></DialogClose>
          <Button onClick={handleSendNotification} disabled={loading || !message.trim()}>
            {loading ? 'Sending...' : 'Send Notification'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SendNotificationModal;