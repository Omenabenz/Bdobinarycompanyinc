import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

const userRoles = ['user', 'admin'];
const userStatuses = ['active', 'suspended', 'pending_verification'];

const EditUserModal = ({ isOpen, onClose, user, onUserUpdated }) => {
  const [loading, setLoading] = useState(false);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState(''); // Email is usually not editable for auth user, display only
  const [role, setRole] = useState('');
  const [status, setStatus] = useState('');

  useEffect(() => {
    if (user) {
      setFullName(user.full_name || '');
      setEmail(user.email || '');
      setRole(user.role || 'user');
      setStatus(user.status || 'active');
    }
  }, [user]);

  const handleSaveChanges = async () => {
    if (!user) return;
    if (!fullName.trim()) {
        toast({ title: "Full Name Required", description: "Please enter user's full name.", variant: "destructive"});
        return;
    }
    setLoading(true);
    try {
      const updates = {
        full_name: fullName,
        role: role,
        status: status,
        updated_at: new Date().toISOString(),
      };
      // Note: Email changes for auth.users are complex and usually involve confirmation.
      // Here we are only updating the 'profiles' table.
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);
      
      if (error) throw error;
      toast({ title: "User Updated", description: "User details saved successfully." });
      onUserUpdated(); // Refresh list
      onClose(); // Close modal
    } catch (error) {
      toast({ title: "Update Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  if (!user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit User: {user.full_name || user.email}</DialogTitle>
          <DialogDescription>ID: {user.id}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="edit-fullName">Full Name</Label>
            <Input id="edit-fullName" value={fullName} onChange={e => setFullName(e.target.value)} disabled={loading} />
          </div>
          <div>
            <Label htmlFor="edit-email">Email (Display Only)</Label>
            <Input id="edit-email" value={email} disabled className="bg-slate-100 cursor-not-allowed" />
          </div>
          <div>
            <Label htmlFor="edit-role">Role</Label>
            <Select value={role} onValueChange={setRole} disabled={loading}>
              <SelectTrigger id="edit-role"><SelectValue placeholder="Select role" /></SelectTrigger>
              <SelectContent>
                {userRoles.map(r => <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="edit-status">Status</Label>
            <Select value={status} onValueChange={setStatus} disabled={loading}>
              <SelectTrigger id="edit-status"><SelectValue placeholder="Select status" /></SelectTrigger>
              <SelectContent>
                {userStatuses.map(s => <SelectItem key={s} value={s} className="capitalize">{s.replace(/_/g, ' ')}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline" disabled={loading}>Cancel</Button></DialogClose>
          <Button onClick={handleSaveChanges} disabled={loading || !fullName.trim()}>
            {loading ? 'Saving...' : 'Save Changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EditUserModal;