import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

const AdjustBalanceModal = ({ isOpen, onClose, user, onBalanceAdjusted }) => {
  const [loading, setLoading] = useState(false);
  const [balanceAction, setBalanceAction] = useState('credit');
  const [balanceAmount, setBalanceAmount] = useState('');
  const [balanceReason, setBalanceReason] = useState('');
  const [currentBalance, setCurrentBalance] = useState(0);

  useEffect(() => {
    if (user && user.user_balances && user.user_balances.length > 0) {
      setCurrentBalance(user.user_balances[0].current_balance || 0);
    } else if (user) { // If user_balances array is empty or not present, fetch it
        const fetchBalance = async () => {
            const {data, error} = await supabase.from('user_balances').select('current_balance').eq('user_id', user.id).single();
            if(data) setCurrentBalance(data.current_balance || 0);
            else setCurrentBalance(0); // Default to 0 if not found
        }
        fetchBalance();
    }
  }, [user]);

  const handleAdjustBalance = async () => {
    if (!user || !balanceAmount || isNaN(parseFloat(balanceAmount)) || !balanceReason.trim()) {
      toast({ title: "Invalid Input", description: "Please provide a valid amount and reason.", variant: "destructive" });
      return;
    }
    setLoading(true);
    const amount = parseFloat(balanceAmount);
    const newBalance = balanceAction === 'credit' 
      ? currentBalance + amount 
      : currentBalance - amount;

    if (balanceAction === 'debit' && newBalance < 0) {
      toast({ title: "Insufficient Balance", description: "Debit amount exceeds user's current balance.", variant: "destructive" });
      setLoading(false);
      return;
    }

    try {
      // Update user_balances
      const { error: balanceError } = await supabase
        .from('user_balances')
        .update({ current_balance: newBalance, last_updated: new Date().toISOString() })
        .eq('user_id', user.id);
      if (balanceError) throw balanceError;

      // Create a transaction record
      const { error: transactionError } = await supabase
        .from('transactions')
        .insert({
          user_id: user.id,
          type: balanceAction === 'credit' ? 'admin_credit' : 'admin_debit',
          amount: balanceAction === 'credit' ? amount : -amount,
          status: 'completed',
          description: `Balance ${balanceAction} by Company. Reason: ${balanceReason}`,
          admin_notes: `Manual balance adjustment by admin. User: ${user.email}`,
          transaction_uid: `ADM-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`,
        });
      if (transactionError) throw transactionError;
      
      // Send notification to user
      await supabase.from('notifications').insert({
        user_id: user.id,
        type: 'balance_update',
        message: `Your account was ${balanceAction}ed by ₱${amount.toFixed(2)} by the Company. Reason: ${balanceReason}. Your new balance is ₱${newBalance.toFixed(2)}.`,
        link_to: '/dashboard/wallet' 
      });

      toast({ title: "Balance Adjusted", description: `User ${user.full_name}'s balance updated to ₱${newBalance.toFixed(2)}.` });
      onBalanceAdjusted();
      onClose();
      setBalanceAmount('');
      setBalanceReason('');
    } catch (error) {
      toast({ title: "Balance Adjustment Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };
  
  if (!user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Adjust Balance for: {user.full_name}</DialogTitle>
          <DialogDescription>Current Balance: ₱{currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="balance-action">Action</Label>
            <Select id="balance-action" value={balanceAction} onValueChange={setBalanceAction} disabled={loading}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="credit">Credit (Top-up)</SelectItem>
                <SelectItem value="debit">Debit (Deduct)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="balance-amount">Amount (₱)</Label>
            <Input id="balance-amount" type="number" placeholder="0.00" value={balanceAmount} onChange={e => setBalanceAmount(e.target.value)} disabled={loading} />
          </div>
          <div>
            <Label htmlFor="balance-reason">Reason for Adjustment</Label>
            <Input id="balance-reason" placeholder="e.g., Bonus, Correction, Fee" value={balanceReason} onChange={e => setBalanceReason(e.target.value)} disabled={loading} />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild><Button variant="outline" disabled={loading}>Cancel</Button></DialogClose>
          <Button onClick={handleAdjustBalance} disabled={loading || !balanceAmount || !balanceReason.trim()}>
            {loading ? 'Processing...' : 'Adjust Balance'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AdjustBalanceModal;