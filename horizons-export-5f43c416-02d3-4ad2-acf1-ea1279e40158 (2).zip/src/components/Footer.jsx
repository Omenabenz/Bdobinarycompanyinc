import React from 'react';
import { Mail, Phone, MapPin, BarChart3 } from 'lucide-react';

const Footer = ({ menuItems, currentDate }) => {
  const businessAddress = "123 Corporate Street, Barangay San Lorenzo, Makati City, Metro Manila, 1225, Philippines";
  const companyRegisteredDate = "November 10, 2024";

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-xl font-bold">BDO Binary Company Inc</span>
              </div>
            </div>
            <p className="text-gray-400 mb-4">
              Philippines' most trusted investment platform. Secure, reliable, and profitable.
            </p>
            <p className="text-sm text-gray-500">
              © 2024 BDO Binary Company Inc. All rights reserved.
            </p>
            <p className="text-xs text-gray-600 mt-1">
              Registered: {companyRegisteredDate}
            </p>
          </div>

          <div>
            <span className="text-lg font-bold mb-4 block">Quick Links</span>
            <ul className="space-y-2">
              {menuItems.map((item) => (
                <li key={item.name}>
                  <a href={item.href} className="text-gray-400 hover:text-white transition-colors">
                    {item.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <span className="text-lg font-bold mb-4 block">Investment Plans</span>
            <ul className="space-y-2 text-gray-400">
              <li>₱2,000 → ₱15,000</li>
              <li>₱5,000 → ₱55,000</li>
              <li>₱10,000 → ₱120,000</li>
              <li>₱20,000 → ₱250,000</li>
              <li>₱50,000 → ₱880,000</li>
            </ul>
          </div>

          <div>
            <span className="text-lg font-bold mb-4 block">Contact Us</span>
            <div className="space-y-3 text-gray-400">
              <p className="flex items-start">
                <Mail className="w-4 h-4 mr-2 mt-1 flex-shrink-0" />
                info@bdobinaryinc.net
              </p>
              <p className="flex items-center">
                <Phone className="w-4 h-4 mr-2 flex-shrink-0" />
                +63 917 123 4567
              </p>
              <p className="flex items-start">
                <MapPin className="w-4 h-4 mr-2 mt-1 flex-shrink-0" />
                <span>{businessAddress}</span>
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            BDO Binary Company Inc is a registered investment company in the Philippines. 
            All investments carry risk. Past performance does not guarantee future results.
            Site information as of {currentDate}.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;