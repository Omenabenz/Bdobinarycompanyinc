import React from 'react';
import { motion } from 'framer-motion';
import { Star, CheckCircle } from 'lucide-react';

const Testimonials = () => {
  const testimonialsData = [
    {
      name: 'Maria Santos',
      location: 'Manila, Philippines',
      amount: '₱140,000',
      time: '6 hours',
      review: 'I received ₱140,000 in just 6 hours! After investing with this legit BDO Binary Company they are truly legit no scam 100% tested and trusted. Salamat po!',
      rating: 5,
      image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/a99218ca764eea132a020aa5fd320c1b.jpg'
    },
    {
      name: 'Carlos Reyes',
      location: 'Cebu City, Philippines',
      amount: '₱85,000',
      time: '8 hours',
      review: 'Sobrang legit ng company na ito! Naka-receive ako ng ₱85,000 sa loob lang ng 8 hours. Hindi ako naniniwala sa una pero totoo pala. Highly recommended!',
      rating: 5,
      image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/cb6cce24d196140daf0ee708ee1c6de4.jpg'
    },
    {
      name: 'Ana Dela Cruz',
      location: 'Davao, Philippines',
      amount: '₱220,000',
      time: '12 hours',
      review: 'Grabe! Hindi ko inexpect na makakakuha ako ng ganito kalaking pera. ₱220,000 in 12 hours lang! BDO Binary Company is the real deal. Salamat sa opportunity!',
      rating: 5,
      image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/c1fdbd969becd26f8d28c417f64d4935.jpg'
    },
    {
      name: 'Roberto Cruz',
      location: 'Quezon City, Philippines',
      amount: '₱95,000',
      time: '5 hours',
      review: 'Napakabilis ng payout! 5 hours lang nakuha ko na yung ₱95,000 ko. Walang hassle, walang delay. This is the best investment platform in the Philippines!',
      rating: 5,
      image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/667980c58a7ec2700dcac7b3c7e9d786.jpg'
    }
  ];

  return (
    <section id="testimonials" className="py-16 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Client Reviews & Testimonials
          </h2>
          <p className="text-lg text-gray-600">Real stories from our successful Filipino investors</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {testimonialsData.map((testimonial, index) => (
            <motion.div
              key={index}
              className="bg-white rounded-2xl shadow-xl p-8 hover-scale"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
            >
              <div className="flex items-center mb-6">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="text-xl font-bold text-gray-900">{testimonial.name}</h4>
                  <p className="text-gray-600">{testimonial.location}</p>
                  <div className="flex items-center mt-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-500 fill-current" />
                    ))}
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <div className="bg-gradient-to-r from-green-100 to-emerald-100 rounded-lg p-4 mb-4">
                  <p className="text-2xl font-bold text-green-800">
                    Received: {testimonial.amount}
                  </p>
                  <p className="text-sm text-gray-600">In just {testimonial.time}</p>
                </div>
              </div>

              <blockquote className="text-gray-700 italic">
                "{testimonial.review}"
              </blockquote>

              <div className="mt-6 flex items-center justify-between">
                <div className="flex items-center text-green-600">
                  <CheckCircle className="w-5 h-5 mr-2" />
                  <span className="font-medium">Verified Payout</span>
                </div>
                <div className="text-sm text-gray-500">
                  {Math.floor(Math.random() * 30) + 1} days ago
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;