import React from 'react';
import { motion } from 'framer-motion';

const BankLogos = () => {
  const banks = [
    {
      name: 'BDO Unibank',
      logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/5968c3a84ee2324918fc85408b7968b2.png',
      description: 'Official Partner'
    },
    {
      name: 'GCash',
      logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/60d6bc3cebd4e6cca26c15d859fe07be.png',
      description: 'Instant Transfers'
    },
    {
      name: 'BPI',
      logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/8931832db4847ef5cf4954be38b2934f.png',
      description: 'Secure Banking'
    },
    {
      name: 'Maya',
      logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/d7d3f02134ec15a75bf02a33dc6912e7.png',
      description: 'Digital Wallet'
    },
    {
      name: 'UnionBank',
      logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/d4ecdcc0502eb0cba9117b9f42a54309.png',
      description: 'Fast Payouts'
    },
    {
      name: 'Metrobank',
      logo: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/5f43c416-02d3-4ad2-acf1-ea1279e40158/2684066ab58a299e2c1c30f316a1e622.png',
      description: 'Trusted Banking'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Trusted Banking Partners
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            We work with the Philippines' most trusted financial institutions
          </p>
          <div className="w-24 h-1 bg-gradient-to-r from-blue-600 to-blue-800 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 max-w-6xl mx-auto">
          {banks.map((bank, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5, scale: 1.05 }}
              className="group"
            >
              <div className="bg-white rounded-2xl p-6 shadow-lg border-2 border-gray-100 hover:border-blue-300 hover:shadow-xl transition-all duration-300 h-full flex flex-col justify-between">
                <div className="text-center">
                  <div className="w-24 h-16 mx-auto mb-4 bg-gray-50 rounded-xl flex items-center justify-center group-hover:bg-blue-50 transition-colors duration-300">
                    <img  
                      src={bank.logo}
                      alt={`${bank.name} official logo`}
                      className="max-w-full max-h-10 object-contain"
                    />
                  </div>
                  <h3 className="font-bold text-gray-900 text-sm mb-1">{bank.name}</h3>
                  <p className="text-xs text-gray-600">{bank.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-12"
        >
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-8 max-w-4xl mx-auto border border-green-200">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Seamless Integration with All Major Philippine Banks
            </h3>
            <p className="text-gray-700 mb-6">
              Our platform is integrated with all major Philippine banks and digital wallets, 
              ensuring fast, secure, and reliable payouts directly to your accounts.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white font-bold">✓</span>
                </div>
                <p className="font-semibold text-gray-900">Real-time Processing</p>
                <p className="text-sm text-gray-600">Instant bank transfers</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white font-bold">🔒</span>
                </div>
                <p className="font-semibold text-gray-900">Bank-level Security</p>
                <p className="text-sm text-gray-600">256-bit SSL encryption</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-white font-bold">24/7</span>
                </div>
                <p className="font-semibold text-gray-900">Always Available</p>
                <p className="text-sm text-gray-600">Round-the-clock service</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default BankLogos;