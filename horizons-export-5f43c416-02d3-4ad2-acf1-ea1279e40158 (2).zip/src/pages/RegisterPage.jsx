import React, { useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from '@/components/ui/use-toast';
import { UserPlus, Mail, Phone, Lock, UploadCloud, Banknote, UserCircle, CheckCircle, Chrome, Facebook as FacebookIcon, ArrowRight, ArrowLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';

const philippineBanks = [
  "Banco de Oro (BDO)", "Bank of the Philippine Islands (BPI)", "Metrobank", "Land Bank of the Philippines", 
  "Philippine National Bank (PNB)", "Security Bank", "UnionBank of the Philippines", "RCBC", 
  "China Bank", "EastWest Bank", "GCash", "PayMaya (Maya)", "Coins.ph", "GrabPay"
];

const RegisterPage = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: '',
    phoneNumber: '',
    email: '',
    password: '',
    confirmPassword: '',
    profilePicture: null,
    bankName: '',
    accountName: '',
    accountNumber: '',
    agreedToTerms: false,
  });
  const [loading, setLoading] = useState(false);
  const [profilePicturePreview, setProfilePicturePreview] = useState(null);
  const fileInputRef = useRef(null);

  const { signUpWithEmail, signInWithGoogle, signInWithFacebook } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    if (type === 'file') {
      const file = files[0];
      setFormData(prev => ({ ...prev, [name]: file }));
      if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setProfilePicturePreview(reader.result);
        };
        reader.readAsDataURL(file);
      } else {
        setProfilePicturePreview(null);
      }
    } else {
      setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
    }
  };

  const handleBankChange = (value) => {
    setFormData(prev => ({ ...prev, bankName: value }));
  };

  const validateStep1 = () => {
    if (!formData.fullName || !formData.phoneNumber || !formData.email || !formData.password || !formData.confirmPassword) {
      toast({ title: "Missing Fields", description: "Please fill all fields in Step 1.", variant: "destructive" });
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      toast({ title: "Password Mismatch", description: "Passwords do not match.", variant: "destructive" });
      return false;
    }
    if (formData.password.length < 6) {
      toast({ title: "Weak Password", description: "Password must be at least 6 characters.", variant: "destructive" });
      return false;
    }
    return true;
  };
  
  const validateStep2 = () => {
    if (!formData.bankName || !formData.accountName || !formData.accountNumber) {
      toast({ title: "Missing Bank Details", description: "Please provide all bank information.", variant: "destructive" });
      return false;
    }
    if (!formData.agreedToTerms) {
      toast({ title: "Terms and Conditions", description: "You must agree to the terms and conditions.", variant: "destructive" });
      return false;
    }
    return true;
  };

  const nextStep = () => {
    if (step === 1 && validateStep1()) {
      setStep(2);
    }
  };
  const prevStep = () => setStep(1);

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!validateStep2()) return;

    setLoading(true);
    try {
      let avatarUrl = null;
      if (formData.profilePicture) {
        const fileExt = formData.profilePicture.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `${fileName}`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('avatars')
          .upload(filePath, formData.profilePicture);

        if (uploadError) throw uploadError;
        
        const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(filePath);
        avatarUrl = urlData.publicUrl;
      }

      const userMetadata = {
        full_name: formData.fullName,
        phone_number: formData.phoneNumber,
        avatar_url: avatarUrl,
        bank_name: formData.bankName,
        bank_account_name: formData.accountName,
        bank_account_number: formData.accountNumber,
      };
      
      const { data, error } = await signUpWithEmail(formData.email, formData.password, userMetadata);
      if (error) throw error;

      if (data.user) {
        const { error: profileError } = await supabase
        .from('profiles')
        .update({ 
            full_name: formData.fullName,
            phone_number: formData.phoneNumber,
            avatar_url: avatarUrl,
            bank_name: formData.bankName,
            bank_account_name: formData.accountName,
            bank_account_number: formData.accountNumber,
            updated_at: new Date().toISOString()
         })
        .eq('id', data.user.id);

        if (profileError) {
            console.error("Error updating profile:", profileError);
            toast({ title: 'Profile Update Failed', description: profileError.message, variant: 'destructive' });
        }
      }

      toast({ title: 'Registration Successful!', description: 'Please check your email to verify your account.' });
      navigate('/login');
    } catch (error) {
      toast({ title: 'Registration Failed', description: error.message, variant: 'destructive' });
    }
    setLoading(false);
  };
  
  const handleSocialLogin = async (provider) => {
    setLoading(true);
    try {
      const { error } = provider === 'google' ? await signInWithGoogle() : await signInWithFacebook();
      if (error) throw error;
    } catch (error) {
      toast({ title: 'Social Login Failed', description: error.message, variant: 'destructive' });
    }
    setLoading(false);
  };

  const pageVariants = {
    initial: { opacity: 0, x: "100%" },
    in: { opacity: 1, x: 0 },
    out: { opacity: 0, x: "-100%" }
  };

  const pageTransition = {
    type: "tween",
    ease: "anticipate",
    duration: 0.5
  };

  const inputStyles = "bg-background border-border text-foreground placeholder:text-muted-foreground focus:border-primary focus:ring-primary";
  const labelStyles = "text-foreground flex items-center";
  const iconStyles = "mr-2 h-4 w-4 text-muted-foreground";

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-center min-h-screen bg-brand-gray-light p-4"
    >
      <Card className="w-full max-w-lg shadow-xl border border-brand-gray-medium bg-white overflow-hidden">
        <CardHeader className="text-center">
           <motion.div initial={{ scale: 0 }} animate={{ scale: 1}} transition={{ delay: 0.2, type: "spring", stiffness: 200 }}>
            <UserPlus className="mx-auto h-12 w-12 text-primary mb-3" />
          </motion.div>
          <CardTitle className="text-3xl font-semibold text-foreground">Create Account</CardTitle>
          <CardDescription className="text-muted-foreground">Join us in two simple steps.</CardDescription>
          <div className="flex justify-center mt-4">
            <div className={`w-1/2 p-2.5 text-center rounded-l-md text-sm font-medium ${step === 1 ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}>Step 1: Basics</div>
            <div className={`w-1/2 p-2.5 text-center rounded-r-md text-sm font-medium ${step === 2 ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}>Step 2: Profile & Bank</div>
          </div>
        </CardHeader>
        <CardContent className="relative">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.form
                key="step1"
                initial="initial"
                animate="in"
                exit="out"
                variants={pageVariants}
                transition={pageTransition}
                onSubmit={(e) => e.preventDefault()} 
                className="space-y-5"
              >
                <div className="space-y-1.5">
                  <Label htmlFor="fullName" className={labelStyles}><UserCircle className={iconStyles} />Full Name</Label>
                  <Input id="fullName" name="fullName" placeholder="Juan Dela Cruz" value={formData.fullName} onChange={handleChange} required className={inputStyles}/>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="phoneNumber" className={labelStyles}><Phone className={iconStyles} />Phone Number</Label>
                  <Input id="phoneNumber" name="phoneNumber" type="tel" placeholder="09123456789" value={formData.phoneNumber} onChange={handleChange} required className={inputStyles}/>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="email" className={labelStyles}><Mail className={iconStyles} />Email Address</Label>
                  <Input id="email" name="email" type="email" placeholder="you@example.com" value={formData.email} onChange={handleChange} required className={inputStyles}/>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="password" className={labelStyles}><Lock className={iconStyles} />Password</Label>
                  <Input id="password" name="password" type="password" placeholder="Minimum 6 characters" value={formData.password} onChange={handleChange} required className={inputStyles}/>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="confirmPassword" className={labelStyles}><Lock className={iconStyles} />Confirm Password</Label>
                  <Input id="confirmPassword" name="confirmPassword" type="password" placeholder="Re-enter your password" value={formData.confirmPassword} onChange={handleChange} required className={inputStyles}/>
                </div>
                <Button onClick={nextStep} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 text-base">
                  Next <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </motion.form>
            )}

            {step === 2 && (
              <motion.form
                key="step2"
                initial="initial"
                animate="in"
                exit="out"
                variants={pageVariants}
                transition={pageTransition}
                onSubmit={handleRegister} 
                className="space-y-5"
              >
                <div className="space-y-1.5">
                  <Label htmlFor="profilePicture" className={labelStyles}><UploadCloud className={iconStyles} />Profile Picture (Optional)</Label>
                  <Input id="profilePicture" name="profilePicture" type="file" accept="image/*" onChange={handleChange} ref={fileInputRef} className={`${inputStyles} file:text-primary file:font-medium`}/>
                  {profilePicturePreview && <img-replace src={profilePicturePreview} alt="Profile Preview" className="mt-2 h-24 w-24 rounded-full object-cover mx-auto border border-border" />}
                </div>
                 <div className="space-y-1.5">
                  <Label htmlFor="bankName" className={labelStyles}><Banknote className={iconStyles} />Select Bank/E-Wallet</Label>
                  <Select onValueChange={handleBankChange} value={formData.bankName}>
                    <SelectTrigger className={`w-full ${inputStyles}`}>
                      <SelectValue placeholder="Choose your bank or e-wallet" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover text-popover-foreground border-border">
                      <SelectGroup>
                        <SelectLabel className="text-muted-foreground">Philippine Banks & E-Wallets</SelectLabel>
                        {philippineBanks.map(bank => (
                          <SelectItem key={bank} value={bank} className="hover:bg-accent focus:bg-accent">{bank}</SelectItem>
                        ))}
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="accountName" className={labelStyles}><UserCircle className={iconStyles} />Account Name</Label>
                  <Input id="accountName" name="accountName" placeholder="Full Name on Account" value={formData.accountName} onChange={handleChange} required className={inputStyles}/>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="accountNumber" className={labelStyles}><CheckCircle className={iconStyles} />Account Number</Label>
                  <Input id="accountNumber" name="accountNumber" placeholder="Your Bank Account Number" value={formData.accountNumber} onChange={handleChange} required className={inputStyles}/>
                </div>
                <div className="flex items-center space-x-2 pt-2">
                  <Checkbox id="agreedToTerms" name="agreedToTerms" checked={formData.agreedToTerms} onCheckedChange={(checked) => setFormData(prev => ({ ...prev, agreedToTerms: Boolean(checked) }))} className="border-border data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"/>
                  <Label htmlFor="agreedToTerms" className="text-sm text-muted-foreground">
                    I agree to the <Link to="/terms" className="underline text-primary hover:text-primary/80">Terms and Conditions</Link>.
                  </Label>
                </div>
                <div className="flex space-x-3 pt-2">
                    <Button type="button" onClick={prevStep} variant="outline" className="w-1/2 border-border text-foreground hover:bg-accent hover:text-accent-foreground">
                        <ArrowLeft className="mr-2 h-5 w-5" /> Back
                    </Button>
                    <Button type="submit" className="w-1/2 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 text-base" disabled={loading}>
                        {loading ? 'Creating Account...' : 'Create Account'}
                    </Button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </CardContent>
        <CardFooter className="flex flex-col items-center space-y-4 pt-6 border-t border-border">
          <div className="relative w-full">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-muted-foreground rounded-md">Or sign up with</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 w-full">
            <Button variant="outline" className="w-full border-border text-foreground hover:bg-accent hover:text-accent-foreground" onClick={() => handleSocialLogin('google')} disabled={loading}>
              <Chrome className="mr-2 h-5 w-5" /> Google
            </Button>
            <Button variant="outline" className="w-full border-border text-foreground hover:bg-accent hover:text-accent-foreground" onClick={() => handleSocialLogin('facebook')} disabled={loading}>
              <FacebookIcon className="mr-2 h-5 w-5" /> Facebook
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link to="/login" className="font-medium text-primary hover:underline">
              Sign In
            </Link>
          </p>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default RegisterPage;