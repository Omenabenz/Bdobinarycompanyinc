import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { Lock, KeyRound, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const ResetPasswordPage = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  // This page is typically visited from an email link containing a recovery token.
  // Supabase handles this token automatically when the user is redirected here.
  // We need to check if there's an active session with a recovery token.

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'PASSWORD_RECOVERY') {
        // This event means Supabase has processed the recovery token from the URL
        // and the user is in a state where they can set a new password.
        // No need to manually handle the token here.
      }
    });
    return () => subscription.unsubscribe();
  }, []);


  const handleResetPassword = async (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return;
    }
    setLoading(true);
    setError('');
    setMessage('');

    try {
      // The user should already be in a "recovery" session state if they clicked the email link.
      // Supabase client's updateUser method will use the active recovery token.
      const { error: updateError } = await supabase.auth.updateUser({ password: password });

      if (updateError) throw updateError;

      setMessage("Your password has been successfully reset. You can now log in with your new password.");
      toast({ title: "Password Reset Successful", description: "You can now log in." });
      setTimeout(() => navigate('/login'), 3000); 
    } catch (err) {
      setError(err.message);
      toast({ title: "Password Reset Failed", description: err.message, variant: 'destructive' });
    }
    setLoading(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 p-4"
    >
      <Card className="w-full max-w-md shadow-xl border-slate-700 bg-slate-800 text-slate-50">
        <CardHeader className="text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: "spring", stiffness: 200 }}>
            <KeyRound className="mx-auto h-12 w-12 text-primary mb-3" />
          </motion.div>
          <CardTitle className="text-3xl font-semibold">Reset Your Password</CardTitle>
          <CardDescription className="text-slate-400">
            Enter your new password below.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {message ? (
            <div className="text-center text-green-400 p-4 bg-green-900/30 rounded-md flex items-center">
              <CheckCircle className="h-5 w-5 mr-2" /> {message}
            </div>
          ) : (
            <form onSubmit={handleResetPassword} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-300 flex items-center">
                  <Lock className="mr-2 h-4 w-4 text-slate-400" /> New Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-slate-50 placeholder:text-slate-500 focus:border-primary focus:ring-primary"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-slate-300 flex items-center">
                  <Lock className="mr-2 h-4 w-4 text-slate-400" /> Confirm New Password
                </Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-slate-50 placeholder:text-slate-500 focus:border-primary focus:ring-primary"
                />
              </div>
              {error && <p className="text-sm text-red-400 bg-red-900/30 p-2 rounded-md">{error}</p>}
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 text-base" disabled={loading}>
                {loading ? 'Resetting...' : 'Reset Password'}
              </Button>
            </form>
          )}
        </CardContent>
         <CardFooter className="text-center pt-6 border-t border-slate-700">
            <p className="text-xs text-slate-500">Make sure to choose a strong, unique password.</p>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ResetPasswordPage;