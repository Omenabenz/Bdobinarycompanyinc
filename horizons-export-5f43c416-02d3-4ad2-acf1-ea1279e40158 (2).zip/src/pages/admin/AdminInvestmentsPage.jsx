import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { TrendingUp, Edit, Eye, Filter, Search } from 'lucide-react';
import { formatInManilaTime } from '@/lib/utils';

const AdminInvestmentsPage = () => {
  const [investments, setInvestments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [editingInvestment, setEditingInvestment] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Form states for editing
  const [editPlanName, setEditPlanName] = useState('');
  const [editAmountInvested, setEditAmountInvested] = useState('');
  const [editExpectedReturn, setEditExpectedReturn] = useState('');
  const [editStatus, setEditStatus] = useState('');

  const investmentStatuses = ['pending', 'active', 'matured', 'cancelled', 'failed'];

  useEffect(() => {
    fetchInvestments();
  }, []);

  const fetchInvestments = async () => {
    setLoading(true);
    try {
      let query = supabase.from('investments').select(`
        id, 
        user_id, 
        plan_name, 
        amount_invested, 
        expected_return, 
        start_date, 
        end_date, 
        status, 
        created_at,
        user:profiles (id, full_name, email)
      `).order('created_at', { ascending: false });

      const { data, error } = await query;
      if (error) throw error;
      setInvestments(data || []);
    } catch (error) {
      toast({ title: "Error Fetching Investments", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleEditInvestment = (investment) => {
    setEditingInvestment(investment);
    setEditPlanName(investment.plan_name);
    setEditAmountInvested(investment.amount_invested.toString());
    setEditExpectedReturn(investment.expected_return ? investment.expected_return.toString() : '');
    setEditStatus(investment.status);
    setIsEditModalOpen(true);
  };

  const handleSaveInvestmentChanges = async () => {
    if (!editingInvestment) return;
    setLoading(true);
    try {
      const updates = {
        plan_name: editPlanName,
        amount_invested: parseFloat(editAmountInvested),
        expected_return: editExpectedReturn ? parseFloat(editExpectedReturn) : null,
        status: editStatus,
        updated_at: new Date().toISOString(),
      };
      const { error } = await supabase
        .from('investments')
        .update(updates)
        .eq('id', editingInvestment.id);
      
      if (error) throw error;
      toast({ title: "Investment Updated", description: "Investment details saved successfully." });
      setIsEditModalOpen(false);
      setEditingInvestment(null);
      fetchInvestments(); // Refresh data
    } catch (error) {
      toast({ title: "Update Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const filteredInvestments = investments.filter(inv => {
    const matchesSearch = 
      (inv.user?.full_name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (inv.user?.email?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      inv.plan_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || inv.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <TrendingUp className="w-7 h-7 mr-3 text-primary" />
            Investments Management
          </CardTitle>
          <CardDescription>Monitor and manage all user investments.</CardDescription>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input 
                placeholder="Search by user, plan, ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full"
              />
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Filter className="h-5 w-5 text-muted-foreground" />
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  {investmentStatuses.map(status => (
                    <SelectItem key={status} value={status} className="capitalize">{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-center py-8">Loading investments...</p>
          ) : filteredInvestments.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">No investments found matching your criteria.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Plan Name</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead className="text-right">Expected Return</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>End Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInvestments.map((investment) => (
                    <TableRow key={investment.id}>
                      <TableCell>
                        <div className="font-medium">{investment.user?.full_name || 'N/A'}</div>
                        <div className="text-xs text-muted-foreground">{investment.user?.email || investment.user_id}</div>
                      </TableCell>
                      <TableCell>{investment.plan_name}</TableCell>
                      <TableCell className="text-right">₱{investment.amount_invested.toLocaleString()}</TableCell>
                      <TableCell className="text-right">
                        {investment.expected_return ? `₱${investment.expected_return.toLocaleString()}` : 'N/A'}
                      </TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 text-xs rounded-full capitalize ${
                          investment.status === 'active' ? 'bg-green-100 text-green-700' :
                          investment.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                          investment.status === 'matured' ? 'bg-blue-100 text-blue-700' :
                          investment.status === 'cancelled' ? 'bg-gray-100 text-gray-700' :
                          investment.status === 'failed' ? 'bg-red-100 text-red-700' : ''
                        }`}>
                          {investment.status}
                        </span>
                      </TableCell>
                      <TableCell>{investment.start_date ? formatInManilaTime(new Date(investment.start_date), 'PP') : 'N/A'}</TableCell>
                      <TableCell>{investment.end_date ? formatInManilaTime(new Date(investment.end_date), 'PP') : 'N/A'}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" onClick={() => handleEditInvestment(investment)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        {/* <Button variant="ghost" size="icon"> <Eye className="h-4 w-4" /> </Button> */}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
         {filteredInvestments.length > 10 && (
            <CardFooter className="justify-center border-t pt-4">
                <p className="text-xs text-muted-foreground">Showing {filteredInvestments.length} investments.</p>
                {/* Add pagination controls here if needed */}
            </CardFooter>
        )}
      </Card>

      {/* Edit Investment Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Investment</DialogTitle>
            <DialogDescription>
              Modify the details for investment ID: {editingInvestment?.id.substring(0,8)}...
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label htmlFor="editPlanName" className="text-sm font-medium">Plan Name</label>
              <Input id="editPlanName" value={editPlanName} onChange={(e) => setEditPlanName(e.target.value)} className="mt-1" />
            </div>
            <div>
              <label htmlFor="editAmountInvested" className="text-sm font-medium">Amount Invested (₱)</label>
              <Input id="editAmountInvested" type="number" value={editAmountInvested} onChange={(e) => setEditAmountInvested(e.target.value)} className="mt-1" />
            </div>
            <div>
              <label htmlFor="editExpectedReturn" className="text-sm font-medium">Expected Return (₱)</label>
              <Input id="editExpectedReturn" type="number" value={editExpectedReturn} onChange={(e) => setEditExpectedReturn(e.target.value)} className="mt-1" placeholder="Optional"/>
            </div>
            <div>
              <label htmlFor="editStatus" className="text-sm font-medium">Status</label>
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger id="editStatus" className="mt-1">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {investmentStatuses.map(status => (
                    <SelectItem key={status} value={status} className="capitalize">{status}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline">Cancel</Button>
            </DialogClose>
            <Button type="button" onClick={handleSaveInvestmentChanges} disabled={loading}>
              {loading ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminInvestmentsPage;