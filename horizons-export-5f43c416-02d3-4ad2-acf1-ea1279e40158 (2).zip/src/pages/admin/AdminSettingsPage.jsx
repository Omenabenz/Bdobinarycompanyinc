import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Cog, Shield, Bell, Percent, Users, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/components/ui/use-toast';

const AdminSettingsPage = () => {
  // Placeholder states for various settings
  const [siteName, setSiteName] = useState('Bdounibank Platform');
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [maxWithdrawal, setMaxWithdrawal] = useState('500000');
  const [minDeposit, setMinDeposit] = useState('500');
  const [supportEmail, setSupportEmail] = useState('support@pseinvest.online');

  const handleSaveChanges = () => {
    // In a real app, these settings would be saved to a config table or backend
    toast({ title: "Settings Saved (Simulated)", description: "Your changes have been recorded." });
    console.log("Settings saved:", { siteName, maintenanceMode, maxWithdrawal, minDeposit, supportEmail });
  };

  return (
    <div className="space-y-6 p-4 md:p-6">
      <Card className="shadow-lg rounded-xl">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-slate-800 flex items-center">
            <Cog className="mr-3 h-7 w-7 text-primary" /> Admin Panel Settings
          </CardTitle>
          <CardDescription>
            Configure general settings for the admin panel and site-wide parameters.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          
          {/* General Site Settings */}
          <section>
            <h3 className="text-lg font-semibold text-slate-700 mb-3 border-b pb-2 flex items-center">
              <Users className="mr-2 h-5 w-5 text-slate-500" /> General Site Configuration
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="siteName">Site Name</Label>
                <Input id="siteName" value={siteName} onChange={(e) => setSiteName(e.target.value)} placeholder="Your Platform Name" className="mt-1"/>
              </div>
              <div>
                <Label htmlFor="supportEmail">Support Email</Label>
                <Input id="supportEmail" type="email" value={supportEmail} onChange={(e) => setSupportEmail(e.target.value)} placeholder="support@example.com" className="mt-1"/>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 border rounded-md md:col-span-2">
                <Label htmlFor="maintenanceMode" className="text-sm">Enable Maintenance Mode</Label>
                <Switch id="maintenanceMode" checked={maintenanceMode} onCheckedChange={setMaintenanceMode} />
              </div>
            </div>
          </section>

          {/* Transaction Limits */}
          <section>
            <h3 className="text-lg font-semibold text-slate-700 mb-3 border-b pb-2 flex items-center">
                <Percent className="mr-2 h-5 w-5 text-slate-500" /> Transaction Parameters
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <Label htmlFor="minDeposit">Minimum Deposit Amount (PHP)</Label>
                    <Input id="minDeposit" type="number" value={minDeposit} onChange={(e) => setMinDeposit(e.target.value)} placeholder="e.g., 500" className="mt-1"/>
                </div>
                <div>
                    <Label htmlFor="maxWithdrawal">Maximum Withdrawal Amount (PHP)</Label>
                    <Input id="maxWithdrawal" type="number" value={maxWithdrawal} onChange={(e) => setMaxWithdrawal(e.target.value)} placeholder="e.g., 500000" className="mt-1"/>
                </div>
            </div>
          </section>
          
          {/* Placeholder for more settings */}
          <div className="p-6 text-center text-slate-400 bg-slate-100 border border-dashed border-slate-300 rounded-lg">
            <Shield className="mx-auto h-8 w-8 text-slate-400 mb-2" />
            <p className="text-sm">
              Additional settings for security, API keys, and integrations will appear here.
            </p>
          </div>
        </CardContent>
        <CardFooter className="border-t pt-6">
          <Button onClick={handleSaveChanges} className="ml-auto bg-primary hover:bg-primary/90">
            <Save className="mr-2 h-4 w-4"/> Save All Settings
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default AdminSettingsPage;