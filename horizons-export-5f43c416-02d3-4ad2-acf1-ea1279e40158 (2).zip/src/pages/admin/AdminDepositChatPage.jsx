import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/use-toast';
import { MessageSquare, Users, Clock, CheckCircle, AlertTriangle } from 'lucide-react';
import { formatInManilaTime } from '@/lib/utils';
import { Link } from 'react-router-dom';

const AdminDepositChatPage = () => {
  const [chatSessions, setChatSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState(''); // e.g., 'pending_admin_reply', 'pending_user_proof'

  const fetchChatSessions = useCallback(async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('chat_sessions')
        .select('*, user:profiles(full_name, email), transaction:transactions(status, amount)')
        .eq('session_type', 'deposit_chat');

      if (searchTerm) {
        query = query.or(`user.full_name.ilike.%${searchTerm}%,user.email.ilike.%${searchTerm}%,id.ilike.%${searchTerm}%`);
      }
      if (filterStatus) {
        query = query.eq('status', filterStatus);
      }
      
      const { data, error } = await query.order('updated_at', { ascending: false }).limit(50);

      if (error) throw error;
      setChatSessions(data || []);
    } catch (error) {
      toast({ title: "Error Fetching Chat Sessions", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  }, [searchTerm, filterStatus]);

  useEffect(() => {
    fetchChatSessions();
     // Setup Supabase realtime subscription for chat_sessions
    const channel = supabase
      .channel('admin-deposit-chat-sessions')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'chat_sessions', filter: 'session_type=eq.deposit_chat' },
        (payload) => {
          console.log('Admin Deposit Chat Sessions change received!', payload);
          fetchChatSessions();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchChatSessions]);

  const getStatusIndicator = (status) => {
    switch (status) {
      case 'pending_admin_reply': return <Clock className="h-4 w-4 text-orange-500" />;
      case 'pending_user_proof': return <Users className="h-4 w-4 text-blue-500" />;
      case 'pending_confirmation': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'closed_completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'closed_failed': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default: return <MessageSquare className="h-4 w-4 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-4 shadow-md rounded-xl bg-white">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <Input 
            placeholder="Search by user, email, or session ID..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-sm"
          />
          {/* Add filter dropdown for status if needed */}
        </div>
      </Card>

      {loading && <p className="text-center py-4">Loading deposit chat sessions...</p>}
      {!loading && chatSessions.length === 0 && <p className="text-center py-4">No deposit chat sessions found.</p>}
      {!loading && chatSessions.length > 0 && (
        <Card className="shadow-md rounded-xl">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Session ID</TableHead>
                <TableHead>User</TableHead>
                <TableHead className="hidden md:table-cell">Deposit Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="hidden lg:table-cell">Last Updated</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {chatSessions.map((session) => (
                <TableRow key={session.id}>
                  <TableCell className="font-medium text-xs">{session.id}</TableCell>
                  <TableCell>
                    <div>{session.user?.full_name || 'N/A'}</div>
                    <div className="text-xs text-slate-500">{session.user?.email || session.user_id}</div>
                  </TableCell>
                  <TableCell className="hidden md:table-cell">
                    ₱{session.transaction?.amount?.toLocaleString('en-US', {minimumFractionDigits: 2}) || 'N/A'}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      {getStatusIndicator(session.status)}
                      <span className="capitalize text-xs">{session.status.replace(/_/g, ' ')}</span>
                    </div>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-xs">{formatInManilaTime(new Date(session.updated_at), 'MMM d, yyyy HH:mm')}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="outline" size="sm" asChild>
                      <Link to={`/admin/deposit-chat/${session.id}`}>Open Chat</Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
};

export default AdminDepositChatPage;