import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { BarChart2, Edit, PlusCircle, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';

const AdminMarketDataPage = () => {
  // Placeholder data - in a real app, this would come from state/API
  const marketDataItems = [
    { id: 'PSEI', name: 'PSE Index', value: '6,500.75', change: '+0.5%', trend: 'up' },
    { id: 'DOW', name: 'Dow Jones', value: '33,800.12', change: '-0.2%', trend: 'down' },
    { id: 'BTC', name: 'Bitcoin (USD)', value: '68,000', change: '+2.1%', trend: 'up' },
    { id: 'ETH', name: 'Ethereum (USD)', value: '3,500', change: '+1.8%', trend: 'up' },
  ];

  return (
    <div className="space-y-6 p-4 md:p-6">
      <Card className="shadow-lg rounded-xl">
        <CardHeader className="flex flex-row justify-between items-center">
          <div>
            <CardTitle className="text-xl font-semibold text-slate-800 flex items-center">
              <BarChart2 className="mr-3 h-7 w-7 text-primary" /> Market Data Management
            </CardTitle>
            <CardDescription>
              Control the market data displayed on the user dashboard.
            </CardDescription>
          </div>
          <Button disabled> {/* Functionality to be implemented */}
            <PlusCircle className="mr-2 h-4 w-4" /> Add New Data Source
          </Button>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {marketDataItems.map(item => (
              <Card key={item.id} className="bg-slate-50">
                <CardHeader>
                  <CardTitle className="text-lg">{item.name}</CardTitle>
                  <CardDescription>ID: {item.id}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-slate-700">{item.value}</p>
                  <p className={`text-sm font-medium ${item.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {item.change}
                  </p>
                  <div className="mt-4 flex justify-end">
                    <Button variant="outline" size="sm" disabled> {/* Functionality to be implemented */}
                      <Edit className="mr-2 h-3.5 w-3.5" /> Edit
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="mt-8 p-6 text-center text-slate-500 bg-amber-50 border border-amber-200 rounded-lg">
            <ShieldAlert className="mx-auto h-10 w-10 text-amber-500 mb-3" />
            <p className="text-md font-semibold text-amber-700">Advanced Configuration Coming Soon</p>
            <p className="mt-1 text-sm">
              This section will allow administrators to integrate live data feeds,
              set update intervals, and manage data source priorities.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminMarketDataPage;