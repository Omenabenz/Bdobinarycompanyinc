import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Repeat, Edit, Eye, Filter, Search, CheckCircle, Clock, AlertCircle, PlusCircle, MinusCircle, TrendingUp, TrendingDown } from 'lucide-react';
import { formatInManilaTime } from '@/lib/utils';

const transactionTypes = ['all', 'deposit', 'withdrawal', 'withdrawal_request', 'investment', 'investment_payout', 'admin_credit', 'admin_debit', 'deposit_initiated'];
const transactionStatuses = ['all', 'pending', 'completed', 'approved', 'failed', 'cancelled', 'processing', 'on_hold', 'declined', 'pending_payment', 'pending_confirmation'];

const TransactionStatusIcon = ({ status }) => {
  switch (status) {
    case 'completed':
    case 'approved':
      return <CheckCircle className="w-4 h-4 text-green-500" />;
    case 'pending':
    case 'pending_payment':
    case 'pending_confirmation':
    case 'processing':
      return <Clock className="w-4 h-4 text-yellow-500" />;
    case 'failed':
    case 'declined':
    case 'cancelled':
      return <AlertCircle className="w-4 h-4 text-red-500" />;
    case 'on_hold':
      return <AlertCircle className="w-4 h-4 text-orange-500" />;
    default:
      return <Clock className="w-4 h-4 text-gray-500" />;
  }
};

const TransactionTypeIcon = ({ type }) => {
    switch (type) {
        case 'deposit':
        case 'deposit_initiated':
        case 'admin_credit':
        case 'investment_payout':
            return <PlusCircle className="w-4 h-4 text-green-500" />;
        case 'withdrawal':
        case 'withdrawal_request':
        case 'admin_debit':
        case 'investment':
            return <MinusCircle className="w-4 h-4 text-red-500" />;
        default:
            return <Repeat className="w-4 h-4 text-gray-500" />;
    }
};


const AdminTransactionsPage = () => {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editStatus, setEditStatus] = useState('');
  const [editAdminNotes, setEditAdminNotes] = useState('');
  const [editStatusReason, setEditStatusReason] = useState('');

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      let query = supabase.from('transactions').select(`
        *,
        user:profiles (id, full_name, email)
      `).order('created_at', { ascending: false });

      const { data, error } = await query;
      if (error) throw error;
      setTransactions(data || []);
    } catch (error) {
      toast({ title: "Error Fetching Transactions", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleEditTransaction = (transaction) => {
    setEditingTransaction(transaction);
    setEditStatus(transaction.status);
    setEditAdminNotes(transaction.admin_notes || '');
    setEditStatusReason(transaction.status_reason || '');
    setIsEditModalOpen(true);
  };

  const handleSaveTransactionChanges = async () => {
    if (!editingTransaction) return;
    setLoading(true);
    try {
      const updates = {
        status: editStatus,
        admin_notes: editAdminNotes,
        status_reason: editStatusReason,
        updated_at: new Date().toISOString(),
      };

      if (editingTransaction.type === 'deposit_initiated' && editStatus === 'completed' && editingTransaction.status !== 'completed') {
        const { data: balanceData, error: fetchError } = await supabase
            .from('user_balances')
            .select('current_balance')
            .eq('user_id', editingTransaction.user_id)
            .single();
        if (fetchError && fetchError.code !== 'PGRST116') { // PGRST116 means no row found, treat as 0 balance
            throw fetchError;
        }
        
        const currentBalance = parseFloat(balanceData?.current_balance || 0);
        const depositAmount = parseFloat(editingTransaction.amount);
        const finalBalance = currentBalance + depositAmount;

        const { error: balanceUpdateError } = await supabase
            .from('user_balances')
            .update({ current_balance: finalBalance, last_updated: new Date().toISOString() })
            .eq('user_id', editingTransaction.user_id);
        if (balanceUpdateError) throw balanceUpdateError;
        
        updates.type = 'deposit'; 
        updates.description = `Deposit of ₱${depositAmount.toFixed(2)} completed.`;
        toast({title: "User Balance Updated", description: `₱${depositAmount.toFixed(2)} credited to user.`});
      }


      const { error } = await supabase
        .from('transactions')
        .update(updates)
        .eq('id', editingTransaction.id);
      
      if (error) throw error;

      await supabase.from('notifications').insert({
        user_id: editingTransaction.user_id,
        type: 'transaction_update',
        message: `Company update on transaction ${editingTransaction.transaction_uid ? editingTransaction.transaction_uid.substring(0,8) + '...' : editingTransaction.id.substring(0,8) + '...'}: Status changed to ${editStatus}. ${editStatusReason ? `Reason: ${editStatusReason}`: 'Please check your transaction history for details.'}`,
        link_to: `/dashboard/transactions/receipt/${editingTransaction.transaction_uid || editingTransaction.id}`
      });

      toast({ title: "Transaction Updated", description: "Transaction details saved successfully." });
      setIsEditModalOpen(false);
      setEditingTransaction(null);
      fetchTransactions(); 
    } catch (error) {
      toast({ title: "Update Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const filteredTransactions = transactions.filter(txn => {
    const matchesSearch = 
      (txn.user?.full_name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (txn.user?.email?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (txn.transaction_uid?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (txn.reference_number?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (txn.description?.toLowerCase() || '').includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || txn.type === filterType;
    const matchesStatus = filterStatus === 'all' || txn.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <Repeat className="w-7 h-7 mr-3 text-primary" />
            Transactions Management
          </CardTitle>
          <CardDescription>View and manage all user transactions.</CardDescription>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="relative w-full md:w-1/3">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input 
                placeholder="Search by user, ID, ref..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full"
              />
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-2 w-full md:w-auto">
              <div className="flex items-center gap-1 w-full sm:w-auto">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-full sm:w-[160px]">
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent>
                    {transactionTypes.map(type => (
                      <SelectItem key={type} value={type} className="capitalize">{type.replace(/_/g, ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-1 w-full sm:w-auto">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-full sm:w-[160px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    {transactionStatuses.map(status => (
                      <SelectItem key={status} value={status} className="capitalize">{status.replace(/_/g, ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-center py-8">Loading transactions...</p>
          ) : filteredTransactions.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">No transactions found matching your criteria.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell>
                        <div className="font-medium">{transaction.user?.full_name || 'N/A'}</div>
                        <div className="text-xs text-muted-foreground">{transaction.user?.email || transaction.user_id}</div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                            <TransactionTypeIcon type={transaction.type} />
                            <span className="capitalize text-xs">{transaction.type.replace(/_/g, ' ')}</span>
                        </div>
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate text-xs" title={transaction.description}>
                        {transaction.description || 'N/A'}
                        {transaction.transaction_uid && <div className="text-muted-foreground text-[10px]">ID: {transaction.transaction_uid.substring(0,12)}...</div>}
                        {transaction.reference_number && <div className="text-muted-foreground text-[10px]">Ref: {transaction.reference_number}</div>}
                      </TableCell>
                      <TableCell className={`text-right font-medium ${transaction.amount >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {transaction.amount >= 0 ? '+' : '-'}₱{Math.abs(transaction.amount).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                            <TransactionStatusIcon status={transaction.status} />
                            <span className="capitalize text-xs">{transaction.status.replace(/_/g, ' ')}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs">{formatInManilaTime(new Date(transaction.created_at), 'PPp')}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" onClick={() => handleEditTransaction(transaction)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        {filteredTransactions.length > 10 && (
            <CardFooter className="justify-center border-t pt-4">
                <p className="text-xs text-muted-foreground">Showing {filteredTransactions.length} transactions.</p>
            </CardFooter>
        )}
      </Card>

      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Transaction</DialogTitle>
            <DialogDescription>
              Update status for transaction ID: {editingTransaction?.transaction_uid || editingTransaction?.id.substring(0,8)}...
              <br/>User: {editingTransaction?.user?.full_name} ({editingTransaction?.user?.email})
              <br/>Type: <span className="capitalize">{editingTransaction?.type.replace(/_/g, ' ')}</span>, Amount: ₱{editingTransaction?.amount.toLocaleString()}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label htmlFor="editStatus" className="text-sm font-medium">Status</label>
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger id="editStatus" className="mt-1">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {transactionStatuses.filter(s => s !== 'all').map(status => ( 
                    <SelectItem key={status} value={status} className="capitalize">{status.replace(/_/g, ' ')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label htmlFor="editStatusReason" className="text-sm font-medium">Status Reason (Company Instructions/Notes for User)</label>
              <Textarea 
                id="editStatusReason" 
                value={editStatusReason} 
                onChange={(e) => setEditStatusReason(e.target.value)} 
                className="mt-1"
                placeholder="Provide a reason or instructions for the user (e.g., 'Additional verification needed. Please check your email.'). This will be visible to the user."
                rows={3}
              />
            </div>
            <div>
              <label htmlFor="editAdminNotes" className="text-sm font-medium">Internal Company Notes (Not visible to user)</label>
              <Textarea 
                id="editAdminNotes" 
                value={editAdminNotes} 
                onChange={(e) => setEditAdminNotes(e.target.value)} 
                className="mt-1"
                placeholder="Internal notes for admin team only."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline">Cancel</Button>
            </DialogClose>
            <Button type="button" onClick={handleSaveTransactionChanges} disabled={loading}>
              {loading ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminTransactionsPage;