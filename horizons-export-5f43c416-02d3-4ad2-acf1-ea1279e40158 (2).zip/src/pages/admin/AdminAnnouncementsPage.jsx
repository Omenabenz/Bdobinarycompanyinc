import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Megaphone, PlusCircle, Edit3, Trash2, AlertTriangle, Search, Filter, Users, User } from 'lucide-react';
import { formatInManilaTime } from '@/lib/utils';

const announcementPriorities = ['low', 'medium', 'high'];

const AdminAnnouncementsPage = () => {
  const { user: adminUser } = useAuth(); // Assuming admin is a Supabase user with 'admin' role
  const [announcements, setAnnouncements] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState(null);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('medium');
  const [targetUserId, setTargetUserId] = useState('all'); // 'all' for global, or specific user_id

  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState('all');

  const fetchAnnouncements = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*, target_user:user_id (id, full_name, email)') 
        .eq('is_announcement', true)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setAnnouncements(data || []);
    } catch (error) {
      toast({ title: "Error Fetching Announcements", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  }, []);

  const fetchAllUsers = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .order('full_name', {ascending: true});
      if (error) throw error;
      setAllUsers(data || []);
    } catch (error) {
      toast({ title: "Error Fetching Users", description: "Could not load user list for targeting.", variant: "destructive" });
    }
  }, []);

  useEffect(() => {
    fetchAnnouncements();
    fetchAllUsers();
  }, [fetchAnnouncements, fetchAllUsers]);

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setPriority('medium');
    setTargetUserId('all');
    setEditingAnnouncement(null);
  };

  const handleOpenModal = (announcement = null) => {
    if (announcement) {
      setEditingAnnouncement(announcement);
      setTitle(announcement.title);
      setDescription(announcement.description || '');
      setPriority(announcement.announcement_priority || 'medium');
      setTargetUserId(announcement.user_id || 'all'); 
    } else {
      resetForm();
    }
    setIsModalOpen(true);
  };

  const handleSubmit = async () => {
    if (!title.trim()) {
      toast({ title: "Title Required", description: "Please enter a title for the announcement.", variant: "destructive" });
      return;
    }
    setLoading(true);

    const announcementData = {
      title: title.trim(),
      description: description.trim(),
      status: 'pending', // Or 'active'
      is_announcement: true,
      announcement_priority: priority,
      user_id: targetUserId === 'all' ? null : targetUserId,
      // For global announcements (user_id = null), ensure RLS allows admin to insert with null user_id.
    };

    let notificationMessage = `New Announcement: ${title.trim()}`;
    if(priority === 'high') notificationMessage = `❗ HIGH PRIORITY: ${title.trim()}`;

    try {
      if (editingAnnouncement) {
        const { error } = await supabase
          .from('tasks')
          .update({ ...announcementData, updated_at: new Date().toISOString() })
          .eq('id', editingAnnouncement.id);
        if (error) throw error;
        toast({ title: "Announcement Updated", description: "Changes saved successfully." });
      } else { // Create new announcement(s)
        if (targetUserId === 'all') {
          // Create a single global announcement (task with user_id = null)
          const { data: newAnn, error } = await supabase.from('tasks').insert(announcementData).select().single();
          if (error) throw error;
          // Send notifications to all users. This should ideally be an Edge Function for performance.
          // For client-side simulation, create notifications for a subset or log.
          const usersToNotify = allUsers; // In a real scenario, paginate or use an Edge function.
          for (const u of usersToNotify) {
              await supabase.from('notifications').insert({
                  user_id: u.id, type: 'announcement', message: notificationMessage, link_to: '/dashboard/tasks'
              });
          }
          console.log(`Sent global announcement notifications to ${usersToNotify.length} users.`);
        } else { // Targeted to specific user
            const { data: newAnn, error } = await supabase.from('tasks').insert(announcementData).select().single();
            if (error) throw error;
            
            await supabase.from('notifications').insert({
              user_id: targetUserId,
              type: 'announcement',
              message: notificationMessage,
              link_to: '/dashboard/tasks'
            });
        }
        toast({ title: "Announcement Created", description: "Successfully posted the new announcement." });
      }
      resetForm();
      setIsModalOpen(false);
      fetchAnnouncements();
    } catch (error) {
      toast({ title: "Operation Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleDelete = async (announcementId) => {
    if (!window.confirm("Are you sure you want to delete this announcement?")) return;
    setLoading(true);
    try {
      const { error } = await supabase.from('tasks').delete().eq('id', announcementId).eq('is_announcement', true);
      if (error) throw error;
      toast({ title: "Announcement Deleted" });
      fetchAnnouncements();
    } catch (error) {
      toast({ title: "Deletion Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };
  
  const filteredAnnouncements = announcements.filter(ann => {
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      (ann.title?.toLowerCase() || '').includes(searchLower) ||
      (ann.description?.toLowerCase() || '').includes(searchLower) ||
      (ann.target_user?.full_name?.toLowerCase() || '').includes(searchLower) ||
      (ann.target_user?.email?.toLowerCase() || '').includes(searchLower) ||
      (!ann.target_user && "all users".includes(searchLower)); // Search for "all users" if target_user is null
    const matchesPriority = filterPriority === 'all' || ann.announcement_priority === filterPriority;
    return matchesSearch && matchesPriority;
  });

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div>
            <CardTitle className="flex items-center text-2xl">
              <Megaphone className="w-7 h-7 mr-3 text-primary" />
              Manage Announcements
            </CardTitle>
            <CardDescription>Create, edit, and view company announcements for users.</CardDescription>
          </div>
          <Button onClick={() => handleOpenModal()} className="mt-4 sm:mt-0">
            <PlusCircle className="w-4 h-4 mr-2" /> Create Announcement
          </Button>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="relative w-full md:w-1/3">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input 
                placeholder="Search by title, content, user..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full"
              />
            </div>
            <div className="flex items-center gap-1 w-full sm:w-auto">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={filterPriority} onValueChange={setFilterPriority}>
                  <SelectTrigger className="w-full sm:w-[160px]">
                    <SelectValue placeholder="Filter by priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    {announcementPriorities.map(prio => (
                      <SelectItem key={prio} value={prio} className="capitalize">{prio}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-center py-8">Loading announcements...</p>
          ) : filteredAnnouncements.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">No announcements found.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead className="hidden md:table-cell">Target</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead className="hidden lg:table-cell">Created</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAnnouncements.map((ann) => (
                    <TableRow key={ann.id}>
                      <TableCell className="font-medium max-w-xs truncate" title={ann.title}>{ann.title}</TableCell>
                      <TableCell className="text-xs hidden md:table-cell">
                        {ann.target_user ? (
                             <div className="flex items-center">
                                <User className="w-3 h-3 mr-1 text-muted-foreground"/> {ann.target_user.full_name || ann.target_user.email}
                            </div>
                        ) : (
                            <div className="flex items-center">
                                <Users className="w-3 h-3 mr-1 text-muted-foreground"/> All Users
                            </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <span className={`px-2 py-0.5 text-xs rounded-full capitalize ${
                          ann.announcement_priority === 'high' ? 'bg-red-100 text-red-700' :
                          ann.announcement_priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-blue-100 text-blue-700'
                        }`}>{ann.announcement_priority || 'low'}</span>
                      </TableCell>
                      <TableCell className="text-xs hidden lg:table-cell">{formatInManilaTime(new Date(ann.created_at), 'PP')}</TableCell>
                      <TableCell className="space-x-1">
                        <Button variant="ghost" size="icon" onClick={() => handleOpenModal(ann)} title="Edit Announcement">
                          <Edit3 className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(ann.id)} title="Delete Announcement">
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingAnnouncement ? 'Edit Announcement' : 'Create New Announcement'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="annTitle">Title</Label>
              <Input id="annTitle" value={title} onChange={e => setTitle(e.target.value)} placeholder="Announcement Title" />
            </div>
            <div>
              <Label htmlFor="annDescription">Description (Optional)</Label>
              <Textarea id="annDescription" value={description} onChange={e => setDescription(e.target.value)} placeholder="Detailed content of the announcement..." rows={4}/>
            </div>
            <div>
              <Label htmlFor="annPriority">Priority</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger id="annPriority"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {announcementPriorities.map(p => <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="annTargetUser">Target User</Label>
              <Select value={targetUserId} onValueChange={setTargetUserId} disabled={!!editingAnnouncement && editingAnnouncement.user_id !== null}>
                <SelectTrigger id="annTargetUser"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Users (Global)</SelectItem>
                  {allUsers.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email} ({u.id.substring(0,8)}...)</SelectItem>)}
                </SelectContent>
              </Select>
              {editingAnnouncement && editingAnnouncement.user_id && (
                 <p className="text-xs text-muted-foreground mt-1">Targeting cannot be changed for existing specific-user announcements.</p>
              )}
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
            <Button onClick={handleSubmit} disabled={loading || !title.trim()}>{loading ? 'Saving...' : (editingAnnouncement ? 'Save Changes' : 'Create Announcement')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminAnnouncementsPage;