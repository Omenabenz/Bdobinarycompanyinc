import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Users, UserPlus, Search, Filter, Eye, Send, MessageSquare, Bell as BellIcon } from 'lucide-react';
import { formatInManilaTime } from '@/lib/utils';
import CreateUserModal from '@/components/admin/users/CreateUserModal';
import EditUserModal from '@/components/admin/users/EditUserModal';
import AdjustBalanceModal from '@/components/admin/users/AdjustBalanceModal';
import SendNotificationModal from '@/components/admin/users/SendNotificationModal';

const AdminUsersManagementPage = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const [isCreateUserModalOpen, setIsCreateUserModalOpen] = useState(false);
  const [isEditUserModalOpen, setIsEditUserModalOpen] = useState(false);
  const [isBalanceModalOpen, setIsBalanceModalOpen] = useState(false);
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState(false);
  
  const [selectedUser, setSelectedUser] = useState(null);

  const userRoles = ['user', 'admin'];
  const userStatuses = ['active', 'suspended', 'pending_verification'];

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('profiles')
        .select(`
          id, 
          full_name, 
          email, 
          phone_number, 
          avatar_url, 
          role, 
          status, 
          created_at, 
          updated_at,
          user_balances (current_balance)
        `)
        .order('created_at', { ascending: false });

      if(filterRole !== 'all') query = query.eq('role', filterRole);
      if(filterStatus !== 'all') query = query.eq('status', filterStatus);
      
      if(searchTerm) {
        query = query.or(`full_name.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%,id.ilike.%${searchTerm}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      setUsers(data.map(u => ({...u, current_balance: u.user_balances[0]?.current_balance || 0 })) || []);
    } catch (error) {
      toast({ title: "Error Fetching Users", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  }, [filterRole, filterStatus, searchTerm]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const handleOpenModal = (modalSetter, user = null) => {
    setSelectedUser(user);
    modalSetter(true);
  };
  
  const filteredUsers = users; // Filtering is now done in Supabase query via fetchUsers dependencies

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div>
            <CardTitle className="flex items-center text-2xl">
              <Users className="w-7 h-7 mr-3 text-primary" />
              Users Management
            </CardTitle>
            <CardDescription>Oversee and manage all user accounts.</CardDescription>
          </div>
          <Button onClick={() => handleOpenModal(setIsCreateUserModalOpen)} className="mt-4 sm:mt-0">
            <UserPlus className="w-4 h-4 mr-2" /> Create New User
          </Button>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="relative w-full md:w-1/3">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input 
                placeholder="Search by name, email, ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full"
              />
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-2 w-full md:w-auto">
              <div className="flex items-center gap-1 w-full sm:w-auto">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={filterRole} onValueChange={setFilterRole}>
                  <SelectTrigger className="w-full sm:w-[140px]">
                    <SelectValue placeholder="Filter by role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    {userRoles.map(role => (
                      <SelectItem key={role} value={role} className="capitalize">{role}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-1 w-full sm:w-auto">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-full sm:w-[160px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    {userStatuses.map(status => (
                      <SelectItem key={status} value={status} className="capitalize">{status.replace(/_/g, ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-center py-8">Loading users...</p>
          ) : filteredUsers.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">No users found matching your criteria.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Balance</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="font-medium">{user.full_name || 'N/A'}</div>
                        <div className="text-xs text-muted-foreground">{user.email}</div>
                      </TableCell>
                      <TableCell className="capitalize">{user.role}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 text-xs rounded-full capitalize ${
                          user.status === 'active' ? 'bg-green-100 text-green-700' :
                          user.status === 'suspended' ? 'bg-red-100 text-red-700' :
                          user.status === 'pending_verification' ? 'bg-yellow-100 text-yellow-700' : ''
                        }`}>
                          {user.status.replace(/_/g, ' ')}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">₱{(user.current_balance || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</TableCell>
                      <TableCell className="text-xs">{formatInManilaTime(new Date(user.created_at), 'PP')}</TableCell>
                      <TableCell className="flex items-center space-x-1">
                        <Button variant="ghost" size="icon" onClick={() => handleOpenModal(setIsEditUserModalOpen, user)} title="Edit User">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleOpenModal(setIsBalanceModalOpen, user)} title="Adjust Balance">
                          <MessageSquare className="h-4 w-4" /> {/* Changed icon to MessageSquare for balance -> better: DollarSign */}
                        </Button>
                         <Button variant="ghost" size="icon" onClick={() => handleOpenModal(setIsNotificationModalOpen, user)} title="Send Notification">
                          <BellIcon className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        {filteredUsers.length > 10 && (
            <CardFooter className="justify-center border-t pt-4">
                <p className="text-xs text-muted-foreground">Showing {filteredUsers.length} users.</p>
            </CardFooter>
        )}
      </Card>

      {isCreateUserModalOpen && (
        <CreateUserModal 
          isOpen={isCreateUserModalOpen} 
          onClose={() => setIsCreateUserModalOpen(false)} 
          onUserCreated={fetchUsers} 
        />
      )}
      {isEditUserModalOpen && selectedUser && (
        <EditUserModal 
          isOpen={isEditUserModalOpen} 
          onClose={() => setIsEditUserModalOpen(false)} 
          user={selectedUser}
          onUserUpdated={fetchUsers}
        />
      )}
      {isBalanceModalOpen && selectedUser && (
        <AdjustBalanceModal 
          isOpen={isBalanceModalOpen} 
          onClose={() => setIsBalanceModalOpen(false)} 
          user={selectedUser}
          onBalanceAdjusted={fetchUsers}
        />
      )}
       {isNotificationModalOpen && selectedUser && (
        <SendNotificationModal
          isOpen={isNotificationModalOpen}
          onClose={() => setIsNotificationModalOpen(false)}
          user={selectedUser}
        />
      )}
    </div>
  );
};

export default AdminUsersManagementPage;