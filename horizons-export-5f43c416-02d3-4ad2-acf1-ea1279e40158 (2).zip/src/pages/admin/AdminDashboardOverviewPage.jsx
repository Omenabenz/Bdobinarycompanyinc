import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Users, DollarSign, AlertTriangle, BarChartBig, ListChecks, TrendingUp, TrendingDown, CheckCircle, Clock } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { formatInManilaTime } from '@/lib/utils';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const StatCard = ({ title, value, icon, description, trend, linkTo }) => {
  const IconComponent = icon;
  return (
    <Card className="shadow-md hover:shadow-lg transition-shadow rounded-xl">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-slate-600">{title}</CardTitle>
        <IconComponent className="h-5 w-5 text-blue-500" />
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold text-slate-800">{value}</div>
        {description && <p className="text-xs text-slate-500 pt-1">{description}</p>}
        {trend && <p className={`text-xs ${trend.startsWith('+') ? 'text-green-600' : 'text-red-600'} pt-1`}>{trend}</p>}
        {linkTo && (
          <Button variant="link" asChild className="p-0 h-auto text-xs text-blue-600 mt-1">
            <Link to={linkTo}>View Details</Link>
          </Button>
        )}
      </CardContent>
    </Card>
  );
};

const TransactionItem = ({ transaction }) => {
  let Icon, color, prefix;
  switch (transaction.type) {
    case 'deposit': Icon = TrendingUp; color = 'text-green-500'; prefix = '+'; break;
    case 'withdrawal_request': Icon = TrendingDown; color = 'text-red-500'; prefix = '-'; break;
    default: Icon = ListChecks; color = 'text-slate-500'; prefix = '';
  }
  let StatusIcon = Clock;
  let statusColor = 'text-yellow-500';
  if (transaction.status === 'approved' || transaction.status === 'completed') { StatusIcon = CheckCircle; statusColor = 'text-green-500'; }
  if (transaction.status === 'failed' || transaction.status === 'rejected' || transaction.status === 'declined') { StatusIcon = AlertTriangle; statusColor = 'text-red-500'; }


  return (
    <li className="flex items-center justify-between py-3 px-2 border-b border-slate-100 last:border-b-0 hover:bg-slate-50 rounded-md">
      <div className="flex items-center space-x-3">
        <Icon className={`h-5 w-5 ${color}`} />
        <div>
          <p className="text-sm font-medium text-slate-700 capitalize">{transaction.description || transaction.type.replace('_', ' ')}</p>
          <p className="text-xs text-slate-500">
            User: {transaction.profiles?.full_name || transaction.user_id.substring(0,8)}...
            <span className="ml-2">({formatInManilaTime(new Date(transaction.created_at), 'MMM d, HH:mm')})</span>
          </p>
        </div>
      </div>
      <div className="flex items-center space-x-2">
        <p className={`text-sm font-semibold ${color}`}>
          {prefix}₱{Math.abs(transaction.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
        </p>
        <StatusIcon className={`h-4 w-4 ${statusColor}`} title={transaction.status}/>
      </div>
    </li>
  );
};


const AdminDashboardOverviewPage = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalFunds: 0,
    pendingWithdrawals: 0,
    activeInvestments: 0,
  });
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      try {
        // Fetch total users
        const { count: usersCount, error: usersError } = await supabase
          .from('profiles')
          .select('*', { count: 'exact', head: true });
        if (usersError) throw usersError;

        // Fetch total funds (sum of all user_balances)
        const { data: fundsData, error: fundsError } = await supabase
          .from('user_balances')
          .select('current_balance');
        if (fundsError) throw fundsError;
        const totalFunds = fundsData.reduce((sum, item) => sum + parseFloat(item.current_balance || 0), 0);
        
        // Fetch pending withdrawals
        const { count: pendingWithdrawalsCount, error: withdrawalsError } = await supabase
          .from('transactions')
          .select('*', { count: 'exact', head: true })
          .eq('type', 'withdrawal_request')
          .eq('status', 'pending');
        if (withdrawalsError) throw withdrawalsError;

        // Fetch active investments
        const { count: activeInvestmentsCount, error: investmentsError } = await supabase
          .from('investments')
          .select('*', { count: 'exact', head: true })
          .eq('status', 'active'); // Assuming 'active' status for investments
        if (investmentsError) throw investmentsError;

        setStats({
          totalUsers: usersCount || 0,
          totalFunds: totalFunds,
          pendingWithdrawals: pendingWithdrawalsCount || 0,
          activeInvestments: activeInvestmentsCount || 0,
        });

        // Fetch recent transactions
        const { data: transactionsData, error: transactionsError } = await supabase
          .from('transactions')
          .select('*, profiles(full_name)') // Join with profiles to get user name
          .order('created_at', { ascending: false })
          .limit(5);
        if (transactionsError) throw transactionsError;
        setRecentTransactions(transactionsData || []);

      } catch (error) {
        console.error("Error fetching admin dashboard data:", error);
        toast({ title: "Error Loading Data", description: error.message, variant: "destructive" });
      }
      setLoading(false);
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return <div className="flex justify-center items-center h-full"><p>Loading dashboard data...</p></div>;
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Total Users" value={stats.totalUsers.toLocaleString()} icon={Users} linkTo="/admin/users" />
        <StatCard title="Total Funds Under Management" value={`₱${stats.totalFunds.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`} icon={DollarSign} />
        <StatCard title="Pending Withdrawals" value={stats.pendingWithdrawals.toLocaleString()} icon={AlertTriangle} linkTo="/admin/withdrawals" />
        <StatCard title="Active Investments" value={stats.activeInvestments.toLocaleString()} icon={BarChartBig} linkTo="/admin/investments" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 shadow-md rounded-xl">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800">Recent Transactions</CardTitle>
            <CardDescription>Overview of the latest platform activities.</CardDescription>
          </CardHeader>
          <CardContent>
            {recentTransactions.length > 0 ? (
              <ul className="space-y-1">
                {recentTransactions.map(tx => <TransactionItem key={tx.id} transaction={tx} />)}
              </ul>
            ) : (
              <p className="text-slate-500 text-center py-4">No recent transactions.</p>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-md rounded-xl">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-slate-800">System Overview Graph</CardTitle>
            <CardDescription>Visual representation of key metrics (Placeholder).</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center h-64 bg-slate-50 rounded-b-xl">
            <p className="text-slate-400">Graph will be displayed here.</p>
            {/* Placeholder for a chart component */}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboardOverviewPage;