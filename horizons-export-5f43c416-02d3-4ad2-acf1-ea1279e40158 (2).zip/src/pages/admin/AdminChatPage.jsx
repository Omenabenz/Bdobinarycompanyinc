import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from '@/components/ui/use-toast';
import { Send, Paperclip, ArrowLeft, UserCircle, CheckCircle, XCircle, Clock, Image as ImageIcon, FileText } from 'lucide-react';
import { formatDistanceToNowStrict } from 'date-fns';
import { formatInManilaTime } from '@/lib/utils';

const AdminChatPage = () => {
  const { sessionId } = useParams();
  const navigate = useNavigate();
  const { user: adminUser, profile: adminProfile, isAdmin, logUserActivity } = useAuth(); // Admin's own user/profile if they are a Supabase user
  
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [chatSession, setChatSession] = useState(null);
  const [chatUser, setChatUser] = useState(null); // The user admin is chatting with
  const [loading, setLoading] = useState(false); // For sending messages
  const [sessionLoading, setSessionLoading] = useState(true); // For loading session
  const [attachment, setAttachment] = useState(null);
  const [attachmentPreview, setAttachmentPreview] = useState(null);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  const adminDisplayId = adminUser?.id || 'ADMIN_CONSOLE'; // Use admin's actual ID if available

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const fetchChatData = useCallback(async () => {
    if (!isAdmin) {
      toast({ title: "Access Denied", description: "You are not authorized to view this page.", variant: "destructive" });
      navigate('/admin/login');
      return;
    }
    setSessionLoading(true);
    try {
      const { data: sessionData, error: sessionError } = await supabase
        .from('chat_sessions')
        .select('*, user:user_id(*), transaction:related_transaction_id(*)') // Corrected foreign key names
        .eq('id', sessionId)
        .single();

      if (sessionError || !sessionData) throw sessionError || new Error("Chat session not found.");
      setChatSession(sessionData);
      setChatUser(sessionData.user);

      const { data: messagesData, error: messagesError } = await supabase
        .from('chat_messages')
        .select('*, sender:sender_id ( id, full_name, avatar_url )') // Fetch sender's profile
        .eq('session_id', sessionId)
        .order('created_at', { ascending: true });
      
      if (messagesError) throw messagesError;
      setMessages(messagesData || []);

      // Mark messages as read by admin
      await supabase
        .from('chat_messages')
        .update({ is_read_by_admin: true })
        .eq('session_id', sessionId)
        .eq('is_read_by_admin', false)
        .neq('sender_id', adminDisplayId); // Don't mark admin's own messages as read by admin

    } catch (error) {
      toast({ title: "Error Loading Chat", description: error.message, variant: "destructive" });
      navigate('/admin/deposit-chat');
    }
    setSessionLoading(false);
  }, [sessionId, isAdmin, navigate, adminDisplayId]);

  useEffect(() => {
    fetchChatData();
  }, [fetchChatData]);

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    const channel = supabase
      .channel(`admin_chat_${sessionId}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `session_id=eq.${sessionId}` },
        async (payload) => {
          let senderProfile = null;
          if (payload.new.sender_id !== adminDisplayId && payload.new.sender_id !== chatUser?.id) { 
             const { data: profileData } = await supabase.from('profiles').select('full_name, avatar_url').eq('id', payload.new.sender_id).single();
             senderProfile = profileData;
          } else if (payload.new.sender_id === chatUser?.id) {
            senderProfile = chatUser; 
          }
          const messageWithSender = {
            ...payload.new,
            sender: senderProfile ? { id: payload.new.sender_id, ...senderProfile } : { id: payload.new.sender_id, full_name: (payload.new.sender_id === adminDisplayId ? 'Admin' : 'User'), avatar_url: null }
          };
          setMessages(prevMessages => [...prevMessages, messageWithSender]);

          if (payload.new.sender_id !== adminDisplayId) {
            supabase
              .from('chat_messages')
              .update({ is_read_by_admin: true })
              .eq('id', payload.new.id)
              .then();
          }
        }
      )
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'chat_sessions', filter: `id=eq.${sessionId}`},
        (payload) => {
            fetchChatData(); // Re-fetch all data if session itself updates
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [sessionId, adminDisplayId, chatUser, fetchChatData]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() && !attachment) return;
    setLoading(true);

    let attachmentUrl = null;
    let messageType = 'text';

    if (attachment) {
      const fileExt = attachment.name.split('.').pop();
      const fileName = `chat_attachments/${sessionId}/${Date.now()}.${fileExt}`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('chat_attachments') 
        .upload(fileName, attachment);

      if (uploadError) {
        toast({ title: "Attachment Upload Failed", description: uploadError.message, variant: "destructive" });
        setLoading(false);
        return;
      }
      attachmentUrl = supabase.storage.from('chat_attachments').getPublicUrl(fileName).data.publicUrl;
      messageType = attachment.type.startsWith('image/') ? 'image_proof' : 'file_attachment';
    }

    try {
      const { error } = await supabase.from('chat_messages').insert({
        session_id: sessionId,
        sender_id: adminDisplayId, 
        message_content: newMessage.trim() || (messageType === 'image_proof' ? 'Proof of payment uploaded.' : 'File attached.'),
        attachment_url: attachmentUrl,
        message_type: attachmentUrl ? messageType : 'text',
        is_read_by_user: false,
        is_read_by_admin: true, 
      });
      if (error) throw error;
      
      await supabase.from('chat_sessions')
        .update({ updated_at: new Date().toISOString(), status: 'pending_user_reply' })
        .eq('id', sessionId);

      setNewMessage('');
      setAttachment(null);
      setAttachmentPreview(null);
      if(fileInputRef.current) fileInputRef.current.value = "";
      logUserActivity(adminDisplayId, 'ADMIN_CHAT_MESSAGE_SENT', `Admin sent message in chat ${sessionId}`);
    } catch (error) {
      toast({ title: "Error Sending Message", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleAttachmentChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({ title: "File Too Large", description: "Attachment must be under 5MB.", variant: "destructive"});
        return;
      }
      setAttachment(file);
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => setAttachmentPreview(reader.result);
        reader.readAsDataURL(file);
      } else {
        setAttachmentPreview(null);
      }
    }
  };

  const handleTransactionStatusUpdate = async (newStatus) => {
    if (!chatSession?.transaction?.id) {
        toast({title: "Error", description: "No linked transaction found for this chat.", variant: "destructive"});
        return;
    }
    setLoading(true);
    try {
        const updates = {
            status: newStatus,
            updated_at: new Date().toISOString(),
            admin_notes: `Status updated to ${newStatus} via deposit chat by Company.`
        };

        if (newStatus === 'completed' && chatSession.transaction.type === 'deposit_initiated' && chatSession.transaction.status !== 'completed') {
            const { data: balanceData, error: fetchError } = await supabase
                .from('user_balances')
                .select('current_balance')
                .eq('user_id', chatSession.user_id)
                .single();
            if (fetchError && fetchError.code !== 'PGRST116') throw fetchError;
            
            const currentBalance = parseFloat(balanceData?.current_balance || 0);
            const depositAmount = parseFloat(chatSession.transaction.amount);
            const finalBalance = currentBalance + depositAmount;

            const { error: balanceUpdateError } = await supabase
                .from('user_balances')
                .update({ current_balance: finalBalance, last_updated: new Date().toISOString() })
                .eq('user_id', chatSession.user_id);
            if (balanceUpdateError) throw balanceUpdateError;
            
            updates.type = 'deposit'; // Change type from deposit_initiated to deposit
            updates.description = `Deposit of ₱${depositAmount.toFixed(2)} completed.`;
            toast({title: "User Balance Updated", description: `₱${depositAmount.toFixed(2)} credited to user.`});
        }


        const { error } = await supabase
            .from('transactions')
            .update(updates)
            .eq('id', chatSession.transaction.id);
        if (error) throw error;

        await supabase.from('chat_sessions')
            .update({ status: newStatus === 'completed' ? 'closed_completed' : (newStatus === 'failed' || newStatus === 'declined' ? 'closed_failed' : 'pending_user_reply')})
            .eq('id', sessionId);

        await supabase.from('notifications').insert({
            user_id: chatSession.user_id,
            type: 'transaction_update',
            message: `Company update on your deposit (Ref: ${chatSession.transaction.reference_number}): Status changed to ${newStatus}.`,
            link_to: `/dashboard/transactions/receipt/${chatSession.transaction.transaction_uid || chatSession.transaction.id}`
        });

        toast({title: "Transaction Updated", description: `Deposit status set to ${newStatus}.`});
        logUserActivity(adminDisplayId, 'ADMIN_UPDATE_DEPOSIT_STATUS', `Admin set deposit ${chatSession.transaction.id} to ${newStatus} via chat.`);
        fetchChatData(); 
    } catch (error) {
        toast({title: "Status Update Failed", description: error.message, variant: "destructive"});
    }
    setLoading(false);
  };


  if (sessionLoading && !chatSession) {
    return <div className="p-6 text-center">Loading chat session...</div>;
  }
  if (!chatSession) {
    return <div className="p-6 text-center text-red-500">Chat session not found or access denied.</div>;
  }
  
  const getSenderInitials = (sender) => {
    if (sender?.full_name) return sender.full_name.split(' ').map(n=>n[0]).join('').toUpperCase();
    if (sender?.email) return sender.email[0].toUpperCase(); 
    return 'U';
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)]"> 
      <Card className="flex-1 flex flex-col shadow-none border-0 rounded-none">
        <CardHeader className="p-4 border-b bg-slate-50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="icon" onClick={() => navigate('/admin/deposit-chat')} className="text-slate-600">
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <Avatar className="h-10 w-10">
                <AvatarImage src={chatUser?.avatar_url || undefined} />
                <AvatarFallback>{getSenderInitials(chatUser)}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-base font-semibold text-slate-800">{chatUser?.full_name || 'User'}</CardTitle>
                <p className="text-xs text-slate-500">{chatUser?.email}</p>
              </div>
            </div>
            {chatSession.transaction && chatSession.session_type === 'deposit_chat' && (
                 <div className="text-right">
                    <p className="text-xs text-slate-500">Deposit: ₱{chatSession.transaction.amount?.toLocaleString()}</p>
                    <p className={`text-xs font-medium capitalize ${
                        chatSession.transaction.status === 'completed' ? 'text-green-600' :
                        chatSession.transaction.status === 'pending_payment' || chatSession.transaction.status === 'pending_confirmation' ? 'text-yellow-600' :
                        chatSession.transaction.status === 'failed' ? 'text-red-600' : 'text-slate-600'
                    }`}>
                        Status: {chatSession.transaction.status.replace(/_/g, ' ')}
                    </p>
                 </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-100">
          {messages.map((msg, index) => (
            <div key={msg.id || index} className={`flex ${msg.sender_id === adminDisplayId ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-xs md:max-w-md lg:max-w-lg p-3 rounded-xl shadow ${
                msg.sender_id === adminDisplayId 
                ? 'bg-blue-600 text-white rounded-br-none' 
                : 'bg-white text-slate-700 rounded-bl-none border'
              }`}>
                {msg.sender_id !== adminDisplayId && (
                    <p className="text-xs font-semibold mb-1 text-slate-500">{msg.sender?.full_name || chatUser?.full_name || 'User'}</p>
                )}
                {msg.message_content && <p className="text-sm whitespace-pre-wrap">{msg.message_content}</p>}
                {msg.attachment_url && (
                  <a href={msg.attachment_url} target="_blank" rel="noopener noreferrer" className={`mt-2 flex items-center space-x-2 p-2 rounded-md ${msg.sender_id === adminDisplayId ? 'bg-blue-500 hover:bg-blue-400' : 'bg-gray-100 hover:bg-gray-200'}`}>
                    {msg.message_type === 'image_proof' || msg.attachment_url.match(/\.(jpeg|jpg|gif|png)$/i) ? 
                      <img src={msg.attachment_url} alt="Proof" className="max-w-[150px] max-h-32 rounded" /> :
                      <>
                        <FileText className="h-5 w-5 flex-shrink-0" />
                        <span className="text-xs truncate max-w-[150px]">{msg.attachment_url.split('/').pop().split('?')[0].split('%2F').pop().substring(14)}</span>
                      </>
                    }
                  </a>
                )}
                <p className={`text-xs mt-1 ${msg.sender_id === adminDisplayId ? 'text-blue-200 text-right' : 'text-slate-400 text-left'}`}>
                  {formatDistanceToNowStrict(new Date(msg.created_at), { addSuffix: true })}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </CardContent>
        <CardFooter className="p-4 border-t bg-slate-50 space-y-2">
          {chatSession.session_type === 'deposit_chat' && chatSession.transaction && chatSession.transaction.status !== 'completed' && chatSession.transaction.status !== 'failed' && chatSession.transaction.status !== 'declined' && (
            <div className="flex flex-wrap gap-2 mb-2">
                <Button onClick={() => handleTransactionStatusUpdate('completed')} size="sm" variant="outline" className="text-green-600 border-green-600 hover:bg-green-50">
                    <CheckCircle className="w-4 h-4 mr-1.5"/> Mark as Completed
                </Button>
                <Button onClick={() => handleTransactionStatusUpdate('pending_confirmation')} size="sm" variant="outline" className="text-yellow-600 border-yellow-600 hover:bg-yellow-50">
                    <Clock className="w-4 h-4 mr-1.5"/> Set to Pending Confirmation
                </Button>
                <Button onClick={() => handleTransactionStatusUpdate('failed')} size="sm" variant="outline" className="text-red-600 border-red-600 hover:bg-red-50">
                    <XCircle className="w-4 h-4 mr-1.5"/> Mark as Failed
                </Button>
            </div>
          )}
          <div className="flex items-center space-x-2">
            <Textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 resize-none bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500"
              rows={1}
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              disabled={loading}
            />
            <label htmlFor="chat-attachment-admin" className="cursor-pointer">
              <Paperclip className="h-5 w-5 text-slate-500 hover:text-blue-600" />
              <input id="chat-attachment-admin" type="file" className="hidden" onChange={handleAttachmentChange} disabled={loading} ref={fileInputRef}/>
            </label>
            <Button onClick={handleSendMessage} disabled={loading || (!newMessage.trim() && !attachment)} className="bg-blue-600 hover:bg-blue-700">
              <Send className="h-5 w-5" />
            </Button>
          </div>
          {attachmentPreview && attachment?.type.startsWith('image/') && (
            <div className="p-2 border-t bg-white">
              <img src={attachmentPreview} alt="Preview" className="max-h-20 rounded" />
            </div>
          )}
          {attachment && !attachment?.type.startsWith('image/') && (
            <div className="p-2 border-t bg-white text-sm text-gray-600">
              Selected file: {attachment.name} ({ (attachment.size / 1024).toFixed(1) } KB)
            </div>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default AdminChatPage;