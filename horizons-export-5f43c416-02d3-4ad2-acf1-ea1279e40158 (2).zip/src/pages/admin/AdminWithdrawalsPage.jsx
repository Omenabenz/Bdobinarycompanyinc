import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { ArrowDownCircle, Edit, Eye, Filter, Search, CheckCircle, Clock, AlertCircle, Info } from 'lucide-react';
import { formatInManilaTime } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';


const withdrawalStatuses = ['all', 'pending', 'processing', 'approved', 'on_hold', 'declined', 'failed', 'completed']; 

const WithdrawalStatusIcon = ({ status }) => {
  switch (status) {
    case 'approved':
    case 'completed':
      return <CheckCircle className="w-4 h-4 text-green-500" />;
    case 'pending':
      return <Clock className="w-4 h-4 text-yellow-500" />;
    case 'processing':
      return <Clock className="w-4 h-4 text-blue-500" />;
    case 'declined':
    case 'failed':
      return <AlertCircle className="w-4 h-4 text-red-500" />;
    case 'on_hold':
      return <Info className="w-4 h-4 text-orange-500" />;
    default:
      return <Clock className="w-4 h-4 text-gray-500" />;
  }
};

const AdminWithdrawalsPage = () => {
  const { user: adminUser } = useAuth(); // Admin user performing the action
  const [withdrawals, setWithdrawals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  
  const [editingWithdrawal, setEditingWithdrawal] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editStatus, setEditStatus] = useState('');
  const [editAdminNotes, setEditAdminNotes] = useState(''); // Internal notes
  const [editCompanyInstructions, setEditCompanyInstructions] = useState(''); // For user, was status_reason

  useEffect(() => {
    fetchWithdrawals();
  }, []);

  const fetchWithdrawals = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('transactions')
        .select(`
          id, user_id, transaction_uid, reference_number, amount, status, description, created_at, updated_at, meta_data, admin_notes, status_reason,
          user:profiles (id, full_name, email)
        `)
        .in('type', ['withdrawal_request', 'withdrawal']) // 'withdrawal' for already processed ones
        .order('created_at', { ascending: false });

      if (error) throw error;
      setWithdrawals(data || []);
    } catch (error) {
      toast({ title: "Error Fetching Withdrawals", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleEditWithdrawal = (withdrawal) => {
    setEditingWithdrawal(withdrawal);
    setEditStatus(withdrawal.status);
    setEditAdminNotes(withdrawal.admin_notes || '');
    setEditCompanyInstructions(withdrawal.status_reason || ''); // status_reason is for user
    setIsEditModalOpen(true);
  };

  const handleSaveWithdrawalChanges = async () => {
    if (!editingWithdrawal || !adminUser) return;
    setLoading(true);

    const originalStatus = editingWithdrawal.status;
    const newStatus = editStatus;

    try {
      const updates = {
        status: newStatus,
        admin_notes: editAdminNotes, // Internal notes
        status_reason: editCompanyInstructions, // Instructions for user
        updated_at: new Date().toISOString(),
      };

      // If status changes to 'completed' or 'approved' from a pending-like state, ensure type is 'withdrawal'
      if ((newStatus === 'completed' || newStatus === 'approved') && editingWithdrawal.type === 'withdrawal_request') {
        updates.type = 'withdrawal';
      }

      // Handle balance refund if withdrawal is declined/failed from a state where funds were deducted
      if ((newStatus === 'failed' || newStatus === 'declined') && 
          (originalStatus === 'pending' || originalStatus === 'processing' || originalStatus === 'on_hold')) {
        
        const { data: balanceData, error: fetchError } = await supabase
            .from('user_balances')
            .select('current_balance')
            .eq('user_id', editingWithdrawal.user_id)
            .single();
        if (fetchError && fetchError.code !== 'PGRST116') throw fetchError;
        
        const currentBalance = parseFloat(balanceData?.current_balance || 0);
        const withdrawalAmount = Math.abs(parseFloat(editingWithdrawal.amount)); 
        const finalBalance = currentBalance + withdrawalAmount;

        const { error: balanceUpdateError } = await supabase
            .from('user_balances')
            .update({ current_balance: finalBalance, last_updated: new Date().toISOString() })
            .eq('user_id', editingWithdrawal.user_id);
        if (balanceUpdateError) throw balanceUpdateError;
        
        toast({title: "User Balance Refunded", description: `₱${withdrawalAmount.toFixed(2)} credited back to user due to ${newStatus} withdrawal.`});
        
        // Log this refund as a system transaction or adjust original transaction
        // For simplicity, we assume the original transaction is just marked as failed/declined.
      }

      const { error: updateError } = await supabase
        .from('transactions')
        .update(updates)
        .eq('id', editingWithdrawal.id);
      
      if (updateError) throw updateError;

      // Log status change to status_history
      await supabase.from('status_history').insert({
        transaction_id: editingWithdrawal.id,
        changed_by_user_id: adminUser.id, 
        previous_status: originalStatus,
        new_status: newStatus,
        reason: editCompanyInstructions, // This is for user
        notes: editAdminNotes // Internal notes
      });
      
      // Send notification to user
      await supabase.from('notifications').insert({
        user_id: editingWithdrawal.user_id,
        type: 'transaction_update', 
        message: `Update on your withdrawal (Ref: ${editingWithdrawal.reference_number || editingWithdrawal.transaction_uid.substring(0,8) + '...'}): Status changed to ${newStatus}. ${editCompanyInstructions ? `Company Instructions: ${editCompanyInstructions}` : ''}`,
        link_to: `/dashboard/transactions/receipt/${editingWithdrawal.transaction_uid || editingWithdrawal.id}`
      });

      // Simulate sending email
      const { data: userProfile, error: profileError } = await supabase.from('profiles').select('full_name, email').eq('id', editingWithdrawal.user_id).single();
      if (profileError) console.warn("Could not fetch user profile for email:", profileError.message);

      const { error: emailError } = await supabase.functions.invoke('send-withdrawal-email', {
        body: JSON.stringify({
          to_email: userProfile?.email || 'user@example.com',
          user_name: userProfile?.full_name || 'Valued User',
          subject: `Withdrawal Status Update – Ref: ${editingWithdrawal.reference_number}`,
          transaction_ref: editingWithdrawal.reference_number,
          transaction_status: newStatus,
          company_instructions: editCompanyInstructions,
          email_type: 'status_update'
        })
      });
      if (emailError) console.warn("Email simulation error:", emailError.message);


      toast({ title: "Withdrawal Updated", description: "Withdrawal status and details saved." });
      setIsEditModalOpen(false);
      setEditingWithdrawal(null);
      fetchWithdrawals(); 
    } catch (error) {
      toast({ title: "Update Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const filteredWithdrawals = withdrawals.filter(wd => {
    const matchesSearch = 
      (wd.user?.full_name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (wd.user?.email?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (wd.transaction_uid?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (wd.reference_number?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (wd.meta_data?.bank_name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (wd.meta_data?.account_number?.toLowerCase() || '').includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || wd.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center text-2xl">
            <ArrowDownCircle className="w-7 h-7 mr-3 text-primary" />
            Withdrawal Requests
          </CardTitle>
          <CardDescription>Manage and process user withdrawal requests.</CardDescription>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input 
                placeholder="Search by user, ID, bank..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full"
              />
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Filter className="h-5 w-5 text-muted-foreground" />
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  {withdrawalStatuses.map(status => (
                    <SelectItem key={status} value={status} className="capitalize">{status.replace(/_/g, ' ')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-center py-8">Loading withdrawals...</p>
          ) : filteredWithdrawals.length === 0 ? (
            <p className="text-center py-8 text-muted-foreground">No withdrawals found matching your criteria.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Bank Details</TableHead>
                    <TableHead className="text-right">Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Requested At</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredWithdrawals.map((withdrawal) => (
                    <TableRow key={withdrawal.id}>
                      <TableCell>
                        <div className="font-medium">{withdrawal.user?.full_name || 'N/A'}</div>
                        <div className="text-xs text-muted-foreground">{withdrawal.user?.email || withdrawal.user_id}</div>
                      </TableCell>
                      <TableCell className="text-xs">
                        <div>{withdrawal.meta_data?.bank_name || 'N/A'}</div>
                        <div>{withdrawal.meta_data?.account_name || 'N/A'}</div>
                        <div>{withdrawal.meta_data?.account_number || 'N/A'}</div>
                      </TableCell>
                      <TableCell className="text-right font-medium text-red-600">
                        ₱{Math.abs(withdrawal.amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                            <WithdrawalStatusIcon status={withdrawal.status} />
                            <span className="capitalize text-xs">{withdrawal.status.replace(/_/g, ' ')}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs">{formatInManilaTime(new Date(withdrawal.created_at), 'PPp')}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" onClick={() => handleEditWithdrawal(withdrawal)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        {filteredWithdrawals.length > 10 && (
            <CardFooter className="justify-center border-t pt-4">
                <p className="text-xs text-muted-foreground">Showing {filteredWithdrawals.length} withdrawals.</p>
            </CardFooter>
        )}
      </Card>

      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Process Withdrawal Request</DialogTitle>
            <DialogDescription>
              User: {editingWithdrawal?.user?.full_name} ({editingWithdrawal?.user?.email})
              <br/>Amount: ₱{editingWithdrawal ? Math.abs(editingWithdrawal.amount).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2}) : '0.00'}
              <br/>To: {editingWithdrawal?.meta_data?.bank_name} - {editingWithdrawal?.meta_data?.account_number} ({editingWithdrawal?.meta_data?.account_name})
              <br/>Ref: {editingWithdrawal?.reference_number}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="editStatus">Status</Label>
              <Select value={editStatus} onValueChange={setEditStatus}>
                <SelectTrigger id="editStatus" className="mt-1">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  {withdrawalStatuses.filter(s => s !== 'all').map(status => (
                    <SelectItem key={status} value={status} className="capitalize">{status.replace(/_/g, ' ')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="editCompanyInstructions">Company Instructions (Visible to User)</Label>
              <Textarea 
                id="editCompanyInstructions" 
                value={editCompanyInstructions} 
                onChange={(e) => setEditCompanyInstructions(e.target.value)} 
                className="mt-1"
                placeholder="Provide instructions or reasons for the user (e.g., 'Approved. Funds will reflect in 1-3 business days.')."
                rows={3}
              />
            </div>
            <div>
              <Label htmlFor="editAdminNotes">Internal Company Notes (Not visible to user)</Label>
              <Textarea 
                id="editAdminNotes" 
                value={editAdminNotes} 
                onChange={(e) => setEditAdminNotes(e.target.value)} 
                className="mt-1"
                placeholder="Internal notes for admin team only (e.g., 'Manual bank transfer initiated by John D.')."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="outline" disabled={loading}>Cancel</Button>
            </DialogClose>
            <Button type="button" onClick={handleSaveWithdrawalChanges} disabled={loading || !editStatus}>
              {loading ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminWithdrawalsPage;