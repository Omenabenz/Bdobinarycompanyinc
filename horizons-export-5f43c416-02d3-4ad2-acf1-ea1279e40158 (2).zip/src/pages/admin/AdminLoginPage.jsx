import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldCheck, KeyRound } from 'lucide-react';
import { motion } from 'framer-motion';

const AdminLoginPage = () => {
  const [accessCode, setAccessCode] = useState('');
  const [loading, setLoading] = useState(false);
  const { adminLoginWithAccessCode } = useAuth();
  const navigate = useNavigate();

  const handleAdminLogin = (e) => {
    e.preventDefault();
    setLoading(true);
    const success = adminLoginWithAccessCode(accessCode);
    if (success) {
      navigate('/admin/dashboard');
    }
    setLoading(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 p-4"
    >
      <Card className="w-full max-w-sm shadow-xl border-slate-700 bg-slate-800 text-slate-50">
        <CardHeader className="text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: "spring", stiffness: 200 }}>
            <ShieldCheck className="mx-auto h-12 w-12 text-primary mb-3" />
          </motion.div>
          <CardTitle className="text-2xl font-semibold">Company Access</CardTitle>
          <CardDescription className="text-slate-400">Enter your administrator access code.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAdminLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="accessCode" className="text-slate-300 flex items-center">
                <KeyRound className="mr-2 h-4 w-4 text-slate-400" /> Access Code
              </Label>
              <Input
                id="accessCode"
                type="password" 
                placeholder="Enter Access Code"
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value)}
                required
                className="bg-slate-700 border-slate-600 text-slate-50 placeholder:text-slate-500 focus:border-primary focus:ring-primary"
              />
            </div>
            <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 text-base" disabled={loading}>
              {loading ? 'Verifying...' : 'Enter Control Panel'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="text-center pt-6 border-t border-slate-700">
            <p className="text-xs text-slate-500">This portal is for authorized personnel only.</p>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default AdminLoginPage;