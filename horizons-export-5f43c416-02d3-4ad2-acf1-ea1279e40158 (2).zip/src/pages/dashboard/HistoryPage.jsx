import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Clock, Activity, Server, UserCheck } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { formatInManilaTime } from '@/lib/utils';

const ActivityIcon = ({ type }) => {
  switch (type.toUpperCase()) {
    case 'LOGIN':
    case 'LOGIN_SESSION_RESTORED':
      return <UserCheck className="w-5 h-5 text-green-500" />;
    case 'PROFILE_UPDATE':
    case 'BANK_DETAILS_UPDATE':
    case 'PASSWORD_CHANGE':
      return <Activity className="w-5 h-5 text-blue-500" />;
    case 'LOGOUT':
      return <Server className="w-5 h-5 text-red-500" />;
    default:
      return <Clock className="w-5 h-5 text-gray-500" />;
  }
};

const HistoryPage = () => {
  const { user } = useAuth();
  const [activityLog, setActivityLog] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchActivityLog = async () => {
      if (!user) return;
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('user_activity_log')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(50); // Limit to recent 50 activities

        if (error) throw error;
        setActivityLog(data || []);
      } catch (error) {
        console.error("Error fetching activity log:", error.message);
        toast({ title: "Error Fetching History", description: error.message, variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };
    fetchActivityLog();
  }, [user]);

  return (
    <div className="p-4 md:p-6">
      <Card className="shadow-lg rounded-xl">
        <CardHeader className="border-b">
          <CardTitle className="text-2xl font-semibold text-gray-800 flex items-center">
            <Clock className="w-7 h-7 mr-3 text-blue-600" /> Account Activity History
          </CardTitle>
          <CardDescription>Review your recent account activities and changes.</CardDescription>
        </CardHeader>
        <CardContent className="p-3 md:p-5">
          {loading && <p className="text-gray-500 text-center py-8">Loading activity history...</p>}
          {!loading && activityLog.length === 0 && (
            <p className="text-gray-500 text-center py-8">No account activity found.</p>
          )}
          {!loading && activityLog.length > 0 && (
            <ul className="space-y-3">
              {activityLog.map((item) => (
                <li key={item.id} className="p-4 border rounded-lg bg-gray-50 hover:shadow-sm transition-shadow flex items-start space-x-3">
                  <div className="flex-shrink-0 pt-1">
                    <ActivityIcon type={item.action_type} />
                  </div>
                  <div className="flex-grow">
                    <p className="font-medium text-gray-700 text-sm">
                      {item.action_type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </p>
                    {item.description && <p className="text-xs text-gray-500">{item.description}</p>}
                    <p className="text-xs text-gray-400 mt-0.5">
                      {formatInManilaTime(new Date(item.created_at), 'MMM d, yyyy, hh:mm:ss a')}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default HistoryPage;