import React, { useState, useEffect, useRef } from 'react';
import { useParams, useLocation, useNavigate, Link as RouterLink } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from '@/components/ui/use-toast';
import { Send, Paperclip, ArrowLeft, Image as ImageIcon, FileText, AlertCircle, MessageSquare } from 'lucide-react';
import { formatDistanceToNowStrict } from 'date-fns';
import { formatInManilaTime } from '@/lib/utils';

const ChatPage = () => {
  const { sessionId: routeSessionId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { user, profile } = useAuth();

  const [currentSessionId, setCurrentSessionId] = useState(routeSessionId);
  const [sessionDetails, setSessionDetails] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [attachmentPreview, setAttachmentPreview] = useState(null);
  const [loading, setLoading] = useState(false); // For sending messages
  const [sessionLoading, setSessionLoading] = useState(true); // For loading session and initial messages
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  const prefilledType = location.state?.type;
  const prefilledTransactionId = location.state?.transactionId;
  const prefilledMessage = location.state?.message;


  const getInitials = (name) => {
    if (!name) return 'U';
    const names = name.split(' ');
    return names.length > 1 ? `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase() : name.substring(0, 2).toUpperCase();
  };

  useEffect(() => {
    if (prefilledMessage && newMessage === '') {
      setNewMessage(prefilledMessage);
    }
  }, [prefilledMessage]);

  useEffect(() => {
    const initOrLoadSession = async () => {
      if (!user) return;
      setSessionLoading(true);

      if (routeSessionId) {
        setCurrentSessionId(routeSessionId);
        await fetchSessionDetails(routeSessionId);
        await fetchMessages(routeSessionId);
      } else if (prefilledType) {
        try {
          const { data, error } = await supabase
            .from('chat_sessions')
            .insert({
              user_id: user.id,
              session_type: prefilledType,
              related_transaction_id: prefilledTransactionId,
              status: prefilledType === 'deposit_chat' ? 'pending_admin_reply' : 'open'
            })
            .select()
            .single();
          if (error) throw error;
          
          setCurrentSessionId(data.id);
          setSessionDetails(data);
          await fetchMessages(data.id);
          navigate(`/dashboard/chat/${data.id}`, { replace: true, state: { type: prefilledType, transactionId: prefilledTransactionId } });
          toast({ title: "Chat Session Started", description: `New ${prefilledType.replace('_', ' ')} chat created.` });
        } catch (err) {
          toast({ title: "Error Starting Chat", description: err.message, variant: "destructive" });
          console.error("Error creating session:", err);
          navigate('/dashboard');
        }
      } else {
         console.log("No session ID and no prefilled type to create session.");
         setSessionLoading(false);
         return;
      }
      setSessionLoading(false);
    };
    initOrLoadSession();
  }, [user, routeSessionId, prefilledType, prefilledTransactionId, navigate]);

  const fetchSessionDetails = async (sessionId) => {
    try {
      const { data, error } = await supabase
        .from('chat_sessions')
        .select(`*, related_transaction_id:transactions ( id, transaction_uid, type, status, amount, reference_number )`)
        .eq('id', sessionId)
        .eq('user_id', user.id)
        .single();
      if (error) throw error;
      setSessionDetails(data);
    } catch (err) {
      toast({ title: "Error Fetching Session", description: err.message, variant: "destructive" });
    }
  };

  const fetchMessages = async (sessionId) => {
    if(!sessionId) return;
    try {
      const { data, error } = await supabase
        .from('chat_messages')
        .select(`*, sender:sender_id ( id, raw_user_meta_data->full_name, avatar_url )`) // Assuming admin might not have a profile, or sender_id is 'ADMIN_CONSOLE'
        .eq('session_id', sessionId)
        .order('created_at', { ascending: true });
      if (error) throw error;
      setMessages(data || []);
    } catch (err) {
      toast({ title: "Error Fetching Messages", description: err.message, variant: "destructive" });
    }
  };
  
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (!currentSessionId || !user) return;

    const channel = supabase
      .channel(`chat:${currentSessionId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `session_id=eq.${currentSessionId}` },
        async (payload) => {
          let senderProfile = null;
          if (payload.new.sender_id !== 'ADMIN_CONSOLE' && payload.new.sender_id !== user.id) { // If sender is not admin console and not current user (should be admin)
             const { data: adminProfileData } = await supabase.from('profiles').select('full_name, avatar_url').eq('id', payload.new.sender_id).single();
             senderProfile = adminProfileData;
          } else if (payload.new.sender_id === user.id) {
            senderProfile = profile; // Current user's profile
          }

          const messageWithSender = {
            ...payload.new,
            sender: senderProfile ? { id: payload.new.sender_id, ...senderProfile } : { id: payload.new.sender_id, full_name: 'Admin Support', avatar_url: null }
          };
          setMessages((prevMessages) => [...prevMessages, messageWithSender]);
        }
      )
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'chat_sessions', filter: `id=eq.${currentSessionId}`},
        (payload) => {
            fetchSessionDetails(currentSessionId); // Re-fetch session details if it's updated (e.g. transaction status)
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentSessionId, user, profile]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() && !attachment) return;
    if (!user || !currentSessionId) {
      toast({ title: "Error", description: "User or session not available.", variant: "destructive" });
      return;
    }
    setLoading(true);

    let fileUrl = null;
    let messageType = 'text';

    if (attachment) {
      const fileExt = attachment.name.split('.').pop();
      // For deposit proofs, use a more specific path
      const storagePath = sessionDetails?.session_type === 'deposit_chat' ? 'deposit_proofs' : 'chat_attachments';
      const fileName = `${storagePath}/${user.id}/${currentSessionId}/${Date.now()}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from(storagePath) // Use dynamic bucket based on session type
        .upload(fileName, attachment);

      if (uploadError) {
        toast({ title: "Attachment Upload Failed", description: uploadError.message, variant: "destructive" });
        setLoading(false);
        return;
      }
      const { data: urlData } = supabase.storage.from(storagePath).getPublicUrl(fileName);
      fileUrl = urlData.publicUrl;
      messageType = attachment.type.startsWith('image/') ? 'image_proof' : 'file_attachment';
    }

    try {
      const { error } = await supabase.from('chat_messages').insert({
        session_id: currentSessionId,
        sender_id: user.id,
        message_content: newMessage.trim() || (messageType === 'image_proof' ? 'Proof of payment uploaded.' : 'File attached.'),
        attachment_url: fileUrl,
        message_type: fileUrl ? messageType : 'text',
      });
      if (error) throw error;

      // If it's a deposit chat and proof is uploaded, update session status
      if (sessionDetails?.session_type === 'deposit_chat' && messageType === 'image_proof') {
        await supabase.from('chat_sessions')
          .update({ status: 'pending_confirmation', updated_at: new Date().toISOString() })
          .eq('id', currentSessionId);
      } else {
         await supabase.from('chat_sessions')
          .update({ updated_at: new Date().toISOString() }) // Just update timestamp for other messages
          .eq('id', currentSessionId);
      }

      setNewMessage('');
      setAttachment(null);
      setAttachmentPreview(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
    } catch (err) {
      toast({ title: "Error Sending Message", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };
  
  const handleAttachmentChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
      if (!allowedTypes.includes(file.type)) {
        toast({ title: "Invalid File Type", description: "Please upload JPG, PNG, or PDF.", variant: "destructive"});
        return;
      }
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({ title: "File Too Large", description: "Attachment must be under 5MB.", variant: "destructive"});
        return;
      }
      setAttachment(file);
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onloadend = () => setAttachmentPreview(reader.result);
        reader.readAsDataURL(file);
      } else {
        setAttachmentPreview(null);
      }
    }
  };

  if (sessionLoading && !currentSessionId && !prefilledType) {
     return (
        <div className="flex flex-col items-center justify-center h-full p-4 text-center">
            <MessageSquare className="w-16 h-16 text-gray-400 mb-4" />
            <h2 className="text-xl font-semibold text-gray-700 mb-2">No Active Chat</h2>
            <p className="text-gray-500 mb-4">Select a chat from your list or start a new one.</p>
            <Button onClick={() => navigate('/dashboard/chat/new-support')}>Start Support Chat</Button>
        </div>
    );
  }

  if (sessionLoading) {
    return <div className="flex items-center justify-center h-full p-4">Loading chat session...</div>;
  }
  
  if (!sessionDetails && !routeSessionId && !prefilledType) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-4 text-center">
        <MessageSquare className="w-16 h-16 text-gray-400 mb-4" />
        <h2 className="text-xl font-semibold text-gray-700 mb-2">Chat System</h2>
        <p className="text-gray-500 mb-4">Your conversations will appear here.</p>
         <Button onClick={() => navigate('/dashboard/chat/new-support')}>Start New Support Chat</Button>
      </div>
    );
  }
  
  if (!sessionDetails && routeSessionId) {
    return <div className="flex items-center justify-center h-full p-4">Session not found or access denied.</div>;
  }

  const transactionDetails = sessionDetails?.related_transaction_id;
  const sessionTitle = sessionDetails?.session_type === 'deposit_chat'
    ? `Deposit Chat (Ref: ${transactionDetails?.reference_number || 'N/A'})`
    : sessionDetails?.session_type?.replace('_', ' ')?.replace(/\b\w/g, l => l.toUpperCase()) || 'Chat';
  
  const sessionStatusInfo = sessionDetails?.session_type === 'deposit_chat' && transactionDetails
    ? `Transaction Status: ${transactionDetails.status.replace(/_/g, ' ')}`
    : `Status: ${sessionDetails?.status.replace(/_/g, ' ')}`;

  const isChatClosed = sessionDetails?.status?.startsWith('closed');
  const isDepositAwaitingAdmin = sessionDetails?.session_type === 'deposit_chat' && sessionDetails?.status === 'pending_admin_reply';

  return (
    <div className="flex flex-col h-[calc(100vh-var(--header-height,0px)-var(--footer-height,0px))] md:h-full bg-gray-100">
      <header className="bg-white p-4 border-b border-gray-200 flex items-center space-x-3 sticky top-0 z-10">
        <Button variant="ghost" size="icon" onClick={() => navigate('/dashboard/chat')} className="md:hidden">
          <ArrowLeft className="h-6 w-6 text-gray-600" />
        </Button>
        <Avatar className="h-10 w-10">
          <AvatarImage src={sessionDetails?.admin_id ? undefined : profile?.avatar_url} /> {/* Admin avatar can be generic */}
          <AvatarFallback>{sessionDetails?.admin_id ? 'A' : getInitials(profile?.full_name)}</AvatarFallback>
        </Avatar>
        <div>
          <h1 className="text-md font-semibold text-gray-800 capitalize">{sessionTitle}</h1>
          <p className="text-xs text-gray-500 capitalize">{sessionStatusInfo}</p>
        </div>
      </header>

      <div className="flex-grow overflow-y-auto p-4 space-y-4 bg-gray-50">
        {isDepositAwaitingAdmin && (
            <div className="p-3 my-2 text-sm text-center bg-blue-50 text-blue-700 rounded-md border border-blue-200">
                Please wait while Company responds with payment instructions.
            </div>
        )}
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender_id === user?.id ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[70%] p-3 rounded-lg ${msg.sender_id === user?.id ? 'bg-blue-500 text-white' : 'bg-white text-gray-800 shadow-sm'}`}>
              {msg.sender_id !== user?.id && (
                <p className="text-xs font-medium mb-0.5 opacity-80">
                  {msg.sender?.full_name || (msg.sender_id === 'ADMIN_CONSOLE' ? 'Company Support' : 'Support')}
                </p>
              )}
              {msg.message_content && <p className="text-sm whitespace-pre-wrap">{msg.message_content}</p>}
              {msg.attachment_url && (
                <a href={msg.attachment_url} target="_blank" rel="noopener noreferrer" className={`mt-2 flex items-center space-x-2 p-2 rounded-md ${msg.sender_id === user?.id ? 'bg-blue-400 hover:bg-blue-300' : 'bg-gray-100 hover:bg-gray-200'}`}>
                  {msg.message_type === 'image_proof' || msg.attachment_url.match(/\.(jpeg|jpg|gif|png)$/i) ? 
                    <img src={msg.attachment_url} alt="Proof" className="max-w-[150px] max-h-32 rounded" /> :
                    <>
                      <FileText className="h-5 w-5 flex-shrink-0" />
                      <span className="text-xs truncate max-w-[150px]">{msg.attachment_url.split('/').pop().split('?')[0].split('%2F').pop().substring(14)}</span>
                    </>
                  }
                </a>
              )}
              <p className={`text-xs mt-1.5 ${msg.sender_id === user?.id ? 'text-blue-100 opacity-70 text-right' : 'text-gray-400 text-left'}`}>
                 {formatDistanceToNowStrict(new Date(msg.created_at), { addSuffix: true })}
              </p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {attachmentPreview && attachment?.type.startsWith('image/') && (
        <div className="p-2 border-t bg-white">
          <img src={attachmentPreview} alt="Preview" className="max-h-20 rounded" />
        </div>
      )}
       {attachment && !attachment?.type.startsWith('image/') && (
        <div className="p-2 border-t bg-white text-sm text-gray-600">
          Selected file: {attachment.name} ({ (attachment.size / 1024).toFixed(1) } KB)
        </div>
      )}

      <form onSubmit={handleSendMessage} className="bg-white p-3 border-t border-gray-200 flex items-center space-x-2 sticky bottom-0">
        <Button type="button" variant="ghost" size="icon" onClick={() => fileInputRef.current?.click()} disabled={loading || isChatClosed}>
          <Paperclip className="h-5 w-5 text-gray-500" />
        </Button>
        <Input 
          ref={fileInputRef}
          type="file" 
          className="hidden" 
          onChange={handleAttachmentChange}
          accept="image/jpeg,image/png,application/pdf"
          disabled={loading || isChatClosed}
        />
        <Input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder={isChatClosed ? "This chat is closed." : "Type a message..."}
          className="flex-grow bg-gray-100 border-gray-300 rounded-full focus:ring-blue-500 focus:border-blue-500 px-4"
          disabled={loading || isChatClosed}
        />
        <Button type="submit" size="icon" className="bg-blue-500 hover:bg-blue-600 rounded-full" disabled={loading || (!newMessage.trim() && !attachment) || isChatClosed}>
          <Send className="h-5 w-5 text-white" />
        </Button>
      </form>
      {isChatClosed && (
         <div className="p-3 text-center bg-yellow-100 text-yellow-700 text-sm">
            This chat session is closed. <RouterLink to="/dashboard/chat/new-support" className="underline hover:text-yellow-800">Start a new support chat?</RouterLink>
        </div>
      )}
    </div>
  );
};

export default ChatPage;