import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from '@/components/ui/use-toast';
import { UserCircle, Mail, Phone, Camera, Save } from 'lucide-react';

const UserProfilePage = () => {
  const { user, profile, fetchProfile, logUserActivity } = useAuth();
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [avatarFile, setAvatarFile] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setPhoneNumber(profile.phone_number || '');
      setAvatarPreview(profile.avatar_url || null);
    }
  }, [profile]);

  const getInitials = (name) => {
    if (!name) return user?.email?.[0]?.toUpperCase() || 'U';
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit for avatars
        toast({ title: "File Too Large", description: "Avatar image must be under 2MB.", variant: "destructive"});
        return;
      }
      setAvatarFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = async () => {
    if (!fullName.trim()) {
        toast({title: "Full Name Required", description: "Please enter your full name.", variant: "destructive"});
        return;
    }
    setLoading(true);
    let avatarUrl = profile?.avatar_url;
    let oldAvatarPath = null;

    if (profile?.avatar_url) {
        try {
            const urlParts = profile.avatar_url.split('/');
            oldAvatarPath = urlParts[urlParts.length -1];
        } catch (e) { console.warn("Could not parse old avatar path")}
    }


    if (avatarFile) {
      // If there was an old avatar and it's different from the new one, attempt to delete it.
      if (oldAvatarPath && oldAvatarPath !== avatarFile.name) {
        const { error: deleteError } = await supabase.storage.from('avatars').remove([oldAvatarPath]);
        if (deleteError) console.warn("Old avatar deletion failed:", deleteError.message);
      }
      
      const fileExt = avatarFile.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, avatarFile, { upsert: true }); // Upsert to overwrite if somehow same name

      if (uploadError) {
        toast({ title: 'Avatar Upload Failed', description: uploadError.message, variant: 'destructive' });
        setLoading(false);
        return;
      }
      const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(fileName);
      avatarUrl = urlData.publicUrl;
    }

    const updates = {
      id: user.id,
      full_name: fullName,
      phone_number: phoneNumber,
      avatar_url: avatarUrl,
      updated_at: new Date().toISOString(),
    };

    const { error } = await supabase.from('profiles').upsert(updates);

    if (error) {
      toast({ title: 'Profile Update Failed', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Profile Updated!', description: 'Your information has been saved.' });
      logUserActivity(user.id, 'PROFILE_UPDATE', 'User profile information updated.');
      await fetchProfile(user.id); // Refresh profile data in context
      setEditing(false);
    }
    setLoading(false);
  };

  if (!user) { // Check for user only as profile might be initially null
    return <div className="p-6 text-center">Loading profile...</div>;
  }

  return (
    <div className="p-4 md:p-6">
      <Card className="max-w-2xl mx-auto shadow-lg rounded-xl">
        <CardHeader className="text-center border-b pb-6">
          <div className="relative w-32 h-32 mx-auto mb-4 group">
            <Avatar className="w-32 h-32 text-4xl border-4 border-blue-200">
              <AvatarImage src={avatarPreview} alt={fullName} />
              <AvatarFallback className="bg-blue-500 text-white">{getInitials(fullName)}</AvatarFallback>
            </Avatar>
            {editing && (
              <Button
                variant="outline"
                size="icon"
                className="absolute bottom-0 right-0 bg-white rounded-full p-2 shadow-md hover:bg-gray-100"
                onClick={() => fileInputRef.current?.click()}
                disabled={loading}
              >
                <Camera className="h-5 w-5 text-blue-600" />
              </Button>
            )}
            <Input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/png, image/jpeg, image/webp" 
              onChange={handleAvatarChange} 
              disabled={!editing || loading}
            />
          </div>
          <CardTitle className="text-2xl font-semibold text-gray-800">{fullName || 'User Profile'}</CardTitle>
          <CardDescription className="text-gray-500">{user?.email}</CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div>
            <Label htmlFor="fullName" className="text-sm font-medium text-gray-600 flex items-center"><UserCircle className="w-4 h-4 mr-2 text-blue-500"/>Full Name</Label>
            <Input 
              id="fullName" 
              value={fullName} 
              onChange={(e) => setFullName(e.target.value)} 
              disabled={!editing || loading}
              className="mt-1 text-gray-700 bg-gray-50 border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <Label htmlFor="email" className="text-sm font-medium text-gray-600 flex items-center"><Mail className="w-4 h-4 mr-2 text-blue-500"/>Email Address</Label>
            <Input id="email" value={user?.email || ''} disabled className="mt-1 text-gray-500 bg-gray-100 border-gray-300 rounded-md cursor-not-allowed"/>
          </div>
          <div>
            <Label htmlFor="phoneNumber" className="text-sm font-medium text-gray-600 flex items-center"><Phone className="w-4 h-4 mr-2 text-blue-500"/>Phone Number</Label>
            <Input 
              id="phoneNumber" 
              value={phoneNumber} 
              onChange={(e) => setPhoneNumber(e.target.value)} 
              disabled={!editing || loading}
              placeholder="e.g. 09123456789"
              className="mt-1 text-gray-700 bg-gray-50 border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          
          {editing ? (
            <div className="flex space-x-3 pt-4">
              <Button onClick={handleSaveProfile} disabled={loading || !fullName.trim()} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white">
                <Save className="w-4 h-4 mr-2"/> {loading ? 'Saving...' : 'Save Changes'}
              </Button>
              <Button variant="outline" onClick={() => {
                setEditing(false);
                setFullName(profile?.full_name || '');
                setPhoneNumber(profile?.phone_number || '');
                setAvatarFile(null);
                setAvatarPreview(profile?.avatar_url || null);
              }} disabled={loading} className="flex-1">
                Cancel
              </Button>
            </div>
          ) : (
            <Button onClick={() => {
              setEditing(true);
            }} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Edit Profile
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default UserProfilePage;