import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { BellRing, CheckCheck, Eye, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { formatDistanceToNowStrict } from 'date-fns';

const NotificationsPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchNotifications();

    // Listen for real-time changes
    const channel = supabase
      .channel(`notifications_page:${user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` },
        payload => {
          console.log('Realtime notification change:', payload);
          fetchNotifications(); // Refetch all notifications on any change
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const fetchNotifications = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      setNotifications(data || []);
    } catch (error) {
      toast({ title: "Error", description: "Could not load notifications.", variant: "destructive" });
    }
    setLoading(false);
  };

  const handleNotificationClick = async (notification) => {
    if (!notification.is_read) {
      await markAsRead(notification.id, false); // Mark as read without refetching yet
    }
    if (notification.link_to) {
      navigate(notification.link_to);
    }
  };

  const markAsRead = async (notificationId, shouldRefetch = true) => {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId);
    if (error) {
      toast({ title: "Error", description: "Could not mark as read.", variant: "destructive" });
    } else {
      if(shouldRefetch) fetchNotifications(); // Subscription might handle this, but explicit for direct action
      else { // Optimistically update UI if not refetching (e.g. from popover)
        setNotifications(prev => prev.map(n => n.id === notificationId ? {...n, is_read: true} : n));
      }
    }
  };
  
  const markAllAsRead = async () => {
    const unreadIds = notifications.filter(n => !n.is_read).map(n => n.id);
    if (unreadIds.length === 0) {
        toast({title: "No Unread Notifications", description: "All notifications are already marked as read."});
        return;
    }

    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .in('id', unreadIds);
    if (error) {
      toast({ title: "Error", description: "Could not mark all as read.", variant: "destructive" });
    } else {
      fetchNotifications(); // Refetch to update UI
      toast({title: "All Marked as Read", description: `${unreadIds.length} notifications marked as read.`});
    }
  };

  const handleDeleteNotification = async (notificationId) => {
    const { error } = await supabase
      .from('notifications')
      .delete()
      .eq('id', notificationId);
    if (error) {
      toast({ title: "Error", description: "Could not delete notification.", variant: "destructive" });
    } else {
      fetchNotifications(); // Refetch
      toast({title: "Notification Deleted"});
    }
  };


  return (
    <div className="p-4 md:p-6">
      <Card className="shadow-lg rounded-xl">
        <CardHeader className="border-b flex flex-row justify-between items-center">
          <div>
            <CardTitle className="text-2xl font-semibold text-gray-800 flex items-center">
              <BellRing className="w-7 h-7 mr-3 text-blue-600" /> Notifications
            </CardTitle>
            <CardDescription>All your account updates and alerts.</CardDescription>
          </div>
          {notifications.some(n => !n.is_read) && (
            <Button onClick={markAllAsRead} size="sm" variant="outline">
                <CheckCheck className="w-4 h-4 mr-2"/> Mark All as Read
            </Button>
          )}
        </CardHeader>
        <CardContent className="p-0">
          {loading && <p className="text-center text-gray-500 py-10">Loading notifications...</p>}
          {!loading && notifications.length === 0 && (
            <p className="text-center text-gray-500 py-10">You have no notifications yet.</p>
          )}
          {!loading && notifications.length > 0 && (
            <ul className="divide-y divide-gray-100">
              {notifications.map((notification) => (
                <li 
                  key={notification.id} 
                  className={`p-4 hover:bg-gray-50 transition-colors ${notification.is_read ? 'opacity-70' : 'bg-blue-50 font-medium'}`}
                >
                  <div className="flex justify-between items-start space-x-3">
                    <div className="flex-1 cursor-pointer" onClick={() => handleNotificationClick(notification)}>
                      <p className={`text-sm ${notification.is_read ? 'text-gray-700' : 'text-blue-700'}`}>{notification.message}</p>
                      <p className={`text-xs mt-1 ${notification.is_read ? 'text-gray-400' : 'text-blue-500'}`}>
                        {formatDistanceToNowStrict(new Date(notification.created_at), { addSuffix: true })}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1">
                        {!notification.is_read && (
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-green-600" onClick={() => markAsRead(notification.id)}>
                                <CheckCheck className="w-4 h-4"/>
                            </Button>
                        )}
                         <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-red-600" onClick={() => handleDeleteNotification(notification.id)}>
                            <Trash2 className="w-4 h-4"/>
                        </Button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default NotificationsPage;