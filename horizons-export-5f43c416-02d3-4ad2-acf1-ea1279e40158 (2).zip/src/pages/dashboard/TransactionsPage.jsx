import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Clock, PlusCircle, MinusCircle, TrendingUp, TrendingDown, AlertCircle } from 'lucide-react'; // Added AlertCircle
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';

const TransactionItem = ({ transaction }) => {
  let IconComponent = Clock;
  let amountColor = 'text-gray-800';
  let amountPrefix = '';
  let statusColor = 'text-gray-500';

  switch (transaction.type) {
    case 'deposit':
      IconComponent = PlusCircle;
      amountColor = 'text-green-600';
      amountPrefix = '+';
      break;
    case 'withdrawal':
    case 'withdrawal_request':
      IconComponent = MinusCircle;
      amountColor = 'text-red-600';
      amountPrefix = '-';
      break;
    case 'investment_payout':
      IconComponent = TrendingUp;
      amountColor = 'text-green-600';
      amountPrefix = '+';
      break;
    case 'investment':
      IconComponent = TrendingDown;
      amountColor = 'text-yellow-600';
      amountPrefix = '-';
      break;
    default:
      IconComponent = Clock;
  }
  
  switch (transaction.status) {
    case 'completed':
    case 'approved':
      statusColor = 'text-green-500';
      if (transaction.type !== 'withdrawal' && transaction.type !== 'withdrawal_request' && transaction.type !== 'investment') {
         IconComponent = CheckCircle;
      }
      break;
    case 'pending':
      statusColor = 'text-yellow-500';
      IconComponent = Clock;
      break;
    case 'failed':
    case 'cancelled':
      statusColor = 'text-red-500';
      IconComponent = AlertCircle;
      break;
    default:
      statusColor = 'text-gray-500';
  }

  return (
    <div className="flex items-center justify-between py-4 px-2 border-b border-gray-100 last:border-b-0 hover:bg-gray-50 transition-colors rounded-md">
      <div className="flex items-center space-x-4">
        <div className={`p-2.5 rounded-full ${
          (transaction.type === 'deposit' || transaction.type === 'investment_payout') && (transaction.status === 'completed' || transaction.status === 'approved') ? 'bg-green-100' : 
          (transaction.type === 'withdrawal' || transaction.type === 'withdrawal_request' || transaction.type === 'investment') && (transaction.status === 'completed' || transaction.status === 'approved') ? 'bg-red-100' : 
          transaction.status === 'pending' ? 'bg-yellow-100' :
          transaction.status === 'failed' || transaction.status === 'cancelled' ? 'bg-red-100' :
          'bg-gray-100'
        }`}>
          <IconComponent className={`h-5 w-5 ${
             (transaction.type === 'deposit' || transaction.type === 'investment_payout') && (transaction.status === 'completed' || transaction.status === 'approved') ? 'text-green-600' : 
             (transaction.type === 'withdrawal' || transaction.type === 'withdrawal_request' || transaction.type === 'investment') && (transaction.status === 'completed' || transaction.status === 'approved') ? 'text-red-600' : 
             transaction.status === 'pending' ? 'text-yellow-600' :
             transaction.status === 'failed' || transaction.status === 'cancelled' ? 'text-red-600' :
             'text-gray-500'
          }`} />
        </div>
        <div>
          <p className="text-md font-medium text-gray-800 capitalize">{transaction.description || transaction.type.replace('_', ' ')}</p>
          <p className="text-sm text-gray-500">
            {new Date(transaction.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
            {' - '}
            <span className={`font-medium ${statusColor}`}>{transaction.status}</span>
          </p>
        </div>
      </div>
      <p className={`text-md font-semibold ${amountColor}`}>
        {amountPrefix}₱{Math.abs(transaction.amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
      </p>
    </div>
  );
};

const TransactionsPage = () => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAllTransactions = async () => {
      if (user) {
        setLoading(true);
        try {
          const { data, error } = await supabase
            .from('transactions')
            .select('*')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false });
          if (error) throw error;
          setTransactions(data || []);
        } catch (error) {
          console.error('Error fetching all transactions:', error.message);
          toast({ title: "Error Fetching Transactions", description: error.message, variant: "destructive" });
        } finally {
          setLoading(false);
        }
      }
    };
    fetchAllTransactions();
  }, [user]);


  return (
    <div className="p-4 md:p-6">
      <Card className="shadow-lg rounded-xl">
        <CardHeader className="border-b">
          <CardTitle className="text-2xl font-semibold text-gray-800">All Transactions</CardTitle>
        </CardHeader>
        <CardContent className="p-3 md:p-5">
          {loading && <p className="text-gray-500 text-center py-8">Loading transactions...</p>}
          {!loading && transactions.length === 0 && (
            <p className="text-gray-500 text-center py-8">No transactions yet.</p>
          )}
          {!loading && transactions.length > 0 && (
            <div className="space-y-2">
              {transactions.map((transaction) => (
                <TransactionItem
                  key={transaction.id}
                  transaction={transaction}
                />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default TransactionsPage;