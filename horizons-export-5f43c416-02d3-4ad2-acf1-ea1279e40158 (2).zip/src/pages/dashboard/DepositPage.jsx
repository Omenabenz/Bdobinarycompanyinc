import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel as RadixSelectLabel } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { DollarSign, Banknote, ArrowRight, Clock, MessageSquare } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { generateTransactionId, generateReferenceNumber } from '@/lib/utils';


const companyDepositAccounts = [
  { id: 'bdo1', bank_name: 'BDO', account_number: '0012-3456-7890', account_name: 'Trading Corp Inc.', details: 'Acct No: 001234567890, Acct Name: Trading Corp Inc.' },
  { id: 'gcash1', bank_name: 'GCash', account_number: '09171234567', account_name: 'John D. (Trading Corp)', details: 'Number: 09171234567, Name: John D. (Trading Corp)' },
  { id: 'paymaya1', bank_name: 'Maya', account_number: '09281234567', account_name: 'Jane S. (Trading Corp)', details: 'Number: 09281234567, Name: Jane S. (Trading Corp)' },
];

const DepositPage = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [amount, setAmount] = useState('');
  const [selectedCompanyAccountId, setSelectedCompanyAccountId] = useState('');
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(0); 
  const [showChatInitiation, setShowChatInitiation] = useState(false);
  const [pendingTransactionId, setPendingTransactionId] = useState(null);
  const [currentTransactionUid, setCurrentTransactionUid] = useState(null);


  useEffect(() => {
    let timer;
    if (countdown > 0) {
      timer = setInterval(() => {
        setCountdown(prev => prev - 1);
      }, 1000);
    } else if (countdown === 0 && showChatInitiation) {
      toast({ 
        title: "Deposit Session Expired", 
        description: "The 30-minute window for this deposit has expired. Please start a new deposit request if you wish to proceed.", 
        variant: "destructive",
        duration: 7000,
      });
      if (pendingTransactionId) {
        const markAsExpired = async () => {
            await supabase.from('transactions').update({ status: 'expired' }).eq('id', pendingTransactionId);
        };
        markAsExpired();
      }
      setShowChatInitiation(false);
      setPendingTransactionId(null);
      setCurrentTransactionUid(null);
    }
    return () => clearInterval(timer);
  }, [countdown, showChatInitiation, pendingTransactionId]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleInitiateDeposit = async () => {
    const depositAmount = parseFloat(amount);
    if (isNaN(depositAmount) || depositAmount <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a valid deposit amount.", variant: "destructive" });
      return;
    }
    if (!selectedCompanyAccountId) {
      toast({ title: "Select Account", description: "Please select an account to deposit into.", variant: "destructive" });
      return;
    }
    setLoading(true);
    
    const selectedAccountDetails = companyDepositAccounts.find(acc => acc.id === selectedCompanyAccountId);
    if (!selectedAccountDetails) {
        toast({ title: "Error", description: "Selected company account details not found.", variant: "destructive" });
        setLoading(false);
        return;
    }

    try {
      const transactionUid = generateTransactionId();
      const referenceNum = generateReferenceNumber();

      const { data: transactionData, error: transactionError } = await supabase
        .from('transactions')
        .insert({
          user_id: user.id,
          type: 'deposit_initiated', 
          amount: depositAmount,
          status: 'pending_payment', 
          description: `Deposit to ${selectedAccountDetails.bank_name}`,
          transaction_uid: transactionUid,
          reference_number: referenceNum,
          meta_data: { 
            selected_company_account: {
                bank_name: selectedAccountDetails.bank_name,
                account_number: selectedAccountDetails.account_number,
                account_name: selectedAccountDetails.account_name
            }
          }
        })
        .select()
        .single();

      if (transactionError) throw transactionError;

      setPendingTransactionId(transactionData.id); 
      setCurrentTransactionUid(transactionData.transaction_uid);
      setCountdown(30 * 60); 
      setShowChatInitiation(true);
      toast({ title: "Deposit Initiated", description: "Please proceed to the chat to get payment details and upload proof." });
      
      // Simulate sending email for deposit initiation
      const { error: emailError } = await supabase.functions.invoke('send-deposit-email', {
        body: JSON.stringify({
          to_email: user.email,
          user_name: profile?.full_name || user.email,
          subject: "Deposit Request Initiated",
          transaction_ref: referenceNum,
          transaction_status: "Pending Payment",
          deposit_amount: depositAmount,
          company_account_details: `${selectedAccountDetails.bank_name} (${selectedAccountDetails.account_name})`,
          email_type: 'deposit_initiated'
        })
      });
      if (emailError) console.warn("Deposit initiation email simulation error:", emailError.message);


    } catch (error) {
      toast({ title: "Deposit Initiation Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleProceedToChat = async () => {
    if (!pendingTransactionId) {
        toast({title: "Error", description: "No pending deposit transaction found.", variant:"destructive"});
        return;
    }
    setLoading(true);
    try {
      const { data: chatSession, error: chatError } = await supabase
        .from('chat_sessions')
        .insert({
          user_id: user.id,
          session_type: 'deposit_chat',
          related_transaction_id: pendingTransactionId, 
          status: 'pending_admin_reply', 
        })
        .select()
        .single();

      if (chatError) throw chatError;
      
      await supabase.from('notifications').insert({
        user_id: user.id,
        type: 'deposit_chat_initiated',
        message: `Deposit chat started for ₱${amount} (Ref: ${currentTransactionUid ? currentTransactionUid.substring(0,8) : 'N/A'}). Waiting for payment details.`,
        link_to: `/dashboard/chat/${chatSession.id}`
      });

      navigate(`/dashboard/chat/${chatSession.id}`, { state: { transactionId: pendingTransactionId } });

    } catch (error) {
      toast({ title: "Chat Creation Failed", description: error.message, variant: "destructive" });
      setLoading(false);
    }
  };

  if (showChatInitiation) {
    const accountDetails = companyDepositAccounts.find(acc => acc.id === selectedCompanyAccountId);
    return (
      <div className="p-4 md:p-6">
        <Card className="max-w-2xl mx-auto shadow-lg rounded-xl">
          <CardHeader className="border-b">
            <CardTitle className="text-2xl font-semibold text-gray-800 flex items-center">
              <Clock className="w-7 h-7 mr-3 text-orange-500" /> Complete Your Deposit
            </CardTitle>
            <CardDescription>
              Time remaining to complete payment and upload proof: 
              <span className="font-semibold text-orange-600 ml-1">{formatTime(countdown)}</span>
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <p className="text-gray-700">You are depositing <span className="font-semibold">₱{parseFloat(amount).toLocaleString()}</span> to:</p>
            <div className="p-3 bg-gray-100 rounded-md border">
              <p className="font-medium">{accountDetails?.bank_name}</p>
              <p className="text-sm text-gray-600">{accountDetails?.details}</p>
            </div>
            <p className="text-sm text-gray-600">
              The payment details will be confirmed by our Payment Manager in the chat.
              After making the payment, please upload your proof of deposit in the chat.
            </p>
            <Button 
              onClick={handleProceedToChat} 
              disabled={loading || countdown === 0}
              className="w-full bg-green-600 hover:bg-green-700 text-white text-base py-3"
            >
              <MessageSquare className="w-5 h-5 mr-2"/> Proceed to Deposit Chat
            </Button>
            {countdown === 0 && <p className="text-red-500 text-sm text-center mt-2">Deposit time expired. Please start a new deposit.</p>}
          </CardContent>
        </Card>
      </div>
    );
  }


  return (
    <div className="p-4 md:p-6">
      <Card className="max-w-2xl mx-auto shadow-lg rounded-xl">
        <CardHeader className="border-b">
          <CardTitle className="text-2xl font-semibold text-gray-800 flex items-center">
            <Banknote className="w-7 h-7 mr-3 text-blue-600" /> Deposit Funds
          </CardTitle>
          <CardDescription>Add funds to your account balance.</CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div>
            <Label htmlFor="amount" className="text-sm font-medium text-gray-600">Amount (PHP)</Label>
            <div className="relative mt-1">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500 pointer-events-none">₱</span>
              <Input 
                id="amount" 
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                disabled={loading}
                className="pl-7 text-gray-700 bg-white border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-lg"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="companyAccount" className="text-sm font-medium text-gray-600">Deposit To:</Label>
            <Select onValueChange={setSelectedCompanyAccountId} value={selectedCompanyAccountId} disabled={loading}>
              <SelectTrigger className="mt-1 w-full bg-gray-50 border-gray-300 text-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500">
                <SelectValue placeholder="Select company bank/e-wallet" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <RadixSelectLabel>Company Accounts</RadixSelectLabel>
                  {companyDepositAccounts.map(acc => (
                    <SelectItem key={acc.id} value={acc.id}>{acc.bank_name} - {acc.account_name}</SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            onClick={handleInitiateDeposit} 
            disabled={loading || !amount || !selectedCompanyAccountId} 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white text-base py-3"
          >
            <ArrowRight className="w-5 h-5 mr-2"/> Next Step
          </Button>
          <p className="text-xs text-gray-500 text-center">
            You will be directed to a chat with our Payment Manager to receive payment details and upload your proof of deposit.
            You will have 30 minutes to complete the payment.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default DepositPage;