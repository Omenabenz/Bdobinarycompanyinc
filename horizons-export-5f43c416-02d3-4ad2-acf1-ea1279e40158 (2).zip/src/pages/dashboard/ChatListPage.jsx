import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from '@/components/ui/use-toast';
import { MessageSquare, PlusCircle } from 'lucide-react';
import { formatDistanceToNowStrict } from 'date-fns';

const ChatListPage = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [chatSessions, setChatSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchChatSessions = async () => {
      if (!user) return;
      setLoading(true);
      try {
        // Fetch sessions and their latest message for preview
        const { data, error } = await supabase
          .from('chat_sessions')
          .select(`
            id,
            session_type,
            status,
            updated_at,
            related_transaction_id ( transaction_uid ),
            chat_messages (
              message_content,
              created_at,
              sender_id
            )
          `)
          .eq('user_id', user.id)
          .order('updated_at', { ascending: false, foreignTable: null }) // Order sessions by their own updated_at
          .order('created_at', { referencedTable: 'chat_messages', ascending: false, limit: 1 }); // Get latest message per session

        if (error) throw error;
        setChatSessions(data || []);
      } catch (error) {
        toast({ title: "Error Fetching Chats", description: error.message, variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };
    fetchChatSessions();
    
    // Realtime listener for new sessions or messages updating a session's `updated_at`
    const sessionsChannel = supabase
      .channel(`chat_sessions_list:${user?.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chat_sessions', filter: `user_id=eq.${user?.id}` },
        () => fetchChatSessions()
      )
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages' /* No direct filter by user_id on messages, session update will trigger */},
        (payload) => {
            // If a new message arrives, its session's updated_at should trigger the session listener
            // Or, more robustly, refetch if payload.new.session_id is in our list of sessions.
            if (chatSessions.some(s => s.id === payload.new.session_id)) {
                fetchChatSessions();
            }
        }
      )
      .subscribe();

    return () => {
        supabase.removeChannel(sessionsChannel);
    };

  }, [user]);

  const getInitials = (name) => {
    if (!name) return 'S'; // Support
    const names = name.split(' ');
    return names.length > 1 ? `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase() : name.substring(0, 2).toUpperCase();
  };

  const handleStartNewSupportChat = () => {
    navigate('/dashboard/chat/new-support', { state: { type: 'support_chat' }});
  };

  return (
    <div className="p-4 md:p-6">
      <Card className="shadow-lg rounded-xl">
        <CardHeader className="border-b flex flex-row justify-between items-center">
          <div>
            <CardTitle className="text-2xl font-semibold text-gray-800 flex items-center">
              <MessageSquare className="w-7 h-7 mr-3 text-blue-600" /> Chat Conversations
            </CardTitle>
            <CardDescription>View and manage your support and deposit chats.</CardDescription>
          </div>
          <Button onClick={handleStartNewSupportChat} size="sm">
            <PlusCircle className="w-4 h-4 mr-2" /> New Support Chat
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          {loading && <p className="text-center text-gray-500 py-10">Loading conversations...</p>}
          {!loading && chatSessions.length === 0 && (
            <div className="text-center text-gray-500 py-10">
              <p className="mb-2">You have no active chats.</p>
              <Button onClick={handleStartNewSupportChat} variant="link">Start a new support chat</Button>
            </div>
          )}
          {!loading && chatSessions.length > 0 && (
            <ul className="divide-y divide-gray-100">
              {chatSessions.map((session) => {
                const latestMessage = session.chat_messages && session.chat_messages.length > 0 ? session.chat_messages[0] : null;
                const sessionTitle = session.session_type === 'deposit_chat'
                    ? `Deposit Chat (Ref: ${session.related_transaction_id?.transaction_uid?.slice(-6) || 'N/A'})`
                    : 'Support Chat';
                
                return (
                  <li key={session.id}>
                    <Link 
                      to={`/dashboard/chat/${session.id}`} 
                      className="block p-4 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={undefined} /> {/* Placeholder for admin/support avatar */}
                          <AvatarFallback className="bg-blue-500 text-white">{getInitials(session.session_type === 'deposit_chat' ? 'P' : 'S')}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-center">
                            <p className="text-sm font-medium text-gray-800 truncate">{sessionTitle}</p>
                            {latestMessage && (
                               <p className="text-xs text-gray-400 whitespace-nowrap">
                                {formatDistanceToNowStrict(new Date(latestMessage.created_at), { addSuffix: true })}
                               </p>
                            )}
                          </div>
                          {latestMessage ? (
                            <p className="text-xs text-gray-500 truncate">
                              {latestMessage.sender_id === user.id ? "You: " : ""}
                              {latestMessage.message_content || (latestMessage.attachment_url ? "Sent an attachment" : "No messages yet")}
                            </p>
                          ) : (
                            <p className="text-xs text-gray-400 italic">No messages yet.</p>
                          )}
                          <p className="text-xs text-gray-400 mt-0.5">Status: {session.status.replace('_', ' ')}</p>
                        </div>
                      </div>
                    </Link>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ChatListPage;