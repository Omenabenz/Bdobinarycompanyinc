import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle, MinusCircle, CheckCircle, Clock, TrendingUp, TrendingDown, AlertCircle, Eye } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { toast } from '@/components/ui/use-toast';
import { formatInManilaTime } from '@/lib/utils';

const TransactionHistoryItem = ({ transaction, onViewDetails }) => {
  let IconComponent = Clock;
  let amountColor = 'text-gray-700';
  let amountPrefix = '';
  let statusColor = 'text-gray-500';

  switch (transaction.type) {
    case 'deposit':
      IconComponent = PlusCircle;
      amountColor = 'text-green-600';
      amountPrefix = '+';
      break;
    case 'withdrawal':
    case 'withdrawal_request':
      IconComponent = MinusCircle;
      amountColor = 'text-red-600';
      amountPrefix = '-';
      break;
    case 'investment':
      IconComponent = TrendingUp;
      amountColor = 'text-blue-600';
      amountPrefix = '-'; 
      break;
    case 'investment_payout':
      IconComponent = TrendingDown; 
      amountColor = 'text-green-600';
      amountPrefix = '+';
      break;
    default:
      IconComponent = Clock;
  }

  switch (transaction.status) {
    case 'completed':
    case 'approved':
      statusColor = 'text-green-500';
      if (transaction.type !== 'withdrawal' && transaction.type !== 'withdrawal_request' && transaction.type !== 'investment') IconComponent = CheckCircle;
      break;
    case 'pending':
      statusColor = 'text-yellow-500';
      IconComponent = Clock;
      break;
    case 'failed':
    case 'cancelled':
      statusColor = 'text-red-500';
      IconComponent = AlertCircle;
      break;
    default:
      statusColor = 'text-gray-500';
  }
  
  const displayTitle = transaction.description || transaction.type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

  return (
    <div className="flex items-center justify-between py-3.5 px-1 border-b border-gray-100 last:border-b-0 hover:bg-gray-50 rounded-md transition-colors">
      <div className="flex items-center space-x-3 flex-grow min-w-0">
        <div className={`p-2 rounded-full flex-shrink-0 ${
          (transaction.status === 'completed' || transaction.status === 'approved') && (transaction.type === 'deposit' || transaction.type === 'investment_payout') ? 'bg-green-100' : 
          (transaction.status === 'completed' || transaction.status === 'approved') && (transaction.type === 'withdrawal' || transaction.type === 'withdrawal_request' || transaction.type === 'investment') ? 'bg-red-100' :
          transaction.status === 'pending' ? 'bg-yellow-100' :
          (transaction.status === 'failed' || transaction.status === 'cancelled') ? 'bg-red-100' : 'bg-gray-100'
        }`}>
          <IconComponent className={`h-5 w-5 ${
             (transaction.status === 'completed' || transaction.status === 'approved') && (transaction.type === 'deposit' || transaction.type === 'investment_payout') ? 'text-green-600' : 
             (transaction.status === 'completed' || transaction.status === 'approved') && (transaction.type === 'withdrawal' || transaction.type === 'withdrawal_request' || transaction.type === 'investment') ? 'text-red-600' :
             transaction.status === 'pending' ? 'text-yellow-600' :
             (transaction.status === 'failed' || transaction.status === 'cancelled') ? 'text-red-600' : 'text-gray-500'
          }`} />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium text-gray-800 truncate" title={displayTitle}>{displayTitle}</p>
          <p className="text-xs text-gray-500">
            {formatInManilaTime(new Date(transaction.created_at), 'MMM d, hh:mm a')}
            <span className={`ml-2 capitalize font-medium ${statusColor}`}>({transaction.status})</span>
          </p>
        </div>
      </div>
      <div className="flex items-center flex-shrink-0 ml-2">
        <p className={`text-sm font-semibold ${amountColor} mr-2`}>
          {amountPrefix}₱{Math.abs(transaction.amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </p>
        <Button variant="ghost" size="icon" className="h-7 w-7 text-gray-400 hover:text-blue-600" onClick={() => onViewDetails(transaction.transaction_uid || transaction.id)}>
            <Eye className="h-4 w-4"/>
        </Button>
      </div>
    </div>
  );
};

const LiveWithdrawalItem = ({ name, bank, amount, time }) => (
    <div className="p-3 bg-green-50 border border-green-200 rounded-lg shadow-sm animate-pulse-glow-once">
        <div className="flex justify-between items-center text-xs">
            <p className="font-medium text-green-700">{name}</p>
            <p className="text-green-500">{time}</p>
        </div>
        <p className="text-sm text-green-600 mt-1">
            Successfully withdrew <span className="font-semibold">₱{amount.toLocaleString()}</span> to {bank}.
        </p>
    </div>
);

const DashboardHomePage = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [loadingBalance, setLoadingBalance] = useState(true);
  const [loadingTransactions, setLoadingTransactions] = useState(true);
  const [liveWithdrawals, setLiveWithdrawals] = useState([]); // Placeholder

  useEffect(() => {
    const fetchBalance = async () => {
      if (user) {
        setLoadingBalance(true);
        try {
          const { data, error } = await supabase
            .from('user_balances')
            .select('current_balance')
            .eq('user_id', user.id)
            .single();
          if (error) throw error;
          setBalance(data?.current_balance || 0);
        } catch (error) {
          console.error('Error fetching balance:', error);
          toast({ title: "Error Fetching Balance", description: error.message, variant: "destructive" });
          setBalance(0);
        } finally {
          setLoadingBalance(false);
        }
      }
    };

    const fetchTransactions = async () => {
      if (user) {
        setLoadingTransactions(true);
        try {
          const { data, error } = await supabase
            .from('transactions')
            .select('*')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false })
            .limit(5); // Show 5 recent transactions
          if (error) throw error;
          setTransactions(data || []);
        } catch (error) {
          console.error('Error fetching transactions:', error);
          toast({ title: "Error Fetching Transactions", description: error.message, variant: "destructive" });
        } finally {
          setLoadingTransactions(false);
        }
      }
    };
    
    // Placeholder for Live Withdrawals Feed
    const fetchLiveWithdrawals = () => {
        // In a real app, this would fetch from a public table or use Supabase Realtime
        const dummyWithdrawals = [
            { id:1, name: 'Anna B.', bank: 'BDO', amount: 7500, time: '2m ago' },
            { id:2, name: 'John D.', bank: 'GCash', amount: 12000, time: '5m ago' },
            { id:3, name: 'Maria S.', bank: 'BPI', amount: 5200, time: '8m ago' },
        ];
        setLiveWithdrawals(dummyWithdrawals);
    };


    fetchBalance();
    fetchTransactions();
    fetchLiveWithdrawals(); // Fetch dummy data for now
  }, [user]);
  
  const getInitials = (name) => {
    if (!name) return user?.email?.[0]?.toUpperCase() || 'U';
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };
  
  const handleViewTransactionDetails = (transactionUid) => {
    navigate(`/dashboard/transactions/receipt/${transactionUid}`);
  };

  return (
    <div className="p-4 md:p-6 space-y-6 bg-gray-50 min-h-full">
      {/* Desktop Header Greeting */}
      <div className="hidden md:flex items-center space-x-4 mb-6">
          <Avatar className="h-12 w-12">
            <AvatarImage src={profile?.avatar_url || undefined} alt={profile?.full_name || user?.email} />
            <AvatarFallback>{getInitials(profile?.full_name || user?.email)}</AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Hi, {profile?.full_name ? profile.full_name.split(' ')[0] : 'User'}!</h1>
            <p className="text-sm text-gray-500">Good Morning!</p>
          </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content Area (Balance, Transactions, Market) */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-blue-600 text-white shadow-lg rounded-xl overflow-hidden">
            <CardContent className="p-6 space-y-4">
              <p className="text-sm text-blue-100">Total Balance</p>
              {loadingBalance ? (
                <p className="text-4xl font-bold">Loading...</p>
              ) : (
                <p className="text-4xl font-bold">
                  ₱{balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              )}
              <div className="grid grid-cols-2 gap-4 pt-2">
                <Button asChild variant="secondary" className="bg-white text-blue-600 hover:bg-blue-50 font-semibold py-3 rounded-lg">
                  <Link to="/dashboard/deposit">Deposit</Link>
                </Button>
                <Button asChild variant="outline" className="w-full bg-transparent border-white text-white hover:bg-blue-500 hover:border-blue-500 font-semibold py-3 rounded-lg">
                  <Link to="/dashboard/withdraw">Withdraw</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md rounded-xl">
            <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-800">Transaction History</CardTitle>
                <CardDescription>Your recent account activities.</CardDescription>
            </CardHeader>
            <CardContent className="p-3 sm:p-5">
              {loadingTransactions ? (
                <p className="text-gray-500 text-center py-4">Loading transactions...</p>
              ) : transactions.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No transactions yet.</p>
              ) : (
                <div className="space-y-1">
                  {transactions.map((transaction) => (
                    <TransactionHistoryItem
                      key={transaction.id}
                      transaction={transaction}
                      onViewDetails={handleViewTransactionDetails}
                    />
                  ))}
                </div>
              )}
              {transactions.length > 0 && (
                 <div className="mt-4 text-center">
                    <Button variant="link" asChild className="text-blue-600">
                        <Link to="/dashboard/transactions">View All Transactions</Link>
                    </Button>
                 </div>
              )}
            </CardContent>
          </Card>
           {/* Market Analysis Section Placeholder */}
            <Card className="bg-white shadow-md rounded-xl">
                <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-800">Market Analysis</CardTitle>
                    <CardDescription>Real-time stock market updates (placeholder).</CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="text-gray-500 text-center py-8">Market data will be displayed here.</p>
                    {/* Example structure: could use a simple list or a chart component later */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                        <div><p className="text-sm text-gray-500">PSEI</p><p className="font-semibold text-green-600">6,500.75 <span className="text-xs">+0.5%</span></p></div>
                        <div><p className="text-sm text-gray-500">Dow</p><p className="font-semibold text-red-600">33,800.12 <span className="text-xs">-0.2%</span></p></div>
                        <div><p className="text-sm text-gray-500">BTC</p><p className="font-semibold text-green-600">$68,000 <span className="text-xs">+2.1%</span></p></div>
                        <div><p className="text-sm text-gray-500">ETH</p><p className="font-semibold text-green-600">$3,500 <span className="text-xs">+1.8%</span></p></div>
                    </div>
                </CardContent>
            </Card>
        </div>

        {/* Sidebar Content Area (Live Withdrawals) */}
        <div className="lg:col-span-1 space-y-6">
            <Card className="bg-white shadow-md rounded-xl">
                <CardHeader>
                    <CardTitle className="text-lg font-semibold text-gray-800">Live Withdrawals</CardTitle>
                    <CardDescription>See recent successful payouts.</CardDescription>
                </CardHeader>
                <CardContent className="max-h-[400px] overflow-y-auto space-y-3 p-4">
                    {liveWithdrawals.length === 0 ? (
                        <p className="text-gray-500 text-center py-4">No live withdrawals to display.</p>
                    ) : (
                        liveWithdrawals.map(wd => (
                            <LiveWithdrawalItem key={wd.id} name={wd.name} bank={wd.bank} amount={wd.amount} time={wd.time} />
                        ))
                    )}
                </CardContent>
            </Card>
        </div>
      </div>
    </div>
  );
};

export default DashboardHomePage;