import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { ArrowLeft, Download, Printer, Share2, Info, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { formatInManilaTime } from '@/lib/utils';

const DetailRow = ({ label, value, isEmphasized = false, valueClassName = '' }) => (
  <div className="flex justify-between py-2.5 border-b border-gray-100 last:border-b-0">
    <p className="text-sm text-gray-600">{label}:</p>
    <p className={`text-sm ${isEmphasized ? 'font-semibold text-gray-800' : 'text-gray-700'} ${valueClassName}`}>{value}</p>
  </div>
);

const StatusDisplay = ({ status, statusReason }) => {
  let IconComponent = Clock;
  let color = 'text-gray-700';
  let bgColor = 'bg-gray-100';

  switch (status?.toLowerCase()) {
    case 'completed':
    case 'approved':
      IconComponent = CheckCircle;
      color = 'text-green-700';
      bgColor = 'bg-green-50';
      break;
    case 'pending':
      IconComponent = Clock;
      color = 'text-yellow-700';
      bgColor = 'bg-yellow-50';
      break;
    case 'processing':
      IconComponent = Clock;
      color = 'text-blue-700';
      bgColor = 'bg-blue-50';
      break;
    case 'on_hold':
      IconComponent = Info;
      color = 'text-orange-700';
      bgColor = 'bg-orange-50';
      break;
    case 'declined':
    case 'failed':
    case 'cancelled':
      IconComponent = AlertCircle;
      color = 'text-red-700';
      bgColor = 'bg-red-50';
      break;
  }

  return (
    <div className={`p-3 rounded-md ${bgColor} ${color}`}>
      <div className="flex items-center mb-1">
        <IconComponent className={`w-5 h-5 mr-2 ${color}`} />
        <span className="font-semibold text-md capitalize">{status?.replace(/_/g, ' ') || 'N/A'}</span>
      </div>
      {statusReason && <p className="text-xs mt-1 ml-1">Company Instructions: {statusReason}</p>}
    </div>
  );
};


const TransactionReceiptPage = () => {
  const { transactionId } = useParams(); // This is transaction_uid
  const { user } = useAuth();
  const [transaction, setTransaction] = useState(null);
  const [statusHistory, setStatusHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTransactionAndHistory = async () => {
      if (!user || !transactionId) return;
      setLoading(true);
      try {
        const { data: txnData, error: txnError } = await supabase
          .from('transactions')
          .select('*')
          .eq('user_id', user.id)
          .or(`transaction_uid.eq.${transactionId},id.eq.${transactionId}`) // Allow fetching by either
          .single();

        if (txnError) throw txnError;
        setTransaction(txnData);

        if (txnData) {
          const { data: historyData, error: historyError } = await supabase
            .from('status_history')
            .select('*')
            .eq('transaction_id', txnData.id)
            .order('changed_at', { ascending: false });
          if (historyError) throw historyError;
          setStatusHistory(historyData || []);
        }

      } catch (error) {
        console.error("Error fetching transaction details:", error);
        toast({ title: "Error", description: "Could not load transaction details.", variant: "destructive" });
        setTransaction(null);
      } finally {
        setLoading(false);
      }
    };
    fetchTransactionAndHistory();
  }, [user, transactionId]);

  const handleDownloadReceipt = () => {
    window.print(); 
    toast({ title: "Print Receipt", description: "Use your browser's print dialog to save as PDF." });
  };

  if (loading) {
    return <div className="p-6 text-center">Loading receipt...</div>;
  }

  if (!transaction) {
    return (
      <div className="p-6 text-center">
        <p className="text-xl text-red-600">Transaction not found or access denied.</p>
        <Button asChild variant="link" className="mt-4">
          <Link to="/dashboard/transactions">Back to Transactions</Link>
        </Button>
      </div>
    );
  }
  
  const isWithdrawal = transaction.type.includes('withdrawal');
  const amountPrefix = transaction.amount > 0 && !isWithdrawal ? '+' : (transaction.amount < 0 ? '' : ''); // Withdrawals are stored negative
  const amountDisplay = Math.abs(transaction.amount);
  const amountColor = transaction.amount > 0 && !isWithdrawal ? 'text-green-600' : (transaction.amount < 0 ? 'text-red-600' : 'text-gray-800');


  return (
    <div className="p-4 md:p-6 bg-gray-50 min-h-screen">
      <Card className="max-w-2xl mx-auto shadow-lg rounded-xl overflow-hidden">
        <CardHeader className="border-b bg-white relative p-4 md:p-6">
          <Button asChild variant="ghost" size="icon" className="absolute left-2 top-1/2 -translate-y-1/2 md:left-4">
            <Link to="/dashboard/transactions"><ArrowLeft className="h-5 w-5" /></Link>
          </Button>
          <CardTitle className="text-xl md:text-2xl font-semibold text-gray-800 text-center">Transaction Receipt</CardTitle>
          <CardDescription className="text-center text-sm">Ref: {transaction.reference_number || 'N/A'}</CardDescription>
        </CardHeader>
        <CardContent className="p-4 md:p-6 space-y-5 bg-white">
          <StatusDisplay status={transaction.status} statusReason={transaction.status_reason} />

          <DetailRow label="Transaction ID" value={transaction.transaction_uid || transaction.id} isEmphasized/>
          <DetailRow label="Date & Time" value={formatInManilaTime(new Date(transaction.created_at), 'MMM d, yyyy, hh:mm:ss a')} />
          <DetailRow label="Type" value={transaction.type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())} />
          <DetailRow label="Description" value={transaction.description || 'N/A'} />
          <DetailRow 
            label="Amount" 
            value={`${amountPrefix}₱${amountDisplay.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            isEmphasized
            valueClassName={amountColor}
          />
          
          {(transaction.type === 'withdrawal' || transaction.type === 'withdrawal_request') && transaction.meta_data && (
            <>
              <div className="pt-3 mt-3 border-t">
                <p className="text-sm font-medium text-gray-500 mb-1.5">Withdrawal Details:</p>
                <DetailRow label="Bank Name" value={transaction.meta_data.bank_name || 'N/A'} />
                <DetailRow label="Account Name" value={transaction.meta_data.account_name || 'N/A'} />
                <DetailRow label="Account Number" value={transaction.meta_data.account_number ? `**** **** **** ${transaction.meta_data.account_number.slice(-4)}` : 'N/A'} />
              </div>
            </>
          )}
          
          {statusHistory.length > 0 && (
            <div className="pt-3 mt-3 border-t">
              <p className="text-sm font-medium text-gray-500 mb-2">Status History:</p>
              <ul className="space-y-1.5 text-xs">
                {statusHistory.map(entry => (
                  <li key={entry.id} className="flex justify-between items-center">
                    <span>
                      Status set to <span className="font-semibold capitalize">{entry.new_status.replace(/_/g, ' ')}</span>
                      {entry.reason && <span className="text-gray-500 italic"> - "{entry.reason}"</span>}
                    </span>
                    <span className="text-gray-400">{formatInManilaTime(new Date(entry.changed_at), 'MMM d, hh:mm a')}</span>
                  </li>
                ))}
                 <li className="flex justify-between items-center text-xs">
                    <span>
                      Status set to <span className="font-semibold capitalize">{transaction.status.replace(/_/g, ' ')}</span>
                      {transaction.status_reason && <span className="text-gray-500 italic"> - "{transaction.status_reason}"</span>}
                    </span>
                    <span className="text-gray-400">{formatInManilaTime(new Date(transaction.updated_at || transaction.created_at), 'MMM d, hh:mm a')}</span>
                  </li>
              </ul>
            </div>
          )}

        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row justify-end space-y-2 sm:space-y-0 sm:space-x-3 p-4 md:p-6 bg-gray-50 border-t">
          <Button variant="outline" onClick={handleDownloadReceipt} className="w-full sm:w-auto">
            <Download className="w-4 h-4 mr-2" /> Download / Print
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default TransactionReceiptPage;