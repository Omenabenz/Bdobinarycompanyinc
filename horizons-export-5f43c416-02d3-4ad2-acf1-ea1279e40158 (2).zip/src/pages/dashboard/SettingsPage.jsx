import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { Settings as SettingsIcon, Bell, Lock, Shield, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const SettingsPage = () => {
  const { user, signOut, logUserActivity } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  
  // Placeholder states for settings - These would typically be fetched/stored in user profile or a settings table
  const [emailNotifications, setEmailNotifications] = useState(true); // Default or fetched state
  const [smsNotifications, setSmsNotifications] = useState(false); // Default or fetched state
  const [twoFactorAuth, setTwoFactorAuth] = useState(false); // Default or fetched state

  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmNewPassword) {
      toast({ title: "Password Mismatch", description: "New passwords do not match.", variant: "destructive" });
      return;
    }
    if (newPassword.length < 6) {
      toast({ title: "Weak Password", description: "New password must be at least 6 characters.", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
      toast({ title: "Password Updated", description: "Your password has been changed successfully." });
      logUserActivity(user.id, 'PASSWORD_CHANGE', 'User changed their password.');
      setNewPassword('');
      setConfirmNewPassword('');
    } catch (error) {
      toast({ title: "Password Update Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleLogout = async () => {
    setLoading(true);
    try {
      // logUserActivity is now called within signOut in AuthContext
      await signOut();
      // Toast and navigation are handled by AuthContext/App.jsx after signOut completes
      // If not, you might need:
      // toast({ title: "Logged Out", description: "You have been successfully logged out." });
      // navigate('/login', { replace: true });
    } catch (error) {
      // This catch might not be necessary if signOut itself handles toasts
      toast({ title: "Logout Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false); // This might run before navigation if signOut is slow
  };
  
  const handleNotificationToggle = async (type, value) => {
    // Placeholder: In a real app, save this preference to user's profile or a settings table.
    // For example: await supabase.from('profiles').update({ [`${type}_notifications_enabled`]: value }).eq('id', user.id);
    if (type === 'email') setEmailNotifications(value);
    if (type === 'sms') setSmsNotifications(value); // This is UI only for now
    logUserActivity(user.id, 'NOTIFICATION_SETTINGS_UPDATE', `${type.toUpperCase()} notifications ${value ? 'enabled' : 'disabled'}.`);
    toast({title: "Settings Updated", description: `${type.toUpperCase()} notifications ${value ? 'enabled' : 'disabled'}.${type === 'sms' ? ' (SMS feature coming soon)' : ''}`})
  };

   const handle2FAToggle = (value) => {
    setTwoFactorAuth(value);
    logUserActivity(user.id, '2FA_SETTINGS_UPDATE', `2FA ${value ? 'enabled' : 'disabled'}. (UI Only)`);
    toast({
      title: "Two-Factor Authentication",
      description: `2FA is now ${value ? 'enabled' : 'disabled'} (UI only). Full 2FA setup requires additional backend integration and user configuration (e.g., authenticator app setup).`,
      duration: 7000,
    });
  };


  return (
    <div className="p-4 md:p-6 space-y-8">
      <Card className="shadow-lg rounded-xl">
        <CardHeader className="border-b">
          <CardTitle className="text-2xl font-semibold text-gray-800 flex items-center">
            <SettingsIcon className="w-7 h-7 mr-3 text-blue-600" /> Account Settings
          </CardTitle>
          <CardDescription>Manage your account preferences and security settings.</CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-8">
          {/* Notification Settings */}
          <section>
            <h3 className="text-lg font-semibold text-gray-700 mb-3 flex items-center">
              <Bell className="w-5 h-5 mr-2 text-blue-500" /> Notification Preferences
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 border rounded-md">
                <Label htmlFor="emailNotifications" className="text-sm text-gray-600">Email Notifications</Label>
                <Switch 
                  id="emailNotifications" 
                  checked={emailNotifications} 
                  onCheckedChange={(value) => handleNotificationToggle('email', value)}
                  disabled={loading} 
                />
              </div>
              <div className="flex items-center justify-between p-3 bg-gray-50 border rounded-md">
                <div>
                  <Label htmlFor="smsNotifications" className="text-sm text-gray-600">SMS Notifications</Label>
                  <p className="text-xs text-gray-400">(Feature coming soon)</p>
                </div>
                <Switch 
                  id="smsNotifications" 
                  checked={smsNotifications} 
                  onCheckedChange={(value) => handleNotificationToggle('sms', value)}
                  disabled={true} // Disabled until feature is ready
                />
              </div>
            </div>
          </section>

          {/* Change Password */}
          <section>
            <h3 className="text-lg font-semibold text-gray-700 mb-3 flex items-center">
              <Lock className="w-5 h-5 mr-2 text-blue-500" /> Change Password
            </h3>
            <form onSubmit={handleChangePassword} className="space-y-4 p-4 border bg-gray-50 rounded-md">
              <div>
                <Label htmlFor="newPassword">New Password</Label>
                <Input id="newPassword" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} disabled={loading} placeholder="Minimum 6 characters" />
              </div>
              <div>
                <Label htmlFor="confirmNewPassword">Confirm New Password</Label>
                <Input id="confirmNewPassword" type="password" value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} disabled={loading} />
              </div>
              <Button type="submit" disabled={loading || !newPassword || !confirmNewPassword} className="bg-blue-600 hover:bg-blue-700 text-white">
                {loading ? 'Updating...' : 'Update Password'}
              </Button>
            </form>
          </section>

          {/* Security Settings (Placeholder for 2FA) */}
          <section>
            <h3 className="text-lg font-semibold text-gray-700 mb-3 flex items-center">
              <Shield className="w-5 h-5 mr-2 text-blue-500" /> Security
            </h3>
            <div className="flex items-center justify-between p-3 bg-gray-50 border rounded-md">
              <div>
                <Label htmlFor="twoFactorAuth" className="text-sm text-gray-600">Two-Factor Authentication (2FA)</Label>
                <p className="text-xs text-gray-400">(Authenticator app setup coming soon)</p>
              </div>
              <Switch 
                id="twoFactorAuth" 
                checked={twoFactorAuth} 
                onCheckedChange={handle2FAToggle}
                disabled={true} // Disabled until feature is fully implemented
              />
            </div>
             <p className="text-xs text-gray-500 mt-1 px-1">Enabling 2FA adds an extra layer of security to your account. This feature is currently under development.</p>
          </section>
          
          {/* Logout */}
          <section className="pt-4 border-t">
             <Button onClick={handleLogout} variant="destructive" className="w-full sm:w-auto" disabled={loading}>
              <LogOut className="w-5 h-5 mr-2"/> {loading ? 'Logging out...' : 'Log Out'}
            </Button>
            <p className="text-xs text-gray-500 mt-2">This will log you out from your current session.</p>
          </section>

        </CardContent>
      </Card>
    </div>
  );
};

export default SettingsPage;