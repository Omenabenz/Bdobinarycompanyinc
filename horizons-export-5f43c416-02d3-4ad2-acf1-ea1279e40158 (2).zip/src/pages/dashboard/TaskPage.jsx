import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { CheckSquare, PlusCircle, Trash2, Edit3, Megaphone, AlertTriangle } from 'lucide-react';
import { formatDistanceToNowStrict } from 'date-fns';

const TaskPage = () => {
  const { user } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [editingTaskId, setEditingTaskId] = useState(null);
  const [editingTaskTitle, setEditingTaskTitle] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchCombinedTasksAndAnnouncements();

    // Realtime subscription for tasks table
    const channel = supabase
      .channel(`tasks-and-announcements:${user?.id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'tasks', filter: `user_id=eq.${user?.id}` },
        (payload) => {
          console.log('Task/Announcement change received!', payload);
          fetchCombinedTasksAndAnnouncements();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const fetchCombinedTasksAndAnnouncements = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      if (error) throw error;
      
      const allItems = data || [];
      setTasks(allItems.filter(item => !item.is_announcement));
      setAnnouncements(allItems.filter(item => item.is_announcement).sort((a, b) => {
        // Sort high priority announcements first, then by date
        if (a.announcement_priority === 'high' && b.announcement_priority !== 'high') return -1;
        if (a.announcement_priority !== 'high' && b.announcement_priority === 'high') return 1;
        return new Date(b.created_at) - new Date(a.created_at);
      }));

    } catch (error) {
      toast({ title: "Error Fetching Items", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleAddTask = async () => {
    if (!newTaskTitle.trim()) {
      toast({ title: "Task Title Required", description: "Please enter a title for your task.", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const { data: insertedData, error } = await supabase
        .from('tasks')
        .insert({ user_id: user.id, title: newTaskTitle.trim(), status: 'pending', is_announcement: false })
        .select()
        .single();
      if (error) throw error;
      if (insertedData) {
        // No need to manually update state, realtime subscription will handle it
        // setTasks([insertedData, ...tasks]); 
      }
      setNewTaskTitle('');
      toast({ title: "Task Added", description: "New task created successfully." });
    } catch (error) {
      toast({ title: "Error Adding Task", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleToggleTask = async (taskId, currentStatus) => {
    const newStatus = currentStatus === 'completed' ? 'pending' : 'completed';
    setLoading(true);
    try {
      const { data: updatedData, error } = await supabase
        .from('tasks')
        .update({ status: newStatus })
        .eq('id', taskId)
        .select()
        .single();
      if (error) throw error;
      if (updatedData) {
        // setTasks(tasks.map(task => task.id === taskId ? updatedData : task));
        toast({ title: "Task Updated", description: `Task marked as ${newStatus}.` });
      }
    } catch (error) {
      toast({ title: "Error Updating Task", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const handleDeleteTask = async (taskId) => {
    setLoading(true);
    try {
      const { error } = await supabase.from('tasks').delete().eq('id', taskId);
      if (error) throw error;
      // setTasks(tasks.filter(task => task.id !== taskId));
      toast({ title: "Task Deleted", description: "Task removed successfully." });
    } catch (error)
{
      toast({ title: "Error Deleting Task", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };
  
  const handleEditTask = (task) => {
    setEditingTaskId(task.id);
    setEditingTaskTitle(task.title);
  };

  const handleSaveEdit = async () => {
    if (!editingTaskTitle.trim()) {
      toast({ title: "Task Title Required", description: "Please enter a title for your task.", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const { data: updatedData, error } = await supabase
        .from('tasks')
        .update({ title: editingTaskTitle.trim() })
        .eq('id', editingTaskId)
        .select()
        .single();
      if (error) throw error;
      if (updatedData) {
        // setTasks(tasks.map(task => task.id === editingTaskId ? updatedData : task));
        toast({ title: "Task Updated", description: "Task title saved." });
      }
      setEditingTaskId(null);
      setEditingTaskTitle('');
    } catch (error) {
      toast({ title: "Error Saving Task", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  const getAnnouncementIcon = (priority) => {
    if (priority === 'high') return <AlertTriangle className="w-5 h-5 text-red-500 mr-2 flex-shrink-0" />;
    return <Megaphone className="w-5 h-5 text-blue-500 mr-2 flex-shrink-0" />;
  };

  const getAnnouncementBgColor = (priority) => {
    if (priority === 'high') return 'bg-red-50 border-red-200';
    return 'bg-blue-50 border-blue-200';
  };

  return (
    <div className="p-4 md:p-6">
      <Card className="max-w-2xl mx-auto shadow-lg rounded-xl">
        <CardHeader className="border-b">
          <CardTitle className="text-2xl font-semibold text-gray-800 flex items-center">
            <CheckSquare className="w-7 h-7 mr-3 text-blue-600" /> Tasks & Announcements
          </CardTitle>
          <CardDescription>Manage your personal to-do list and view important announcements.</CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          {/* Announcements Section */}
          {announcements.length > 0 && (
            <div className="space-y-3 mb-6">
              <h3 className="text-lg font-semibold text-gray-700">Announcements</h3>
              {announcements.map(ann => (
                <div key={ann.id} className={`flex items-start p-3 border rounded-lg ${getAnnouncementBgColor(ann.announcement_priority)}`}>
                  {getAnnouncementIcon(ann.announcement_priority)}
                  <div>
                    <p className={`font-medium text-sm ${ann.announcement_priority === 'high' ? 'text-red-700' : 'text-blue-700'}`}>{ann.title}</p>
                    {ann.description && <p className="text-xs text-gray-600 mt-1">{ann.description}</p>}
                    <p className="text-xs text-gray-400 mt-1">
                      {formatDistanceToNowStrict(new Date(ann.created_at), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Task Input Section */}
          <div className="flex space-x-2">
            <Input 
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="Add a new task..."
              className="flex-grow bg-gray-50 border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              onKeyPress={(e) => e.key === 'Enter' && handleAddTask()}
              disabled={loading}
            />
            <Button onClick={handleAddTask} disabled={loading || !newTaskTitle.trim()} className="bg-blue-600 hover:bg-blue-700 text-white">
              <PlusCircle className="w-5 h-5 mr-2"/> Add Task
            </Button>
          </div>

          {/* Tasks List Section */}
          {loading && tasks.length === 0 && announcements.length === 0 && <p className="text-gray-500 text-center py-4">Loading...</p>}
          {!loading && tasks.length === 0 && announcements.length === 0 && <p className="text-gray-500 text-center py-8">No tasks or announcements yet.</p>}
          {!loading && tasks.length === 0 && announcements.length > 0 && <p className="text-gray-500 text-center py-8">No personal tasks yet. Add one above!</p>}
          
          {tasks.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-gray-700 mt-4">My Tasks</h3>
              <ul className="space-y-3">
                {tasks.map(task => (
                  <li key={task.id} className="flex items-center justify-between p-3 bg-gray-50 border border-gray-200 rounded-lg hover:shadow-sm transition-shadow">
                    {editingTaskId === task.id ? (
                      <Input
                        type="text"
                        value={editingTaskTitle}
                        onChange={(e) => setEditingTaskTitle(e.target.value)}
                        className="flex-grow mr-2 text-sm"
                        onKeyPress={(e) => e.key === 'Enter' && handleSaveEdit()}
                        autoFocus
                      />
                    ) : (
                      <div className="flex items-center space-x-3 flex-grow">
                        <Checkbox 
                          id={`task-${task.id}`} 
                          checked={task.status === 'completed'} 
                          onCheckedChange={() => handleToggleTask(task.id, task.status)}
                          className="border-gray-400 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                          disabled={loading}
                        />
                        <label 
                          htmlFor={`task-${task.id}`} 
                          className={`text-sm cursor-pointer ${task.status === 'completed' ? 'line-through text-gray-400' : 'text-gray-700'}`}
                        >
                          {task.title}
                        </label>
                      </div>
                    )}
                    
                    <div className="flex items-center space-x-2">
                      {editingTaskId === task.id ? (
                        <Button onClick={handleSaveEdit} size="sm" variant="ghost" className="text-green-600 hover:text-green-700" disabled={loading}>
                          Save
                        </Button>
                      ) : (
                        <Button onClick={() => handleEditTask(task)} size="icon" variant="ghost" className="text-gray-500 hover:text-blue-600" disabled={loading}>
                          <Edit3 className="w-4 h-4" />
                        </Button>
                      )}
                      <Button onClick={() => handleDeleteTask(task.id)} size="icon" variant="ghost" className="text-gray-500 hover:text-red-600" disabled={loading}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default TaskPage;