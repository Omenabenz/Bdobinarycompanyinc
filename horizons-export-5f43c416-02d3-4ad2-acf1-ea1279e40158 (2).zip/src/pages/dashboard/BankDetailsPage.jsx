import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { Landmark, User, Hash, Save, Edit3 } from 'lucide-react';

const philippineBanks = [
  "Banco de Oro (BDO)", "Bank of the Philippine Islands (BPI)", "Metrobank", "Land Bank of the Philippines", 
  "Philippine National Bank (PNB)", "Security Bank", "UnionBank of the Philippines", "RCBC", 
  "China Bank", "EastWest Bank", "GCash", "PayMaya (Maya)", "Coins.ph", "GrabPay"
];

const BankDetailsPage = () => {
  const { user, profile, fetchProfile, logUserActivity } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const [bankName, setBankName] = useState('');
  const [accountName, setAccountName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');

  useEffect(() => {
    if (profile) {
      setBankName(profile.bank_name || '');
      setAccountName(profile.bank_account_name || '');
      setAccountNumber(profile.bank_account_number || '');
      // If no bank details exist, automatically open in editing mode
      if (!profile.bank_name && !profile.bank_account_name && !profile.bank_account_number) {
        setIsEditing(true);
      }
    }
  }, [profile]);

  const handleSaveBankDetails = async () => {
    if (!bankName || !accountName || !accountNumber) {
      toast({ title: "Missing Fields", description: "Please fill all bank details.", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const updates = {
        id: user.id,
        bank_name: bankName,
        bank_account_name: accountName,
        bank_account_number: accountNumber,
        updated_at: new Date().toISOString(),
      };
      const { error } = await supabase.from('profiles').upsert(updates);
      if (error) throw error;

      await fetchProfile(user.id); // Refresh profile
      logUserActivity(user.id, 'BANK_DETAILS_UPDATE', 'User bank details updated.');
      toast({ title: "Bank Details Updated", description: "Your bank information has been saved." });
      setIsEditing(false);
    } catch (error) {
      toast({ title: "Update Failed", description: error.message, variant: "destructive" });
    }
    setLoading(false);
  };

  return (
    <div className="p-4 md:p-6">
      <Card className="max-w-2xl mx-auto shadow-lg rounded-xl">
        <CardHeader className="border-b">
          <CardTitle className="text-2xl font-semibold text-gray-800 flex items-center">
            <Landmark className="w-7 h-7 mr-3 text-blue-600" /> Bank Details
          </CardTitle>
          <CardDescription>Manage your bank account information for withdrawals.</CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div>
            <Label htmlFor="bankName" className="text-sm font-medium text-gray-600 flex items-center">
              <Landmark className="w-4 h-4 mr-2 text-blue-500"/>Bank/E-Wallet Name
            </Label>
            {isEditing ? (
              <Select onValueChange={setBankName} value={bankName} disabled={loading}>
                <SelectTrigger className="mt-1 w-full bg-gray-50 border-gray-300 text-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500">
                  <SelectValue placeholder="Select your bank or e-wallet" />
                </SelectTrigger>
                <SelectContent className="bg-popover text-popover-foreground border-border">
                  <SelectGroup>
                    <SelectLabel className="text-muted-foreground">Philippine Banks & E-Wallets</SelectLabel>
                    {philippineBanks.map(bank => (
                      <SelectItem key={bank} value={bank} className="hover:bg-accent focus:bg-accent">{bank}</SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            ) : (
              <p className="mt-1 text-lg text-gray-700 p-2 bg-gray-50 rounded-md border border-gray-200 min-h-[40px]">
                {profile?.bank_name || 'Not set'}
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="accountName" className="text-sm font-medium text-gray-600 flex items-center">
              <User className="w-4 h-4 mr-2 text-blue-500"/>Account Name
            </Label>
            <Input 
              id="accountName" 
              value={isEditing ? accountName : profile?.bank_account_name || ''} 
              onChange={(e) => setAccountName(e.target.value)} 
              disabled={!isEditing || loading}
              placeholder="Full name on account"
              className="mt-1 text-gray-700 bg-gray-50 border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 read-only:bg-gray-100 read-only:cursor-default"
              readOnly={!isEditing}
            />
          </div>

          <div>
            <Label htmlFor="accountNumber" className="text-sm font-medium text-gray-600 flex items-center">
              <Hash className="w-4 h-4 mr-2 text-blue-500"/>Account Number
            </Label>
            <Input 
              id="accountNumber" 
              value={isEditing ? accountNumber : profile?.bank_account_number || ''} 
              onChange={(e) => setAccountNumber(e.target.value)} 
              disabled={!isEditing || loading}
              placeholder="Your bank account number"
              className="mt-1 text-gray-700 bg-gray-50 border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 read-only:bg-gray-100 read-only:cursor-default"
              readOnly={!isEditing}
            />
          </div>

          <div className="pt-4">
            {isEditing ? (
              <div className="flex space-x-3">
                <Button onClick={handleSaveBankDetails} disabled={loading} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white">
                  <Save className="w-4 h-4 mr-2"/> {loading ? 'Saving...' : 'Save Details'}
                </Button>
                <Button variant="outline" onClick={() => {
                  setIsEditing(false);
                  setBankName(profile?.bank_name || '');
                  setAccountName(profile?.bank_account_name || '');
                  setAccountNumber(profile?.bank_account_number || '');
                }} disabled={loading} className="flex-1">
                  Cancel
                </Button>
              </div>
            ) : (
              <Button onClick={() => setIsEditing(true)} className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                <Edit3 className="w-4 h-4 mr-2"/> Edit Bank Details
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BankDetailsPage;