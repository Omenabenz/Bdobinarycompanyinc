import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';
import { DollarSign, Send, Landmark, AlertCircle, Banknote } from 'lucide-react';
import { generateTransactionId, generateReferenceNumber } from '@/lib/utils';
import { useNavigate, Link } from 'react-router-dom';

const philippineBanks = [
  "Banco de Oro (BDO)", "Bank of the Philippine Islands (BPI)", "Metrobank", "Land Bank of the Philippines", 
  "Philippine National Bank (PNB)", "Security Bank", "UnionBank of the Philippines", "RCBC", 
  "China Bank", "EastWest Bank", "GCash", "PayMaya (Maya)", "Coins.ph", "GrabPay"
];

const MIN_WITHDRAWAL_AMOUNT = 5000;

const WithdrawPage = () => {
  const { user, profile, fetchProfile } = useAuth();
  const navigate = useNavigate();
  
  const [amount, setAmount] = useState('');
  const [selectedBank, setSelectedBank] = useState(profile?.bank_name || '');
  const [accountName, setAccountName] = useState(profile?.bank_account_name || '');
  const [accountNumber, setAccountNumber] = useState(profile?.bank_account_number || '');
  
  const [loading, setLoading] = useState(false);
  const [userBalance, setUserBalance] = useState(0);
  const [isFetchingBalance, setIsFetchingBalance] = useState(true);

  const isFormValid = 
    parseFloat(amount) >= MIN_WITHDRAWAL_AMOUNT &&
    parseFloat(amount) <= userBalance &&
    selectedBank &&
    accountName.trim() !== '' &&
    accountNumber.trim() !== '';

  useEffect(() => {
    if (profile) {
      setSelectedBank(profile.bank_name || '');
      setAccountName(profile.bank_account_name || '');
      setAccountNumber(profile.bank_account_number || '');
    }
  }, [profile]);

  useEffect(() => {
    const fetchBalance = async () => {
      if (user) {
        setIsFetchingBalance(true);
        try {
          const { data, error } = await supabase
            .from('user_balances')
            .select('current_balance')
            .eq('user_id', user.id)
            .single();
          
          if (error && error.code !== 'PGRST116') {
             throw error;
          }
          setUserBalance(data?.current_balance || 0);
        } catch (error) {
          console.error('Error fetching balance:', error);
          toast({ title: "Error Fetching Balance", description: error.message, variant: "destructive" });
          setUserBalance(0);
        } finally {
          setIsFetchingBalance(false);
        }
      }
    };
    fetchBalance();
  }, [user]);

  const handleWithdraw = async () => {
    const withdrawAmount = parseFloat(amount);

    if (!isFormValid) {
        if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
            toast({ title: "Invalid Amount", description: "Please enter a valid positive amount.", variant: "destructive" });
        } else if (withdrawAmount < MIN_WITHDRAWAL_AMOUNT) {
            toast({ title: "Minimum Amount", description: `Minimum withdrawal amount is ₱${MIN_WITHDRAWAL_AMOUNT.toFixed(2)}.`, variant: "destructive" });
        } else if (withdrawAmount > userBalance) {
            toast({ title: "Insufficient Balance", description: "You do not have enough funds.", variant: "destructive" });
        } else if (!selectedBank || !accountName.trim() || !accountNumber.trim()) {
            toast({ title: "Bank Details Incomplete", description: "Please provide all bank details for withdrawal.", variant: "destructive" });
        }
        return;
    }

    setLoading(true);
    const transactionUid = generateTransactionId();
    const referenceNum = generateReferenceNumber();
    const withdrawalDescription = `Withdrawal to ${selectedBank} (${accountNumber.slice(-4)})`;

    try {
      const newBalance = userBalance - withdrawAmount;

      const { error: balanceError } = await supabase
        .from('user_balances')
        .update({ current_balance: newBalance, last_updated: new Date().toISOString() })
        .eq('user_id', user.id);

      if (balanceError) throw balanceError;

      const { data: transactionData, error: transactionError } = await supabase
        .from('transactions')
        .insert({
          user_id: user.id,
          transaction_uid: transactionUid,
          reference_number: referenceNum,
          type: 'withdrawal_request',
          amount: -withdrawAmount, // Store as negative
          status: 'pending',
          description: withdrawalDescription,
          meta_data: { 
            bank_name: selectedBank,
            account_name: accountName,
            account_number: accountNumber 
          }
        })
        .select('id, transaction_uid') // Ensure transaction_uid is selected
        .single();

      if (transactionError) {
        await supabase.from('user_balances').update({ current_balance: userBalance }).eq('user_id', user.id);
        throw transactionError;
      }
      
      await supabase.from('notifications').insert({
        user_id: user.id,
        type: 'transaction_update',
        message: `Your withdrawal request of ₱${withdrawAmount.toFixed(2)} is pending. Ref: ${referenceNum}`,
        link_to: `/dashboard/transactions/receipt/${transactionData.transaction_uid || transactionData.id}` 
      });
      
      // Notify Admin (system-level notification)
      // This might require a specific admin user_id or a different mechanism
      // For now, let's assume a generic admin notification if such a system exists
      // Or this could be a trigger/Edge Function that creates an admin task/alert
      console.log("Admin Notification: New withdrawal request pending - User:", user.email, "Amount:", withdrawAmount, "Ref:", referenceNum);
      // Example: await supabase.from('admin_alerts').insert({ message: `...` });

      // Simulate sending email
      const { error: emailError } = await supabase.functions.invoke('send-withdrawal-email', {
        body: JSON.stringify({
          to_email: user.email,
          user_name: profile?.full_name || user.email,
          subject: "Withdrawal Request Submitted",
          transaction_ref: referenceNum,
          transaction_status: "Pending",
          transaction_amount: withdrawAmount,
          bank_details: `${selectedBank} (Acct No: ...${accountNumber.slice(-4)})`,
          email_type: 'request_submitted'
        })
      });
      if (emailError) console.warn("Email simulation error:", emailError.message);


      toast({ title: "Withdrawal Request Submitted", description: `Ref: ${referenceNum}. Your request for ₱${withdrawAmount.toFixed(2)} is pending.`, duration: 5000 });
      setUserBalance(newBalance);
      setAmount('');
      await fetchProfile(user.id); 
      
      navigate(`/dashboard/transactions/receipt/${transactionData.transaction_uid || transactionData.id}`);

    } catch (error) {
      toast({ title: "Withdrawal Failed", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };
  
  const bankDetailsProvided = profile?.bank_name && profile?.bank_account_name && profile?.bank_account_number;

  return (
    <div className="p-4 md:p-6">
      <Card className="max-w-2xl mx-auto shadow-lg rounded-xl">
        <CardHeader className="border-b">
          <CardTitle className="text-2xl font-semibold text-gray-800 flex items-center">
            <DollarSign className="w-7 h-7 mr-3 text-blue-600" /> Withdraw Funds
          </CardTitle>
          <CardDescription>Transfer funds to your linked bank account. Minimum ₱{MIN_WITHDRAWAL_AMOUNT.toFixed(2)}.</CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-700 font-medium">Available Balance:</p>
            {isFetchingBalance ? (
                 <p className="text-3xl font-bold text-blue-600">Loading...</p>
            ): (
                 <p className="text-3xl font-bold text-blue-600">₱{userBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
            )}
          </div>

          {!bankDetailsProvided && (
            <div className="p-4 bg-yellow-50 border border-yellow-300 rounded-lg text-yellow-700 flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0 text-yellow-500" />
              <div>
                <h4 className="font-semibold">Bank Details Required</h4>
                <p className="text-sm">Please add your primary bank details in your <Link to="/dashboard/bank-details" className="underline hover:text-yellow-800">Bank Details page</Link> first, or fill them below for this withdrawal.</p>
              </div>
            </div>
          )}
          
          <div className="space-y-4 p-4 border rounded-lg bg-gray-50">
             <p className="text-sm font-medium text-gray-700 mb-1">Withdraw To:</p>
            <div>
                <Label htmlFor="selectedBank">Bank/E-Wallet Name</Label>
                <Select value={selectedBank} onValueChange={setSelectedBank} disabled={loading}>
                    <SelectTrigger id="selectedBank" className="mt-1 bg-white">
                        <SelectValue placeholder="Select bank/e-wallet" />
                    </SelectTrigger>
                    <SelectContent>
                        {philippineBanks.map(bank => <SelectItem key={bank} value={bank}>{bank}</SelectItem>)}
                    </SelectContent>
                </Select>
            </div>
            <div>
                <Label htmlFor="accountName">Account Name</Label>
                <Input id="accountName" value={accountName} onChange={e => setAccountName(e.target.value)} placeholder="Full name on account" className="mt-1 bg-white" disabled={loading}/>
            </div>
            <div>
                <Label htmlFor="accountNumber">Account Number</Label>
                <Input id="accountNumber" value={accountNumber} onChange={e => setAccountNumber(e.target.value)} placeholder="Bank account number" className="mt-1 bg-white" disabled={loading}/>
            </div>
            {!bankDetailsProvided && (
                <p className="text-xs text-gray-500">Entering details here will use them for this transaction. For future ease, <Link to="/dashboard/bank-details" className="underline">save them in your profile</Link>.</p>
            )}
          </div>


          <div>
            <Label htmlFor="amount" className="text-sm font-medium text-gray-600 flex items-center">
             <Banknote className="w-4 h-4 mr-2 text-blue-500"/> Amount to Withdraw (PHP)
            </Label>
            <div className="relative mt-1">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500 pointer-events-none">₱</span>
              <Input 
                id="amount" 
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder={MIN_WITHDRAWAL_AMOUNT.toFixed(2)}
                disabled={loading || isFetchingBalance}
                className="pl-7 text-gray-700 bg-white border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 text-lg"
              />
            </div>
             {parseFloat(amount) > 0 && parseFloat(amount) < MIN_WITHDRAWAL_AMOUNT && (
                <p className="text-xs text-red-500 mt-1">Minimum withdrawal is ₱{MIN_WITHDRAWAL_AMOUNT.toFixed(2)}.</p>
            )}
            {parseFloat(amount) > userBalance && (
                <p className="text-xs text-red-500 mt-1">Amount exceeds available balance.</p>
            )}
          </div>
          
          <Button 
            onClick={handleWithdraw} 
            disabled={loading || isFetchingBalance || !isFormValid} 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white text-base py-3"
          >
            <Send className="w-5 h-5 mr-2"/> {loading ? 'Processing...' : 'Submit Withdrawal Request'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default WithdrawPage;