import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { Mail, KeyRound, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [messageSent, setMessageSent] = useState(false);

  const handlePasswordReset = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessageSent(false);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`, // Your redirect URL after email link click
      });
      if (error) throw error;
      toast({ title: 'Password Reset Email Sent', description: 'Please check your email for instructions.' });
      setMessageSent(true);
    } catch (error) {
      toast({ title: 'Error Sending Reset Email', description: error.message, variant: 'destructive' });
    }
    setLoading(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 p-4"
    >
      <Card className="w-full max-w-md shadow-xl border-slate-700 bg-slate-800 text-slate-50">
        <CardHeader className="text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: "spring", stiffness: 200 }}>
            <KeyRound className="mx-auto h-12 w-12 text-primary mb-3" />
          </motion.div>
          <CardTitle className="text-3xl font-semibold">Forgot Password</CardTitle>
          <CardDescription className="text-slate-400">
            {messageSent ? 'Check your email for the reset link.' : 'Enter your email to receive a password reset link.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!messageSent ? (
            <form onSubmit={handlePasswordReset} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-300 flex items-center">
                  <Mail className="mr-2 h-4 w-4 text-slate-400" /> Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-slate-50 placeholder:text-slate-500 focus:border-primary focus:ring-primary"
                />
              </div>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 text-base" disabled={loading}>
                {loading ? 'Sending...' : 'Send Reset Link'}
              </Button>
            </form>
          ) : (
            <div className="text-center text-slate-300">
              <p>If an account exists for {email}, you will receive an email with instructions on how to reset your password.</p>
              <p className="mt-2">Please check your spam folder if you don't see it.</p>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-col items-center space-y-3 pt-6 border-t border-slate-700">
          <Button variant="link" className="text-slate-400 hover:text-primary" asChild>
            <Link to="/login">
              <ArrowLeft className="mr-1.5 h-4 w-4" /> Back to Login
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default ForgotPasswordPage;