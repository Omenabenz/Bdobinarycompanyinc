import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { Mail, Lock, LogIn, UserPlus, Chrome, Facebook as FacebookIcon, Briefcase } from 'lucide-react';
import { motion } from 'framer-motion';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { signInWithEmail, signInWithGoogle, signInWithFacebook } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { error } = await signInWithEmail(email, password);
      if (error) throw error;
      toast({ title: 'Login Successful!', description: 'Welcome back!' });
      navigate('/dashboard'); 
    } catch (error) {
      toast({ title: 'Login Failed', description: error.message, variant: 'destructive' });
    }
    setLoading(false);
  };

  const handleSocialLogin = async (provider) => {
    setLoading(true);
    try {
      const { error } = provider === 'google' ? await signInWithGoogle() : await signInWithFacebook();
      if (error) throw error;
      // Navigation will be handled by AuthContext listener
    } catch (error) {
      toast({ title: 'Social Login Failed', description: error.message, variant: 'destructive' });
    }
    setLoading(false);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 p-4"
    >
      <Card className="w-full max-w-md shadow-xl border-slate-700 bg-slate-800 text-slate-50">
        <CardHeader className="text-center">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1}} transition={{ delay: 0.2, type: "spring", stiffness: 200 }}>
            <LogIn className="mx-auto h-12 w-12 text-primary mb-3" />
          </motion.div>
          <CardTitle className="text-3xl font-semibold">Welcome Back</CardTitle>
          <CardDescription className="text-slate-400">Sign in to access your account.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-slate-300 flex items-center">
                <Mail className="mr-2 h-4 w-4 text-slate-400" /> Email Address
              </Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="you@example.com" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                required 
                className="bg-slate-700 border-slate-600 text-slate-50 placeholder:text-slate-500 focus:border-primary focus:ring-primary"
              />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="password" className="text-slate-300 flex items-center">
                  <Lock className="mr-2 h-4 w-4 text-slate-400" /> Password
                </Label>
                <Link to="/forgot-password" className="text-xs text-slate-400 hover:text-primary hover:underline">
                  Forgot password?
                </Link>
              </div>
              <Input 
                id="password" 
                type="password" 
                placeholder="••••••••" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                required 
                className="bg-slate-700 border-slate-600 text-slate-50 placeholder:text-slate-500 focus:border-primary focus:ring-primary"
              />
            </div>
            <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-3 text-base" disabled={loading}>
              {loading ? 'Signing In...' : 'Sign In'}
            </Button>
          </form>
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-slate-600" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-slate-800 text-slate-400 rounded-md">Or continue with</span>
              </div>
            </div>
            <div className="mt-6 grid grid-cols-2 gap-4">
              <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-slate-50" onClick={() => handleSocialLogin('google')} disabled={loading}>
                <Chrome className="mr-2 h-5 w-5" /> Google
              </Button>
              <Button variant="outline" className="w-full border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-slate-50" onClick={() => handleSocialLogin('facebook')} disabled={loading}>
                <FacebookIcon className="mr-2 h-5 w-5" /> Facebook
              </Button>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col items-center space-y-3 pt-6 border-t border-slate-700">
          <p className="text-sm text-slate-400">
            Don't have an account?{' '}
            <Link to="/register" className="font-medium text-primary hover:underline">
              Sign Up Here
            </Link>
          </p>
          <div className="mt-4 w-full text-center">
            <Button variant="link" className="text-slate-400 hover:text-primary text-xs opacity-75 hover:opacity-100" asChild>
              <Link to="/admin/login">
                <Briefcase className="mr-1.5 h-3.5 w-3.5" /> Company Access
              </Link>
            </Button>
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default LoginPage;