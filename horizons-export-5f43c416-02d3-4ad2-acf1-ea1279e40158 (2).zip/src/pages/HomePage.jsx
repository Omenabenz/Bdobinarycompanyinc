import React from 'react';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import LivePayoutAlerts from '@/components/LivePayoutAlerts';
import InvestmentCarousel from '@/components/InvestmentCarousel';
import BankLogos from '@/components/BankLogos';
import MarketActivity from '@/components/MarketActivity';
import Testimonials from '@/components/Testimonials';
import TransferNotifications from '@/components/TransferNotifications';
import CompanyHighlights from '@/components/CompanyHighlights';
import PartnershipCompliance from '@/components/PartnershipCompliance';
import NewsPartnership from '@/components/NewsPartnership';
import WithdrawalProofs from '@/components/WithdrawalProofs';
import ContactSupport from '@/components/ContactSupport';
import Footer from '@/components/Footer';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';


const HomePage = ({ isMenuOpen, setIsMenuOpen }) => {
  const { user, signOut, profile } = useAuth();
  const navigate = useNavigate();

  const handleRegister = () => navigate('/register');
  const handleLogin = () => navigate('/login');
  
  const handleLogout = async () => {
    try {
      await signOut();
      toast({ title: "Logged Out", description: "You have been successfully logged out." });
      navigate('/'); 
    } catch (error) {
      toast({ title: "Logout Failed", description: error.message, variant: "destructive" });
    }
  };

  const menuItems = [
    { name: 'Home', href: '#home' },
    { name: 'Investment Plans', href: '#plans' },
    { name: 'Live Payouts', href: '#payouts' },
    { name: 'Withdrawal Proofs', href: '#proofs' },
    { name: 'Testimonials', href: '#testimonials' },
    { name: 'News', href: '#news' },
    { name: 'About Us', href: '#about' },
    { name: 'Contact', href: '#contact' }
  ];

  const stockTicker = [
    'PSEi: +2.3% ₱6,847.23',
    'BTC: +5.2% $43,250',
    'ETH: +3.8% $2,650',
    'BDO: +1.8% ₱142.50',
    'BPI: +2.1% ₱98.75',
    'PLDT: +0.9% ₱1,285',
    'SM: +1.5% ₱875.50'
  ];
  
  const currentDate = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="bg-gradient-to-r from-primary to-accent text-primary-foreground py-2 overflow-hidden shadow-md">
        <div className="ticker-scroll whitespace-nowrap">
          <span className="inline-block px-8 text-sm font-medium">
            🔴 LIVE MARKET (As of {currentDate}): {stockTicker.join(' • ')} • Philippine Stock Exchange • Real-time Updates
          </span>
        </div>
      </div>

      <Header 
        menuItems={menuItems}
        isMenuOpen={isMenuOpen}
        setIsMenuOpen={setIsMenuOpen}
        handleLogin={user ? handleLogout : handleLogin}
        handleRegister={user ? null : handleRegister}
        user={user}
        profile={profile}
      />

      <HeroSection handleRegister={handleRegister} />
      <LivePayoutAlerts />
      <InvestmentCarousel handleRegister={handleRegister} />
      <BankLogos />
      <NewsPartnership />
      <MarketActivity />
      <WithdrawalProofs currentDate={currentDate} />
      <Testimonials />
      <TransferNotifications />
      <CompanyHighlights />
      <PartnershipCompliance currentDate={currentDate} />
      <ContactSupport handleRegister={handleRegister} />
      <Footer menuItems={menuItems} currentDate={currentDate} />
    </div>
  );
};

export default HomePage;